package junit.extensions;

import java.lang.reflect.*;

import junit.framework.*;

/**
* A test case used to wrap a simple test case, used to run to test for a fixed number of iterations<br>
 * It prints total and average execution time.<br>
 * It let to verify total and average time execution. <br>
 * It was inspired by junit.extensions.RepeatedTest and JUnitPerf TimedTest
 * but, for a better accurancy, test iteration is done with caching on reflection invoke.
 * 
 * <code>setUp</code> and <code>tearDown</code> methods are called before and after
 * iteration block (but this can be extended to conditionally do these calls in iteration block).
 * Static factory methods are provided to  simplyfy overloading constructors:
 * @see TestCase
 * @see IterTestSuite
 * @author Giovanni Pelosi (hute37@netscape.net)
 */
public class IterTest extends TestCase {

    /**
     * Method test.
     * @param testClass Class<? extends TestCase>
     * @param testMethod String
     * @param repeat int
     * @param maxElapsedTime long
     * @param maxAverageTime double
     * @return IterTest
     */
    public static IterTest test(Class<? extends TestCase> testClass, String testMethod, int repeat, 
            long maxElapsedTime, double maxAverageTime) {
        try {
            Constructor<? extends TestCase> ctor;
            ctor = testClass.getConstructor(String.class);
            TestCase test = ctor.newInstance(testMethod);
            return test(test,repeat, maxElapsedTime, maxAverageTime);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    
    /**
     * Method test.
     * @param test TestCase
     * @param repeat int
     * @param maxElapsedTime long
     * @param maxAverageTime double
     * @return IterTest
     */
    public static IterTest test(TestCase test, int repeat, long maxElapsedTime, double maxAverageTime) {
        return new IterTest(test,repeat,maxElapsedTime, maxAverageTime);
    }
    
    /**
     * Method test.
     * @param testClass Class<? extends TestCase>
     * @param testMethod String
     * @param repeat int
     * @param maxAverageTime double
     * @return IterTest
     */
    public static IterTest test(Class<? extends TestCase> testClass, String testMethod, int repeat, double maxAverageTime) {
        return test(testClass, testMethod, repeat,0, maxAverageTime);
    }
    
    /**
     * Method test.
     * @param test TestCase
     * @param repeat int
     * @param maxAverageTime double
     * @return IterTest
     */
    public static IterTest test(TestCase test, int repeat, double maxAverageTime) {
        return new IterTest(test,repeat,0, maxAverageTime);
    }
    
    /**
     * Method test.
     * @param testClass Class<? extends TestCase>
     * @param testMethod String
     * @param repeat int
     * @param maxElapsedTime long
     * @return IterTest
     */
    public static IterTest test(Class<? extends TestCase> testClass, String testMethod, int repeat, long maxElapsedTime) {
        return test(testClass, testMethod, repeat,maxElapsedTime,0.0);
    }
    
    /**
     * Method test.
     * @param test TestCase
     * @param repeat int
     * @param maxElapsedTime long
     * @return IterTest
     */
    public static IterTest test(TestCase test, int repeat, long maxElapsedTime) {
        return test(test,repeat,maxElapsedTime,0.0);
    }
    
    /**
     * Method test.
     * @param testClass Class<? extends TestCase>
     * @param testMethod String
     * @param repeat int
     * @return IterTest
     */
    public static IterTest test(Class<? extends TestCase> testClass, String testMethod, int repeat) {
        return test(testClass, testMethod, repeat, 0, 0.0);
    }
    
    /**
     * Method t.
     * @param test TestCase
     * @param repeat int
     * @return IterTest
     */
    public static IterTest test(TestCase test, int repeat) {
        return test(test, repeat, 0);
    }
    
    private int fTimesRepeat;
    private final long maxElapsedTime;
    private final double maxAverageTime;
    private boolean maxElapsedTimeExceeded;
    private boolean maxAverageTimeExceeded;
    private boolean isQuiet;
    
    private TestCase testCase;
    
    /**
     * Constructor for IterTest.
     * @param testCase TestCase
     * @param repeat int
     */
    public IterTest(TestCase testCase, int repeat) {
        this(testCase, repeat, 0, 0.0);
    }
    
    /**
     * Constructor for IterTest.
     * @param testCase TestCase
     * @param repeat int
     * @param maxElapsedTime long
     * @param maxAverageTime double
     */
    public IterTest(TestCase testCase, int repeat, long maxElapsedTime, double maxAverageTime) {
        super("testRun");
        if (repeat < 0)
            throw new IllegalArgumentException("Repetition count must be > 0");
        fTimesRepeat= repeat;
        
        this.maxElapsedTime = maxElapsedTime;
        this.maxAverageTime = maxAverageTime;
        maxElapsedTimeExceeded = false;
        maxAverageTimeExceeded = false;
        isQuiet = false;
        this.testCase = testCase;
//      setName(testCase.getName());
        setName(testCase.getName().trim()+"-[n:"+repeat+",t:"+maxElapsedTime+",m:"+maxAverageTime+"]");
        
    }
    
    /**
     * Method runTest.
     * @throws Throwable
     */
    @Override
    protected void runTest() throws Throwable {
        testRun();
    }

    /**
     * Method testRun.
     * @throws Throwable
     */
    public void testRun() throws Throwable {
        
        String testName = testCase.getName(); 

        
        assertNotNull(testName);
        Method runMethod= null;
        try {
            // use getMethod to get all public inherited
            // methods. getDeclaredMethods returns all
            // methods of this class but excludes the
            // inherited ones.
            runMethod= testCase.getClass().getMethod(testName, (Class[]) null);
        } catch (NoSuchMethodException e) {
            fail("Method \""+testName+"\" not found");
        }
        if (!Modifier.isPublic(runMethod.getModifiers())) {
            fail("Method \""+testName+"\" should be public");
        }

        Method setUpMethod= null;
        try {
            setUpMethod= testCase.getClass().getDeclaredMethod("setUp", (Class[]) null);
            if (!Modifier.isPublic(setUpMethod.getModifiers())) {
                setUpMethod.setAccessible(true);
            }
        } catch (NoSuchMethodException e) {
        }
        
        Method tearDownMethod= null;
        try {
            tearDownMethod= testCase.getClass().getDeclaredMethod("tearDown", (Class[]) null);
            if (!Modifier.isPublic(tearDownMethod.getModifiers())) {
                tearDownMethod.setAccessible(true);
            }
        } catch (NoSuchMethodException e) {
        }
        
        
        if (setUpMethod != null) {
            try {
                setUpMethod.invoke(testCase, new Object[0]);
            }
            catch (InvocationTargetException e) {
                e.fillInStackTrace();
                throw e.getTargetException();
            }
            catch (IllegalAccessException e) {
                e.fillInStackTrace();
                throw e;
            }
        }

        long beginTime = System.currentTimeMillis();
        
        for (int i= 0; i < fTimesRepeat; i++) {
            try {
                runMethod.invoke(testCase, new Object[0]);
            }
            catch (InvocationTargetException e) {
                e.fillInStackTrace();
                throw e.getTargetException();
            }
            catch (IllegalAccessException e) {
                e.fillInStackTrace();
                throw e;
            }
        }

        long elapsedTime = getElapsedTime(beginTime);
        double averageTime = ((double) elapsedTime) / ((double) fTimesRepeat);
        
        if (tearDownMethod != null) {
            try {
                tearDownMethod.invoke(testCase, new Object[0]);
            }
            catch (InvocationTargetException e) {
                e.fillInStackTrace();
                throw e.getTargetException();
            }
            catch (IllegalAccessException e) {
                e.fillInStackTrace();
                throw e;
            }
        }

        printElapsedTime(elapsedTime, averageTime);
        
        if (maxElapsedTime > 0) {
            if (elapsedTime > maxElapsedTime) { 
                maxElapsedTimeExceeded = true;
                fail("Expected " + maxElapsedTime + " ms, but was " +
                        elapsedTime + " ms." +
                        " Maximum elapsed time exceeded!");
            }
        }

        
        if (maxAverageTime > 0.0) {
            if (averageTime > maxAverageTime) { 
                maxElapsedTimeExceeded = true;
                fail("Expected " + maxAverageTime + " ms, but was " +
                        averageTime + " ms." +
                        " Maximum average time exceeded!");
            }
        }

        
        
    }


    /**
     * Method getElapsedTime.
     * @param beginTime long
     * @return long
     */
    protected long getElapsedTime(long beginTime) {
        long endTime = System.currentTimeMillis();
        return endTime - beginTime;
    }
    
    /**
     * Method printElapsedTime.
     * @param elapsedTime long
     * @param averageTime double
     */
    protected void printElapsedTime(long elapsedTime, double averageTime) {
        if (!isQuiet) {
            System.out.println(format() +"\t => "+ testCase.toString()+ "\t: " + elapsedTime + " ms" + " (avg: "+averageTime + " ms)");
            System.out.flush();
        }
    }
        
    /**
     * Method format.
     * @return String
     */
    private String format() {
        return "[iter(n:"+fTimesRepeat+",t:"+maxElapsedTime+",m:"+maxAverageTime+")]";
    }
    
    /**
     * Method toString.
     * @return String
     */
    @Override
    public String toString() {
        return format()+testCase.toString();
    }

    /**
     * Method isMaxElapsedTimeExceeded.
     * @return boolean
     */
    public boolean isMaxElapsedTimeExceeded() {
        return maxElapsedTimeExceeded;
    }

    /**
     * Method isMaxAverageTimeExceeded.
     * @return boolean
     */
    public boolean isMaxAverageTimeExceeded() {
        return maxAverageTimeExceeded;
    }

    /**
     * Method getTestCase.
     * @return TestCase
     */
    public TestCase getTestCase() {
        return testCase;
    }
    

} 