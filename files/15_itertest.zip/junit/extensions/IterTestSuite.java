package junit.extensions;

import java.lang.reflect.*;

import junit.framework.*;

/**
 * A TestSuite for timed Tests. It wraps each
 * test, iterating for a fixed numer of repetitions
 * and computing avg elaboration times.
 * @see IterTest
 * @author Giovanni Pelosi (hute37@netscape.net)
 * 
 */
public class IterTestSuite extends TestSuite {

    /**
     * Constructor for IterTestSuite.
     */
    public IterTestSuite() {
        super();
    }

    /**
     * Constructor for IterTestSuite.
     * @param theClass Class
     * @param name String
     */
    public IterTestSuite(Class theClass, String name) {
        super(theClass, name);
    }

    /**
     * Constructor for IterTestSuite.
     * @param theClass Class
     */
    public IterTestSuite(Class theClass) {
        super(theClass);
    }

    /**
     * Constructor for IterTestSuite.
     * @param name String
     */
    public IterTestSuite(String name) {
        super(name);
    }
    

    
    /**
     * Constructor for IterTestSuite.
     * @param repeat int
     */
    public IterTestSuite(int repeat) {
        this();
        this.repeat = repeat;
    }

    /**
     * Constructor for IterTestSuite.
     * @param theClass Class
     * @param name String
     * @param repeat int
     */
    public IterTestSuite(Class theClass, String name, int repeat) {
        this(theClass, name);
        this.repeat = repeat;
    }

    /**
     * Constructor for IterTestSuite.
     * @param theClass Class
     * @param repeat int
     */
    public IterTestSuite(Class theClass, int repeat) {
        this(theClass);
        this.repeat = repeat;
    }

    /**
     * Constructor for IterTestSuite.
     * @param name String
     * @param repeat int
     */
    public IterTestSuite(String name, int repeat) {
        this(name);
        this.repeat = repeat;
    }
    
    
    
    private int repeat;
    
    
    private Class<? extends IterTest> wrapperClass = IterTest.class;

    /**
     * @return Returns the wrapperClass.
     */
    public Class<? extends IterTest> getWrapperClass() {
        return this.wrapperClass;
    }

    /**
     * @param wrapperClass The wrapperClass to set.
     */
    public void setWrapperClass(Class<? extends IterTest> wrapperClass) {
        this.wrapperClass = wrapperClass;
    }

    /**
     * Method runTest.
     * @param test Test
     * @param result TestResult
     */
    @Override
    public void runTest(Test test, TestResult result) {
        super.runTest(wrapTest(test), result);
    }
    
    /**
     * wrap a Test in a IterTest with a fixed repetition count.
     * @param test Test
     * @return Test
     */
    private Test wrapTest(Test test) {
        try {
            if (!(test instanceof TestCase)) {
                return test;
            }
            Constructor<? extends IterTest> ctor = getWrapperClass()
                    .getConstructor(TestCase.class, int.class);

            Test result = ctor.newInstance(test, getRepeat());
            return result;
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * @return Returns the repeat.
     */
    public int getRepeat() {
        return this.repeat > 0 ? repeat : 1;
    }

    /**
     * @param repeat The repeat to set.
     */
    public void setRepeat(int repeat) {
        this.repeat = repeat;
    }

    /* (non-Javadoc)
     * @see junit.framework.TestSuite#addTestSuite(java.lang.Class)
     */
    @Override
    public void addTestSuite(Class testClass) {
        addTest(new IterTestSuite(testClass, getRepeat()));
    }
    
}
