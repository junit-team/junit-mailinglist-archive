package junit.extensions.test;

import junit.extensions.*;
import junit.framework.*;

public class IterFactDemoTests {

    public static Test suite() {
        TestSuite suite = new TestSuite("Demo for IterTest test wrapper");
        //$JUnit-BEGIN$
        
        suite.addTest(new IterTest(new IterFactDemoTest("testFactIter", true), 5));
        suite.addTest(new IterTest(new IterFactDemoTest("testFactRec", true), 5));
        
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactIter", 100000));
        suite.addTest(IterTest.test(new IterFactDemoTest("testFactRec"), 100000));
        
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactIter", 50, 10));
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactRec", 50, 10));
        
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactIter", 5000, 10));
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactRec", 5000, 10));
        
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactIter", 500000, 10));
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactRec", 500000, 10));
        
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactIter", 500000, 1.0));
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactRec", 500000, 1.0));
        
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactIter", 500000, 1.0E-3));
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactRec", 500000, 1.0E-3));
        
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactIter", 500000, 1.0E-5));
        suite.addTest(IterTest.test(IterFactDemoTest.class, "testFactRec", 500000, 1.0E-5));
        
        //$JUnit-END$
        return suite;
    }

}
