package junit.extensions.test;

import junit.extensions.*;
import junit.framework.*;

public class IterFactDemoSuiteTests {

    public static Test suite() {
        TestSuite suite = new IterTestSuite("Demo for IterTestSuite ", 2000000);
        //$JUnit-BEGIN$
        suite.addTestSuite(IterFactDemoTest.class);
        //$JUnit-END$
        return suite;
    }

}
