package junit.extensions.test;

import junit.framework.*;

public class AllTests {

    public static Test suite() {
        TestSuite suite = new TestSuite("Demo for IterTest, IterTestSuite");
        //$JUnit-BEGIN$
        suite.addTest(IterFactDemoTests.suite());
        suite.addTest(IterFactDemoSuiteTests.suite());
        //$JUnit-END$
        return suite;
    }

}
