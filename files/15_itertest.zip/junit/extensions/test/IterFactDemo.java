package junit.extensions.test;

public class IterFactDemo {

    public long factIter(long n) {
        long f = 1;
        for (int i = 1; i <= n; i++) {
            f *= i;
        }
        return f;
    }

    public long factRec(long n) {
        return n == 0 ? 1 : n * factRec(n-1);
    }
     

}
