package junit.extensions.test;

import junit.framework.*;

public class IterFactDemoTest extends TestCase {

    public static void main(String[] args) {
        junit.textui.TestRunner.run(IterFactDemoTest.class);
    }

    public IterFactDemoTest() {
        super();
    }

    public IterFactDemoTest(String name) {
        super(name);
    }
    
    public IterFactDemoTest(boolean verbose) {
        this();
        this.verbose = verbose;
    }

    public IterFactDemoTest(String name,boolean verbose) {
        this(name);
        this.verbose = verbose;
    }
    
    boolean verbose;
    

    /**
     * @return Returns the verbose.
     */
    public boolean isVerbose() {
        return this.verbose;
    }

    /**
     * @param verbose The verbose to set.
     */
    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    protected void setUp() throws Exception {
        super.setUp();
        if (verbose) System.out.println("setup...");
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        if (verbose) System.out.println("teardown...");
    }

    public void testFactIter() {
        IterFactDemo a = new IterFactDemo();
        long n = a.factIter(20);
        assertEquals(2432902008176640000L, n);
        if (verbose) System.out.println("testFactIter: " + n);
    }

    public void testFactRec() {
        IterFactDemo a = new IterFactDemo();
        long n = a.factRec(20);
        assertEquals(2432902008176640000L, n);
        if (verbose) System.out.println("testFactRec: " + n);
    }

}
