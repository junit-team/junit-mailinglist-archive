/*
 * Copyright (C) 2002 by Brett Neumeier. All rights reserved.
 */
package cx.rnd.test.console;

import java.io.*;

import junit.framework.*;

public class SampleConsoleAppTest extends TestCase {

    private ConsoleTester tester;

    public SampleConsoleAppTest(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        tester = new ConsoleTester();
    }

    protected void tearDown() throws Exception {
        tester.shutdown();
    }

    public void testSampleConsoleApp() throws Exception {
        Thread sampleAppRunner = new Thread() {
            public void run() {
                SampleConsoleApp.main(new String[0]);
            }
        };
        sampleAppRunner.start();
        Thread.sleep(25);
        assertEquals("What's your name?  ", tester.getOutput());

        tester.provideInput("Eric");
        Thread.sleep(25);
        assertEquals("Where do you work, Eric?  ", tester.getOutput());

        tester.provideInput("Nowhere right now");
        Thread.sleep(25);
        assertEquals("Get a real job!\n", tester.getOutput());
    }
}