/*
 * Copyright (C) 2002 by Brett Neumeier. All rights reserved.
 */
package cx.rnd.test.console;

import junit.framework.*;

public class ConsoleTestSuite {
    public static Test suite() {
        TestSuite suite = new TestSuite("Java Console Tests");
        suite.addTestSuite(ConsoleTesterTest.class);
        suite.addTestSuite(SampleConsoleAppTest.class);
        return suite;
    }
}