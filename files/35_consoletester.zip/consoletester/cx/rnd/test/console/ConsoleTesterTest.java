/*
 * Copyright (C) 2002 by Brett Neumeier. All rights reserved.
 */
package cx.rnd.test.console;

import cx.rnd.util.*;

import junit.framework.*;

public class ConsoleTesterTest extends TestCase {

    private ConsoleTester tester;

    public ConsoleTesterTest(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        tester = new ConsoleTester();
    }

    protected void tearDown() {
        tester.shutdown();
    }

    public void testGetOutput() throws Exception {
        System.out.print("Hello, World!");
        assertEquals("Hello, World!", tester.getOutput());
    }

    public void testProvideInput() throws Exception {
        tester.provideInput("here is some input\n");
        assertEquals("here is some input\n", StreamUtils.readFromStream(System.in));
    }

    public void testProvideInputAddsEndOfLine() throws Exception {
        tester.provideInput("here is some input without an EOL");
        assertEquals(
            "here is some input without an EOL\n",
            StreamUtils.readFromStream(System.in));
    }
}