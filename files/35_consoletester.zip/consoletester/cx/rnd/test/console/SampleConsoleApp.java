/*
 * Copyright (C) 2002 by Brett Neumeier. All rights reserved.
 */
package cx.rnd.test.console;

import java.io.*;

public class SampleConsoleApp {
    public static void main(String[] args) {
        try {
            BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("What's your name?  ");
            String userName = stdIn.readLine();
            System.out.print("Where do you work, " + userName + "?  ");
            String place = stdIn.readLine();
            System.out.println("Get a real job!");
        } catch (IOException problem) {
            throw new RuntimeException("Unexpected I/O problem");
        }
    }
}