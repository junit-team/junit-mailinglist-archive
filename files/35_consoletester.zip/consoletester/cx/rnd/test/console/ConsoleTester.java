/*
 * Copyright (C) 2002 by Brett Neumeier. All rights reserved.
 */
package cx.rnd.test.console;

import java.io.*;

import cx.rnd.util.*;

public class ConsoleTester implements Constants {

    private PipedInputStream in;
    private Writer pipeToInput;
    
    private InputStream savedStdin;
    private PrintStream savedStdout;

    public ConsoleTester() throws IOException {
        savedStdin = System.in;
        savedStdout = System.out;

        PipedOutputStream sysOut = new PipedOutputStream();
        in = new PipedInputStream(sysOut);
        System.setOut(new PrintStream(sysOut, true));

        PipedOutputStream out = new PipedOutputStream();
        PipedInputStream sysIn = new PipedInputStream(out);
        System.setIn(sysIn);
        pipeToInput = new OutputStreamWriter(out);
    }

    public String getOutput() throws IOException {
        return StreamUtils.readFromStream(in);
    }

    public void provideInput(String fakeInput) throws IOException {
        pipeToInput.write(ensureEndOfLine(fakeInput));
        pipeToInput.flush();
    }

    private String ensureEndOfLine(String original) {
        if (original.endsWith(EOL)) {
            return original;
        } else {
            return original + EOL;
        }
    }
    
    public void shutdown() {
        System.setIn(savedStdin);
        System.setOut(savedStdout);
    }

    protected void finalize() {
        shutdown();
    }
}