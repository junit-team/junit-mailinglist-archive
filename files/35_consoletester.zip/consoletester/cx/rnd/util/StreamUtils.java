/*
 * Copyright (C) 2002 by Brett Neumeier. All rights reserved.
 */
package cx.rnd.util;

import java.io.*;

public class StreamUtils {
    
    /**
     * Return a String containing all currently-available characters
     * from the input stream, using the default character encoding.
     * 
     * BEWARE:  There is no test for this method.
     */
    public static String readFromStream(InputStream in) throws IOException {
        StringBuffer contents = new StringBuffer();
        Reader source = new InputStreamReader(in);
        while (source.ready()) {
            contents.append((char) source.read());
        }
        return contents.toString();
    }
}