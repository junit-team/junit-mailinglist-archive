package com.medcharge.c3web.test.support;

import java.util.*;
import java.io.*;
import java.lang.reflect.*;

import org.apache.log4j.*;

import junit.framework.*;
import junit.runner.*;

public class TestSuiteBuilder {

	private static Category log = Category.getInstance(TestSuiteBuilder.class);
	
	private static final String EXCLUDED_TESTS = "C:/Program Files/IBM/Application Developer/properties/excludedTests.properties";

	public static TestSuite buildSuite() throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
		
		TestSuite suite = new TestSuite();

		LoadingTestCollector loader = new LoadingTestCollector();
		Enumeration tests = loader.collectTests();
		
		TestCaseClassLoader classLoader = new TestCaseClassLoader();
		String className;
		
		Properties testProperties = new Properties();

		try {
			FileInputStream file = new FileInputStream(new File(EXCLUDED_TESTS));
			testProperties.load(file);
		} catch (Exception e) {
		}
		
		List excludedPackages = getExcludedPackages(testProperties);
		
		while (tests.hasMoreElements()) {
			
			className = (String)tests.nextElement();

			if (isTestExcluded(className, testProperties, excludedPackages)) {
				continue;
			}
			
			Class[] classArgs = new Class[] { String.class };
			Object[] constructorArgs = new Object[] { new String(className) };
			
			Class loadedClass = classLoader.loadClass(className, true);
			java.lang.reflect.Constructor theConstructor = loadedClass.getConstructor(classArgs);
			
			Object theClass = theConstructor.newInstance(constructorArgs);
			
			Method suiteMethod = loadedClass.getDeclaredMethod("suite", new Class[0]);

			suite.addTest((Test)suiteMethod.invoke(theClass, new Class[0]));
		}

		return suite;
	}

	private static List getExcludedPackages(Properties props) {
		
		ArrayList packages = new ArrayList();
		
		String badPackages = props.getProperty("packages");
		
		if (badPackages != null) {
			
			StringTokenizer token = new StringTokenizer(badPackages, ",");
			
			while (token.hasMoreElements()) {
				
				packages.add(token.nextElement());
			}
		}
		
		return packages;
	}
	
	private static boolean isTestExcluded(String name, Properties testProperties, List packages) {

		boolean result = false;

		if (testProperties.containsKey(name)) {
			
			result = true;
		} else {
			
			Iterator packageIterator = packages.iterator();
			
			while (packageIterator.hasNext()) {
				
				if (name.startsWith((String)packageIterator.next())) {
					result = true;
					break;
				}
			}
		}
		
		return result;
	}
}

