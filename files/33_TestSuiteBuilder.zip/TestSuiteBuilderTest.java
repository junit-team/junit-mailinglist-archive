package com.medcharge.c3web.test.support.test;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.framework.Test;
import com.medcharge.c3web.test.support.*;
import java.io.*;
import java.util.*;

import org.apache.log4j.*;

public class TestSuiteBuilderTest extends TestCase {
	
	private static Category log = Category.getInstance(TestSuiteBuilderTest.class);
	private File testDirectory;

	public TestSuiteBuilderTest(String name) {
		super(name);
	}

	public static Test suite(){
		return new TestSuite(TestSuiteBuilderTest.class);
	}
	
	public static void main(String[] args){
		junit.swingui.TestRunner tr = new junit.swingui.TestRunner();
		tr.run(TestSuiteBuilderTest.class);
	}

	public void testSuiteBuilding() {

		try {
			TestSuite test = TestSuiteBuilder.buildSuite();
			
//			assertEquals(431, test.countTestCases());
			Enumeration allTests = test.tests();
			
			assertNotNull(allTests);
			
			while (allTests.hasMoreElements()) {
				
				Test aTest = (Test)allTests.nextElement();
				assertTrue("", aTest.toString().startsWith("com.medcharge"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			fail("Unexpected exception");
		}
	}	
}

