package net.saff.junit.pbm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import junit.framework.JUnit4TestAdapter;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.RunWith;

public class ParameterizedByMethodTest {
	
	@RunWith(ParameterizedByMethod.class) //TODO This shouldn't be called Factory, because it doesn't create anything. "Runner", perhaps?
	static public class FibonacciTest {
		@DataSource(name="seven") public static Object[] data() {
			return new int[][] {{0, 0}, {1, 1}, {2, 1}, {3, 2}, {4, 3}, {5, 5}, {6, 8}};
		}
		
		@Test @FromSource("seven") public void test(int expected, int input) {
			assertEquals(expected, fib(input));
		}

		private int fib(int x) {
			return 0;
		}
	}
	
	@Test public void count() {
		Result runner= JUnitCore.runClasses(FibonacciTest.class);
		assertEquals(7, runner.getRunCount());
		assertEquals(6, runner.getFailureCount());
	}
	
	@RunWith(ParameterizedByMethod.class) 
	static public class FibonacciTestTwoMethods extends FibonacciTest {
		@Test @FromSource("seven") public void theyreEqual(int expected, int input) {
			assertEquals(expected, input);
		}
	}
	
	@Test public void countTwoMethods() {
		Result runner= JUnitCore.runClasses(FibonacciTestTwoMethods.class);
		assertEquals(7 + 7, runner.getRunCount());
		assertEquals(6 + 4, runner.getFailureCount());
	}
	
	@RunWith(ParameterizedByMethod.class) 
	static public class FibonacciTestTwoSources extends FibonacciTest {
		@DataSource(name="five") public static Object[] data() {
			return new int[][] {{0}, {1}, {2}, {3}, {100}};
		}		
		
		@Test @FromSource("five") public void lessThanFour(int input) {
			assertTrue(input < 4);
		}
	}
	
	@Test public void countTwoSources() {
		Result runner= JUnitCore.runClasses(FibonacciTestTwoSources.class);
		assertEquals(7 + 5, runner.getRunCount());
		assertEquals(6 + 1, runner.getFailureCount());
	}	
	
	@Test public void testCountIsCorrect() {
		ParameterizedByMethod pbm = new ParameterizedByMethod();
		pbm.initialize(null, FibonacciTestTwoSources.class);
		assertEquals(7 + 5, pbm.testCount());
	}
	
	static public junit.framework.Test suite() {
		return new JUnit4TestAdapter(ParameterizedByMethodTest.class);
	}
}
