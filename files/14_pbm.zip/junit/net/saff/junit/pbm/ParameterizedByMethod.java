package net.saff.junit.pbm;

import static org.junit.Assert.assertEquals;

import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.List;

import org.junit.runner.Runner;
import org.junit.runner.internal.TestIntrospector;
import org.junit.runner.internal.TestMethodRunner;
import org.junit.runner.internal.TestNotifier;

public class ParameterizedByMethod implements Runner {
	private Class<? extends Object> fTestClass;

	private TestNotifier fNotifier;

	public void initialize(TestNotifier notifier, Class<? extends Object> klass) {
		this.fNotifier = notifier;
		this.fTestClass = klass;
	}

	public int testCount() {
		try {
			int count = 0;
			for (Method eachMethod : pbmTests()) {
				Object parameters = getParametersList(eachMethod);
				count += Array.getLength(parameters);
			}

			return count;
		} catch (Exception e) {
			// TODO: what's right?
			return 0;
		}
		// TODO: what if it's not an array?
	}

	private Object getParametersList(Method eachMethod) throws Exception {
		String sourceName = sourceName(eachMethod);
		Object parameters = getParametersList(sourceName);
		return parameters;
	}

	private List<Method> pbmTests() {
		return new TestIntrospector(fTestClass)
				.getTestMethods(FromSource.class);
	}

	private Object getParametersList(String sourceName) throws Exception {
		return getParametersMethod(sourceName).invoke(null, new Object[0]);
	}

	private Method getParametersMethod(String sourceName) throws Exception {
		Class<? extends Object> clazz = fTestClass;
		while (!clazz.equals(Object.class)) {
			Method parametersMethod = getParametersMethod(sourceName, clazz);
			if (parametersMethod != null)
				return parametersMethod;
			clazz = clazz.getSuperclass();
		}
		throw new Exception("No parameters method named " + sourceName);
	}

	private Method getParametersMethod(String sourceName,
			Class<? extends Object> clazz) {
		for (Method each : clazz.getMethods()) {
			if (Modifier.isStatic(each.getModifiers())) {
				DataSource ann = getAnnotation(each, DataSource.class);
				if (ann != null && ann.name().equals(sourceName))
					return each;
			}
		}
		return null;
	}

	public void run() {
		try {
			for (final Method eachMethod : pbmTests()) {
				Object parameters = getParametersList(eachMethod);
				for (int i = 0; i < Array.getLength(parameters); i++) {
					final Object[] boxed = boxParameters(parameters, i);
					final Object test = createTest();
					TestMethodRunner runner = new TestMethodRunner(test, eachMethod, fNotifier) {
						@Override
						protected void invokeMethod() throws Exception {
							eachMethod.invoke(test, boxed);
						}
					};
					runner.run();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: what to do? Create a Failure
		}
	}

	public <T extends Annotation> T getAnnotation(Method method,
			Class<? extends T> clazz) {
		Annotation[] annotations = method.getAnnotations();
		for (Annotation annotation : annotations) {
			if (annotation.annotationType() == clazz)
				return clazz.cast(annotation);
		}
		return null;
	}

	private String sourceName(Method eachMethod) throws Exception {
		return getAnnotation(eachMethod, FromSource.class).value();
	}

	private Object[] boxParameters(Object parameters, int i) {
		Object parameters1 = Array.get(parameters, i);
		final Object[] boxed = new Object[Array.getLength(parameters1)];
		for (int i1 = 0; i1 < Array.getLength(parameters1); i1++)
			boxed[i1] = Array.get(parameters1, i1);
		return boxed;
	}

	private Object createTest() throws Exception {
		// TODO I'd prefer to look at the runtime types of the parameters and
		// find a matching constructor, but I can't figure out how to fetch the
		// actual types
		// Instead, this will only work with test classes that have a single
		// constructor
		Constructor[] constructors = fTestClass.getConstructors();
		assertEquals(1, constructors.length);
		Constructor constructor = constructors[0];
		Object test = constructor.newInstance();
		return test;
	}
}
