package junit.extensions;

public class ThisIsNotReallyATest
{
    public void testNotReallyATest() {}
}