package junit.extensions;

import java.io.File;
import java.io.FileFilter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import junit.framework.TestCase;
import junit.framework.TestSuite;

public class AllTestsTestSuiteFactory
{
    final FileFilter DIRECTORY_FILE_FILTER = new FileFilter()
	{
	    public boolean accept( File file )
	    {
	        return file.isDirectory() && !( file.getName().equals( "." ) || file.getName().equals( ".." ) );
	    }
	};

    private FileFilter testClassFileFilter;

    private Set testCaseClassNames = new HashSet();

    public AllTestsTestSuiteFactory( File classfileRootDirectory, FileFilter testClassFileFilter )
    {
        if ( !classfileRootDirectory.isDirectory() )
        {
            throw new IllegalArgumentException( classfileRootDirectory + " is not a directory" );
        }
        this.testClassFileFilter = testClassFileFilter;
        testCaseClassNames = new HashSet();
        findTestClassNames( classfileRootDirectory, "" );
    }

    public TestSuite buildTestSuite()
    {
        ClassLoader classLoader = getClass().getClassLoader();
        TestSuite suite = new TestSuite();
        try
        {
            for ( Iterator iter = testCaseClassNames.iterator(); iter.hasNext(); )
            {
                Class loadedClass = classLoader.loadClass( (String) iter.next() );
                if ( TestCase.class.isAssignableFrom( loadedClass ) )
                {
                    suite.addTestSuite( loadedClass );
                }
            }
        }
        catch ( ClassNotFoundException e )
        {
            throw new NoClassDefFoundError( e.getMessage() );
        }
        return suite;
    }

    private void findTestClassNames( File startingDir, String packageName )
    {
        File[] filesHere = startingDir.listFiles( testClassFileFilter );

        for ( int i = 0; i < filesHere.length; i++ )
        {
            testCaseClassNames.add( calculateFullyQualifiedClassName( packageName, filesHere[ i ].getName() ) );
        }

        File[] subdirectories = startingDir.listFiles( DIRECTORY_FILE_FILTER );

        for ( int i = 0; i < subdirectories.length; i++ )
        {
            findTestClassNames( subdirectories[ i ], buildDottedName( packageName, subdirectories[ i ].getName() ) );
        }
    }

    Set getTestCaseClassNames()
    {
        return testCaseClassNames;
    }

    static String calculateFullyQualifiedClassName( String packageName, String fileName )
    {
        String className = fileName.substring( 0, fileName.length() - 6 );
        return buildDottedName( packageName, className );
    }

    static String buildDottedName( String parentNameString, String childNameSegment )
    {
        if ( parentNameString.length() > 0 )
        {
            return parentNameString + "." + childNameSegment;
        }
        return childNameSegment;
    }
}