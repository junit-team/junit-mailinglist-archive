package junit.extensions;

import java.io.File;
import java.io.FileFilter;
import java.util.Enumeration;
import java.util.Set;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class AllTestsTestSuiteFactoryTest extends TestCase
{
    private static final int TEST_METHODS_IN_THIS_CLASS = 5;

    final FileFilter TEST_CLASS_FILE_FILTER = new FileFilter()
    {
        public boolean accept( File file )
        {
            return file.getName().endsWith( "Test.class" );
        }
    };

	private static final File SRC_DIRECTORY = new File( "src" );

    private static final File BIN_DIRECTORY = new File( "bin" );

    private static final File EXTENSIONS_DIRECTORY = new File( "bin\\junit\\extensions\\" );

    private AllTestsTestSuiteFactory srcDirectoryFactory;

    protected void setUp() throws Exception
    {
        super.setUp();
        srcDirectoryFactory = new AllTestsTestSuiteFactory( SRC_DIRECTORY, TEST_CLASS_FILE_FILTER );
    }

    public void testBadDirectory()
    {
        try
        {
            new AllTestsTestSuiteFactory( new File( "Gooaragaaaah" ), TEST_CLASS_FILE_FILTER );
            fail( "Expected IllegalArgumentException" );
        }
        catch ( IllegalArgumentException e )
        {
            assertEquals( "Gooaragaaaah is not a directory", e.getMessage() );
        }
    }

    public void testBuildDottedName()
    {
        assertEquals( "bar", AllTestsTestSuiteFactory.buildDottedName( "", "bar" ) );
        assertEquals( "foo.bar", AllTestsTestSuiteFactory.buildDottedName( "foo", "bar" ) );
        assertEquals( "foo.bar.baz", AllTestsTestSuiteFactory.buildDottedName( "foo.bar", "baz" ) );
    }

    public void testFullyQualifiedClassName()
    {
        assertEquals( "Foo", AllTestsTestSuiteFactory.calculateFullyQualifiedClassName( "", "Foo.class" ) );
        assertEquals( "bleah.Bar", AllTestsTestSuiteFactory.calculateFullyQualifiedClassName( "bleah", "Bar.class" ) );
        assertEquals( "junit.extensions.AllTestsTestSuiteFactoryTest", AllTestsTestSuiteFactory.calculateFullyQualifiedClassName( "junit.extensions", "AllTestsTestSuiteFactoryTest.class" ) );
    }

    public void testSubdirectoryFileFilter()
    {
        assertFalse( srcDirectoryFactory.DIRECTORY_FILE_FILTER.accept( new File( "Bleah.class" ) ) );
        assertFalse( srcDirectoryFactory.DIRECTORY_FILE_FILTER.accept( new File( "build.xml" ) ) );
        assertFalse( srcDirectoryFactory.DIRECTORY_FILE_FILTER.accept( new File( "." ) ) );
        assertFalse( srcDirectoryFactory.DIRECTORY_FILE_FILTER.accept( new File( ".." ) ) );
        assertTrue( srcDirectoryFactory.DIRECTORY_FILE_FILTER.accept( SRC_DIRECTORY ) );
    }

    public void testFindTests()
    {
        Set testCaseClassNames = srcDirectoryFactory.getTestCaseClassNames();
        assertNotNull( testCaseClassNames );
        assertEquals( 0, testCaseClassNames.size() );

        AllTestsTestSuiteFactory testDirectoryFactory = new AllTestsTestSuiteFactory( EXTENSIONS_DIRECTORY, TEST_CLASS_FILE_FILTER );

        testCaseClassNames = testDirectoryFactory.getTestCaseClassNames();
        assertNotNull( testCaseClassNames );
        assertEquals( 2, testCaseClassNames.size() );
        assertTrue( testCaseClassNames.contains( "AllTestsTestSuiteFactoryTest" ) );
        assertTrue( testCaseClassNames.contains( "ThisIsNotReallyATest" ) );

        try
        {
            testDirectoryFactory.buildTestSuite();
            fail("Expected NoClassDefFoundError -- class root directory improperly specified");
        }
        catch ( NoClassDefFoundError e )
        {
            String msg = e.getMessage();
            assertTrue( msg.equals( "AllTestsTestSuiteFactoryTest" ) || msg.equals( "ThisIsNotReallyATest" ) );
        }

        AllTestsTestSuiteFactory binDirectoryFactory = new AllTestsTestSuiteFactory( BIN_DIRECTORY, TEST_CLASS_FILE_FILTER );

        testCaseClassNames = binDirectoryFactory.getTestCaseClassNames();
        assertNotNull( testCaseClassNames );
        assertTrue( testCaseClassNames.size() >= 2 );
        assertTrue( testCaseClassNames.contains( "junit.extensions.AllTestsTestSuiteFactoryTest" ) );
        assertTrue( testCaseClassNames.contains( "junit.extensions.ThisIsNotReallyATest" ) );

        TestSuite suite = binDirectoryFactory.buildTestSuite();
        assertTrue( suite.countTestCases() >= TEST_METHODS_IN_THIS_CLASS );

        Enumeration testSuiteEnum = suite.tests();
        while ( testSuiteEnum.hasMoreElements() )
        {
            TestSuite thisSuite = (TestSuite) testSuiteEnum.nextElement();
            Enumeration testEnum = thisSuite.tests();
            while ( testEnum.hasMoreElements() )
            {
                Test thisTest = (Test) testEnum.nextElement();
                // System.out.println( thisTest );
                if ( thisTest.toString().startsWith( "warning" ) )
                {
                    fail( "Should have ignored ThisIsNotReallyATest.class as it does not extend TestCase" );
                }
            }
        }
    }
}