package yaps.users.jdbc;

import java.sql.*;

import junit.framework.TestCase;

public class SampleDatabaseTest extends TestCase {
	private static final String USER_NAME = "user 1";

	private MockDataSource mockDataSource;

	protected void setUp() {
		mockDataSource = new MockDataSource();
	}

	protected void tearDown() throws SQLException {
		mockDataSource.clear();
	}

	public void testCreate() throws SQLException {
		mockDataSource.expectAllConnectionsClosed();
		SampleDatabase db = new SampleDatabase(mockDataSource);
		db.createUser(USER_NAME);
		mockDataSource.verify();
		assertUserExists();
	}

	private void assertUserExists() throws SQLException {
		Connection conn = mockDataSource.getConnection();
		Statement statement = conn.createStatement();
		ResultSet rs = statement.executeQuery("select * from user");
		assertTrue(rs.next());
		assertEquals(USER_NAME, rs.getString("name"));
	}
}
