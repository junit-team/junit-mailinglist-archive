package yaps.users.jdbc;

import java.io.*;
import java.sql.*;
import java.util.*;

import javax.sql.DataSource;

import junit.framework.*;

import com.mockobjects.*;

/**
 * @author john.link@gmx.net
 * (c) 2003 by Johannes Link 
 * 
 * This class provides a mock implementation for javax.sql.DataSource
 * It requires hsqldb (www.hsqldb.org) to be availabe in the class path.
 * The mock objects library (www.mockobjects.com) is being used.
 * 
 * @see MockDataSourceTest for examples of usage 
 */
public class MockDataSource extends MockObject implements DataSource {

	private static final String DB_DRIVER_CLASS = "org.hsqldb.jdbcDriver";
	private static final String DB_URL_PREFIX = "jdbc:hsqldb:";
	private static final String DB_USER = "sa";
	private static final String DB_PASSWORD = "";
	private static final String TESTDB_NAME = "testdb";

	private List connections = new ArrayList();
	private boolean allConnectionsShouldBeClosed = false;
	private boolean noConnectionsShouldBeClosed;
	private ExpectationCounter getConnectionCalls =
		new ExpectationCounter("MockDataSource.getConnection()");

	interface ConnectionTester {
		boolean test(Connection connection) throws SQLException;
	}

	public Connection getConnection() throws SQLException {
		try {
			Class.forName(DB_DRIVER_CLASS);
		} catch (ClassNotFoundException cnfe) {
			throw new RuntimeException(cnfe);
		}
		Connection newConnection =
			DriverManager.getConnection(getDbUrl(), DB_USER, DB_PASSWORD);
		connections.add(newConnection);
		getConnectionCalls.inc();
		return newConnection;
	}

	private String getDbUrl() {
		return DB_URL_PREFIX + TESTDB_NAME;
	}

	public Connection getConnection(String username, String password)
		throws SQLException {
		return null;
	}

	public PrintWriter getLogWriter() throws SQLException {
		return null;
	}

	public void setLogWriter(PrintWriter out) throws SQLException {
	}

	public void setLoginTimeout(int seconds) throws SQLException {
	}

	public int getLoginTimeout() throws SQLException {
		return 0;
	}

	public void verify() {
		super.verify();
		if (allConnectionsShouldBeClosed) {
			verifyAllConnectionsClosed();
		}
		if (noConnectionsShouldBeClosed) {
			verifyNoConnectionsClosed();
		}
	}

	private void verifyAllConnectionsClosed() throws AssertionFailedError {
		ConnectionTester isClosedTester = new ConnectionTester() {
			public boolean test(Connection connection) throws SQLException {
				return connection.isClosed();
			}
		};
		verifyAllConnections(isClosedTester, "Unexpected open connections");
	}

	private void verifyNoConnectionsClosed() throws AssertionFailedError {
		ConnectionTester notClosedTester = new ConnectionTester() {
			public boolean test(Connection connection) throws SQLException {
				return !connection.isClosed();
			}
		};
		verifyAllConnections(notClosedTester, "Unexpected open connections");
	}

	private void verifyAllConnections(
		ConnectionTester tester,
		String failureText)
		throws AssertionFailedError {
		Iterator i = connections.iterator();
		int countConnectionsWithTestFailure = 0;
		while (i.hasNext()) {
			Connection each = (Connection) i.next();
			try {
				if (!tester.test(each)) {
					countConnectionsWithTestFailure++;
				}
			} catch (SQLException e) {
				throw new AssertionFailedError("Unexpected exception: " + e);
			}
			Assert.assertEquals(
				failureText,
				0,
				countConnectionsWithTestFailure);
		}
	}

	public void clear() throws SQLException {
		closeAllConnections();
		deleteAllHsqlFiles();
	}

	private void deleteAllHsqlFiles() {
		File[] filesToDelete = new File(".").listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.startsWith(TESTDB_NAME);
			}
		});
		for (int j = 0; j < filesToDelete.length; j++) {
			filesToDelete[j].delete();
		}
	}

	private void closeAllConnections() throws SQLException {
		Iterator i = connections.iterator();
		while (i.hasNext()) {
			Connection each = (Connection) i.next();
			each.close();
		}
	}

	public void expectAllConnectionsClosed() {
		allConnectionsShouldBeClosed = true;
		noConnectionsShouldBeClosed = false;
	}

	public void expectGetConnectionCalls(int expectedCalls) {
		getConnectionCalls.setExpected(expectedCalls);
	}

	public void expectNoConnectionsClosed() {
		allConnectionsShouldBeClosed = false;
		noConnectionsShouldBeClosed = true;
	}
}
