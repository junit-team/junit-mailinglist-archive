package yaps.users.jdbc;

import java.sql.*;
import java.sql.Connection;

import javax.sql.DataSource;

public class SampleDatabase {

	private DataSource dataSource;

	public SampleDatabase(DataSource dataSource) throws SQLException {
		this.dataSource = dataSource;
		createUserTable();
	}

	private void createUserTable() throws SQLException {
		Connection conn = dataSource.getConnection();
		Statement statement = conn.createStatement();
		statement.executeUpdate("create table user (name varchar(32))");
		conn.close();
	}

	public void createUser(String name) throws SQLException {
		Connection conn = dataSource.getConnection();
		Statement statement = conn.createStatement();
		statement.executeUpdate("insert into user values ('" + name + "')");
		conn.close();
	}

}
