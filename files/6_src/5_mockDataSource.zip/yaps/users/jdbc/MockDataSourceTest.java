package yaps.users.jdbc;

import java.sql.*;

import junit.framework.*;

/**
 * @author john.link@gmx.net
 * (c) 2003 by Johannes Link 
 * 
 * This class provides the test suite for MockDataSource. 
 * It requires hsqldb (www.hsqldb.org) to be availabe in the class path.
 * The tests create temporary files in the current working directory
 * which should be removed after the tests are run.
 * 
 * @see MockDataSource 
 */
public class MockDataSourceTest extends TestCase {

	private static final String TEST_TABLE = "test";
	private static final String TEST_COLUMN = "id";
	private static final int TEST_VALUE = 123456;

	private MockDataSource dataSource;

	public MockDataSourceTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		dataSource = new MockDataSource();
	}

	protected void tearDown() throws Exception {
		dataSource.clear();
	}

	public void testSingleConnection() throws Exception {
		Connection conn = dataSource.getConnection();
		insertTestData(conn);
		assertTestDataPresent(conn);
		conn.close();
	}

	public void testTwoConnections() throws Exception {
		Connection conn = dataSource.getConnection();
		insertTestData(conn);
		conn.close();
		Connection conn2 = dataSource.getConnection();
		assertNotSame(conn, conn2);
		assertTestDataPresent(conn2);
		conn2.close();
	}

	public void testVerifyWithoutExpectations() throws Exception {
		dataSource.getConnection();
		dataSource.verify();
	}

	public void testVerifyAllConnectionsClosed() throws Exception {
		dataSource.expectAllConnectionsClosed();
		dataSource.getConnection().close();
		dataSource.getConnection().close();
		dataSource.verify();
	}

	public void testVerifyAllConnectionsClosedFails() throws Exception {
		dataSource.expectAllConnectionsClosed();
		dataSource.getConnection().close();
		dataSource.getConnection();
		assertVerifyFailure();
	}

	public void testVerifyNoConnectionsClosed() throws Exception {
		dataSource.expectNoConnectionsClosed();
		dataSource.getConnection();
		dataSource.getConnection();
		dataSource.verify();
	}

	public void testVerifyNoConnectionsClosedFails() throws Exception {
		dataSource.expectNoConnectionsClosed();
		dataSource.getConnection();
		dataSource.getConnection().close();
		assertVerifyFailure();
	}

	public void testVerifyCallsToGetConnection() throws Exception {
		dataSource.expectGetConnectionCalls(2);
		dataSource.getConnection();
		dataSource.getConnection();
		dataSource.verify();
	}

	public void testVerifyCallsToGetConnectionFails() throws Exception {
		dataSource.expectGetConnectionCalls(2);
		dataSource.getConnection();
		assertVerifyFailure();
	}

	public void testClear() throws Exception {
		dataSource.expectAllConnectionsClosed();
		dataSource.getConnection().close();
		dataSource.getConnection();
		dataSource.clear();
		dataSource.verify();
		assertTestTableNotPresent(dataSource.getConnection());
	}

	private void insertTestData(Connection connection) throws SQLException {
		Statement statement = connection.createStatement();
		statement.executeUpdate(
			"create table "
				+ TEST_TABLE
				+ " ("
				+ TEST_COLUMN
				+ " varchar(12) primary key)");
		int count =
			statement.executeUpdate(
				"insert into " + TEST_TABLE + " values('" + TEST_VALUE + "')");
		assertEquals(1, count);
		statement.close();
	}

	private void assertVerifyFailure() {
		try {
			dataSource.verify();
			fail("AssertionFailedError expected");
		} catch (AssertionFailedError expected) {
			assertTrue(
				"verify() should have failed",
				!expected.getMessage().startsWith(
					"AssertionFailedError expected"));
		}
	}

	private void assertTestDataPresent(Connection connection)
		throws SQLException {
		Statement statement = connection.createStatement();
		ResultSet result =
			statement.executeQuery("select * from " + TEST_TABLE);
		assertTrue(result.next());
		assertEquals(TEST_VALUE, result.getInt(TEST_COLUMN));
		statement.close();
	}

	private void assertTestTableNotPresent(Connection connection)
		throws SQLException {
		Statement statement = connection.createStatement();
		try {
			statement.executeQuery("select * from " + TEST_TABLE);
			fail("SQLException expected");
		} catch (SQLException expected) {
		}
		statement.close();
	}
}
