package junit.extensions;

import java.util.*;
import java.lang.reflect.*;
import junit.framework.*;

/**
 * Responsible for loading classes representing valid test cases.  The constructor
 * takes an iterator that contains a list of fully qualified class names, usually
 * the output from the ClassFinder.getClasses method.  This class will locate
 * all classes that are valid TestCases's.
 *
 * @author Andy Schneider (andy.schneider@javaworld.com)
 * @author Matt Di Iorio (doo@pobox.com)
 */
public class TestCaseLoader {
    final private Vector classList = new Vector ();
    final private String requiredType;

    /**
     * Load the classes that represent test cases we are interested.
     * @param classNamesIterator An iterator over a collection of fully qualified class names
     */
    public void loadTestCases (final Iterator classNamesIterator) {
        while (classNamesIterator.hasNext ()) {
            String className = (String)classNamesIterator.next ();
            try {
                Class candidateClass = Class.forName (className);
                addClassIfTestCase (candidateClass);
            } catch (ClassNotFoundException e) {
                System.err.println ("Cannot load class: " + className + " " + e.getMessage ());
            } catch (NoClassDefFoundError e) {
                System.err.println ("Cannot load class that " + className + " is dependant on");
            }
        }
    }

    /**
     * Construct this instance. Load all the test cases possible that derive
     * from <code>baseClass</code> and cannot be ignored.
     * @param classNamesIterator An iterator over a collection of fully qualified class names
     */
    public TestCaseLoader(final String requiredType) {
        this.requiredType = requiredType;
    }

    /**
     * Obtain an iterator over the collection of test case classes loaded by <code>loadTestCases</code>
     */
    public Iterator getClasses () {
        return classList.iterator ();
    }

    /**
     * Adds <code>testCaseClass</code> to the list of classdes
     * if the class is a test case we wish to load. Calls
     * <code>shouldLoadTestCase ()</code> to determine that.
     */
    private void addClassIfTestCase (final Class testCaseClass) {
        // To be included, a class must:
        // - be public
        // - be a subclass of TestCase
        // - not be abstract
        // - have public test methods
        // - if a test type is specified, it must have the correct test type
        if (Modifier.isPublic(testCaseClass.getModifiers()) == true &&
            TestCase.class.isAssignableFrom(testCaseClass) &&
            Modifier.isAbstract(testCaseClass.getModifiers()) == false &&
            hasPublicTestMethods(testCaseClass) &&
            correctTestType(testCaseClass, this.requiredType)) {

            // this class is in.. add it to the list
            classList.add (testCaseClass);
        }
    }

    // XXX: the following two methods are copied from TestSuite.
    // As we all know, copying code is BAD.  But, the methods are private
    // in TestSuite, so I had no choice.  It would be nice to have a
    // public static isPublicTestMethod in TestSuite so we could keep
    // the two in sync.

    /**
     * Taken from junit.framework.TestSuite
     */
    private boolean hasPublicTestMethods(final Class testCaseClass) {
        Method methods[] = testCaseClass.getDeclaredMethods();
        for (int i = 0; i < methods.length; i++) {
            Method method = methods[i];
            if (isTestMethod(method) &&
                Modifier.isPublic(method.getModifiers())) {
                return true;
            }
        }

        return false;
     }

    /**
     * Taken from junit.framework.TestSuite
     */
    private boolean isTestMethod(Method m) {
        String name= m.getName();
        Class[] parameters= m.getParameterTypes();
        Class returnType= m.getReturnType();
        return parameters.length == 0 && name.startsWith("test") && returnType.equals(Void.TYPE);
    }

    /**
     * Check if the specified string matches the test type of this
     * class.  If no test type is specified, then this method will
     * return true for only those classes that do not have a test
     * type.  That means that creating a TestFinderSuite with no
     * test type will only find those classes that do not have a
     * test type defined.
     */
    private boolean correctTestType (final Class testCaseClass, final String testType) {
        String testCaseTestType = getTestType(testCaseClass);

        if(testType == null) {
            if(testCaseTestType == null) {
                return true;
            } else {
                return false;
            }
        } else if(testType.equals(testCaseTestType)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Extract the test type from the specified class by looking for a
     * static member called 'TEST_FINDER_TEST_TYPE'.
     */
    private String getTestType(final Class testCaseClass) {
        try {
            Field testAllIgnoreThisField = testCaseClass.getDeclaredField("TEST_FINDER_TEST_TYPE");
            final int EXPECTED_MODIFIERS = Modifier.STATIC | Modifier.PUBLIC | Modifier.FINAL;
            if (((testAllIgnoreThisField.getModifiers() & EXPECTED_MODIFIERS) != EXPECTED_MODIFIERS) ||
                (testAllIgnoreThisField.getType() != String.class)) {
                throw new IllegalArgumentException ("TEST_FINDER_TEST_TYPE should be static public final String");
            }
            String testType = (String)testAllIgnoreThisField.get(testCaseClass);

            return testType;
        } catch (NoSuchFieldException e) {
        } catch (IllegalAccessException e) {
            throw new IllegalArgumentException ("The field " + testCaseClass.getName () + ".TEST_FINDER_TEST_TYPE is not accessible.");
        }

        return null;
    }
}