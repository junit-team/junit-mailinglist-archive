package junit.extensions;

import junit.framework.TestSuite;
import junit.framework.TestCase;
import junit.framework.Test;
import java.util.Iterator;
import java.util.Enumeration;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.io.IOException;
import java.io.File;

/**
 * This class is used to automatically search for the classpath for
 * subclasses of the <code>TestCase</code> class.  Any classes that
 * are subclasses of <code>TestCase</code> and have public test methods
 * are added to this <code>TestSuite</code>.  The user can limit
 * the package from which the <code>TestCases</code> are loaded by
 * specifying a root package.  If a root package is specified only
 * tests that are in that package or a package 'underneath' that
 * package are included in the <code>TestSuite</code>.
 * <p>
 * This is an example of using the <code>TestFinderSuite</code> to run
 * all the tests in the com.foo.tests package:
 * <pre>
 *     junit.textui.TestRunner.run( new TestFinderSuite( "com.foo.tests" ) );
 * </pre>
 * You can also specify a test type when creating a
 * <code>TestFinderSuite</code>.  This can be used to run different
 * types of tests, like performance or load tests.
 * <p>
 * To mark a test as a certain type place a static, public, final
 * String called 'TEST_FINDER_TEST_TYPE' in the test class and assign
 * it a value indicating the type of test.  Then create a
 * <code>TestFinderSuite</code> with the test type.
 *
 * <pre>
 * public class FooTest extends TestCase {
 *     static public final String TEST_FINDER_TEST_TYPE = "UnitTest";
 *     ...
 * }
 * </pre>
 * Then create a <code>TestFinderSuite</code>
 * <pre>
 *     junit.textui.TestRunner.run(
 *         new TestFinderSuite( "com.foo.tests", "UnitTest" ) );
 * </pre>
 * <p>
 * Note that creating a TestFinderSuite with no test type will only
 * find tests that do not have a test type.  A TestFinderSuite with
 * no test type will not find all tests in the specified packages,
 * just those with no test type.
 * <p>
 * Known problems:
 * <ul>
 * <li>The TestFinderSuite will pickup ANY subclass of TestCase that
 *     has a public method that starts with 'test'.  If you have
 *     subclasses of TestCase that should not be executed directly
 *     either make them abstract or use test types to filter your tests.
 * </ul>
 * <p>
 * History:<br><br>
 * The original code and idea came from the TestAll utility by Andy
 * Schneider.  The code for the TestAll utility appeared in this
 * <a href="http://www.javaworld.com/javaworld/jw-12-2000/jw-1221-junit.html">JavaWorld article</a>.
 *
 * @author Andy Schneider (andy.schneider@javaworld.com)
 * @author Matt Di Iorio (doo@pobox.com)
 */
public class TestFinderSuite extends TestSuite {
    /**
     * Creates a <code>TestSuite</code> that contains all the <code>TestCases</code>'s that
     * are in the given package or in a sub-package of the given package.
     *
     * @param rootPackage The root package from which all TestCases's are loaded.  To load
     *   all tests in the classpath, set this to "".
     */
    public TestFinderSuite(final String rootPackage) {
        addAllTests(rootPackage, null);
    }

    /**
     * Creates a <code>TestSuite</code> that contains all the <code>TestCases</code>'s that
     * are in the given package or in a sub-package of the given package and are of the
     * given type.
     *
     * @param rootPackage The root package from which all TestCases's are loaded.  To load
     *   all tests in the classpath, set this to "".
     * @param testType A string indicating the type of tests that should be included in this
     *   suite.
     */
    public TestFinderSuite(final String rootPackage, final String testType) {
        addAllTests(rootPackage, testType);
    }

    /**
     * Iterates over the classes accessible via the iterator and adds them to the test suite.
     */
    private int addAllTests(final String rootPackage, final String testType) {
        try {
            ClassFinder classFinder = new ClassFinder (rootPackage);
            TestCaseLoader testCaseLoader = new TestCaseLoader (testType);
            testCaseLoader.loadTestCases (classFinder.getClasses ());
            Iterator classIterator = testCaseLoader.getClasses ();

            int testClassCount = 0;
            while (classIterator.hasNext ()) {
                Class testCaseClass = (Class)classIterator.next ();
                try {
                    Method suiteMethod = testCaseClass.getMethod("suite", new Class[0]);
                    Test test = (Test)suiteMethod.invoke(null, new Class[0]); // static method
                    addTest (test);
                } catch (NoSuchMethodException e) {
                    addTest (new TestSuite (testCaseClass));
                } catch (Exception e) {
                    addTest (warning ("Failed to execute suite()"));
                    e.printStackTrace ();
                }

                testClassCount++;
            }
            return testClassCount;
        } catch (IOException e) {
            addTest(warning("Caught IOException while create suite: " + e + "\nNo tests will be added"));
            return 0;
        }
    }

    /**
     * Utility method that inserts a warning into the suite.  I would have used the one defined
     * in TestSuite, but it's private, not protected.
     */
    private Test warning(final String message) {
        return new TestCase("warning") {
            protected void runTest() {
                fail(message);
            }
        };
    }
}