package junit.extensions;

import java.util.*;
import java.io.*;
import java.util.zip.ZipFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;

/**
 * This class is responsible for searching the classpath and compiling a list of
 * non-inner classe.  It will search directories, jar files and zip files.  It builds
 * a list of fully qualified class names from the class files in the directory tree.
 *
 * @author Andy Schneider (andy.schneider@javaworld.com)
 * @author Matt Di Iorio (doo@pobox.com)
 */
public class ClassFinder {
    final private Vector classNameList = new Vector ();
    final private String packageRoot;

    final private static int CLASS_EXTENSION_LENGTH = 6;

    /**
     * Construct the class finder and locate all the classes in the directory structured
     * pointed to by <code>classPathRoot</code>. Only classes in the package <code>packageRoot</code>
     * are considered.
     */
    public ClassFinder(final String packageRoot) throws IOException {
        this.packageRoot = packageRoot;

        List elemList = elementsInClassPath();
        for (Iterator i = elemList.iterator(); i.hasNext();) {
            Object elem = i.next();
            if (elem instanceof File) {
                File dir = (File) elem;
                int startPackageIndex = dir.getAbsolutePath().length() + 1;
                findAndStoreTestClassesFromDir (dir, startPackageIndex);
            } else if (elem instanceof ZipFile) {
                findAndStoreTestClassesFromZip((ZipFile) elem);
            }
        }
    }

    /**
     * Return the found classes.
     */
    public Iterator getClasses () {
        return classNameList.iterator ();
    }

    private List elementsInClassPath() {
        String classPath = System.getProperty("java.class.path", ".");
        StringTokenizer strTok = new StringTokenizer (classPath, File.pathSeparator);

        ArrayList elemList = new ArrayList();
        while (strTok.hasMoreTokens()) {
            String pathElem = strTok.nextToken();
            File elemAsFile = new File (pathElem);
            if (elemAsFile.isDirectory()) {
                elemList.add (elemAsFile);
            } else if (isZipOrJarFile (elemAsFile)) {
                try {
                    elemList.add (new ZipFile (elemAsFile));
                } catch (ZipException e) {
                } catch (IOException e) {
                    // ignore it, just don't add the file
                }
            }
        }

        return elemList;
    }

    /**
     * This method runs down the directory structure looking for java classes.
     */
    private void findAndStoreTestClassesFromDir (final File currentDirectory, final int startPackageIndex) throws IOException {
        String files[] = currentDirectory.list();
        for(int i = 0; i < files.length; i++) {
            File file = new File (currentDirectory, files[i]);
            if (file.isDirectory()) {
                findAndStoreTestClassesFromDir (file, startPackageIndex);
            } else {
                String className = computeClassName(file.getAbsolutePath(), startPackageIndex);
                if (isValidClass(className)) {
                    classNameList.add(className);
                }
            }
        }
    }

    /**
     * This method examines a .zip or .jar file and pulls out all the valid classes.
     */
    private void findAndStoreTestClassesFromZip (final ZipFile zipFile) {
        Enumeration files = zipFile.entries();
        while (files.hasMoreElements()) {
            ZipEntry file = (ZipEntry) files.nextElement();
            String className = computeClassName(file.getName(), 0);
            if (isValidClass(className)) {
                classNameList.add (className);
            }
        }
    }

    private boolean isZipOrJarFile (File file) {
        String fileNameAsLower = file.getName().toLowerCase();
        if (file.isFile() && (fileNameAsLower.endsWith(".zip") || fileNameAsLower.endsWith(".jar"))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * A class is valid as long as it's not an inner class and it's package starts with packageRoot.
     */
    private boolean isValidClass (String className) {
        if (className == null) {
            return false;
        }

        if (className.startsWith(packageRoot) && className.indexOf("$") == -1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Given a file name, guess the fully qualified class name.
     */
    private String computeClassName (final String filename, final int startPackageIndex) {
        if (filename.endsWith(".class") == false) {
            return null;
        }

        String packageBase = filename;

        // for platform
        packageBase = filename.replace (File.separatorChar, '.');
        // for .jar files
        packageBase = packageBase.replace('/', '.');

        String className = packageBase.substring (startPackageIndex, packageBase.length () - CLASS_EXTENSION_LENGTH);
        return className;
    }
}