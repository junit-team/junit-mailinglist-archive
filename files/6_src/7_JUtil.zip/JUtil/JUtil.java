/**
 * This class is an utility for generating
 * the test class for a specfied production class
 *
 * @author    Hariprakash K S
 * @version   10/10/2001
 */


import junit.framework.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

/*
*   How to Use: java JUtil arg1 arg2 arg3
*				arg1 = smf.portfolio.PORT_Update_Portfolio(Class for which
*				       the test class to be generated)
*				arg2 = d:\\smf\\portfolio(path where generated
*						 test class to be kept)
*				arg3 = Name of the generated test file without the extension
*/

public  class JUtil
{
	public static PrintWriter pw;
	static String str_classname;
	static String str_directory;
	static String str_filename;
	static String filepath;

/**
* Main method takes the production class as command-line arguments and
* generates a test class
*
* @param			Class, folder where the generated class to be kept,
*					name of the generted class
* @return			Generates the .java file
* @exception	    None
*/

public static void main(String args[])
{

 try
 {
	//For instantiating the class, name which is passed from command line
	Class oTest = Class.forName(args[0]);
	Method oMethod[] =  oTest.getDeclaredMethods();
	str_classname = args[0];
	str_directory = args[1];
	str_filename = args[2];
	//To formulate the name of the file
	filepath = str_directory +"\\" + str_filename  + ".java";

	try {
		//To have a output stream which will write it into a file with 'filepath'
		pw=new PrintWriter((new FileOutputStream(filepath,false)),true);
	} catch(Exception oE) {
		oE.printStackTrace();
	}


	String strDeclaration = "/**\n"+
 	 "* GIve the Project Name here - Give brief Description about functionality of the class\n"+
	 "*\n"+
	 "* @author    Put your name\n"+
	 "* @version   Put today's date\n"+
 	 "*/\n";
	printFile("");printFile("");
	printFile(strDeclaration);

	int li = args[0].lastIndexOf('.');
	String strPackageStmt = args[0].substring(0,li);
	//To put the package declaration for the generated class
	printFile("package " + strPackageStmt + ";");

	//To write all the import statements
	printFile("import junit.framework.*;\nimport java.io.*;\nimport java.util.*;");
	printFile("");printFile("");printFile("");

	printFile("public class "+ str_filename +" extends TestCase{");
	printFile("");

	printFile("\t" + args[0] + " oTestClassInstance;");
	printFile("\tboolean actual;");
	printFile("\n");


	String oAllString = "\t public " + str_filename  + "(String name){\n"
			+ "\t \t \t  super(name);\n\t}\n";

	printFile(oAllString);
	printFile("\t protected void setUp(){");
	printFile("");
	Constructor oConstructor[] =  oTest.getDeclaredConstructors();//+oConstructor[0].getName()
	printFile("\t \t \t oTestClassInstance" + " = new  " + args[0] + "();");
	printFile("\t}");
	printFile("\n");

for(int i = 0; i<oMethod.length; i++){
	int modifiers = oMethod[i].getModifiers();
		/*
		Checking whether the methods in the specified class are
		protected or public if so then only will be called
		in the generated test class
		*/
		if(Modifier.isPublic(modifiers) || Modifier.isProtected(modifiers)){

			String strThrows = oMethod[i].toString();

			String strMethod = "\t//This method must pass, supply the valid data\n"+
			"\t/**\n"+
			"\t* Give brief description about this method\n"+
			"\t*\n"+
			"\t* @param			Give parameter details\n"+
			"\t* @return			Give Return Type details\n"+
			"\t* @exception		Give exception details\n"+
	  		"\t*/\n"+
			"\t public void "+"test"+oMethod[i].getName()+"Good"+"()";

			//To check whether the method is having any exception in throws class.
			if(strThrows.indexOf("throws") > 0)
			{
				strMethod = strMethod + " throws Exception";
			}
			strMethod = strMethod + " {";
			printFile(strMethod);

			//printFile("\t public void "+"test"+oMethod[i].getName()+"Good"+"(){");
			Class oclass[] = oMethod[i].getParameterTypes();

				/**for checking whether any of the method parameters are of type DataHolder
				*  and if so calling the method called createDataHolder method which will create
				*  the object of DataHolder by prompting the user to enter the key value pair
				*/
				boolean blisparam = false;
				for(int l = 0; l<oclass.length; l++ )
				{
					if( (oclass[l].getName()).equals("com.gt.smf.common.DataHolder"))
					{
						blisparam = true;
					}
				}
				if(blisparam)
				{
					/*
					String strcallmethod ="\t \t \tSystem.out.println(\"The method you entered is"+
					" 'test"+oMethod[i].getName()+"Good()', try giving VALID data\");\n"+
					"\t \t \tcreateDataHolder();";
					printFile(strcallmethod);
					*/
				}
			String oStrMethod = "\t \t \tactual = oTestClassInstance."+oMethod[i].getName();
				//To write parameters into the method
				if(oclass.length > 0){
					oStrMethod = oStrMethod + "(" ;
					for(int m = 0; m<oclass.length; m++){

						//* on 11-10-2001
						//To take out the "class" from the parameter
						String str_take_class_out =""+oclass[m];
						str_take_class_out = str_take_class_out.trim();
						int its = str_take_class_out.indexOf("class",0);
						//System.out.println("index of class"+its);
							if(its >= 0)
							{
								str_take_class_out = str_take_class_out.substring(6,str_take_class_out.length());
							}
						//on 11-10-2001*/

						oStrMethod = oStrMethod + str_take_class_out;
						int no_of_args = oclass.length ;
							//for deciding whether to put comma after each and every argument of the method.
							if(no_of_args-(m+1) != 0)
							{
								oStrMethod = oStrMethod + ",";
							}

							//else{oStrMethod = oStrMethod + ");";}
					}
					oStrMethod = oStrMethod + ");";
				}
				else{
					oStrMethod = oStrMethod + "();";
				}
			printFile(oStrMethod);

			printFile("\t \t \tassertTrue(actual == expected);");
			printFile("\t }");
			printFile("");

			String strThrowsBad = oMethod[i].toString();
			//To write equivalent bad method for a method in the production class
			String strMethodBad = "\t//This method must fail, supply the invalid data\n"+

			"\t/**\n"+
			"\t* Give brief description about this method\n"+
			"\t*\n"+
			"\t* @param			Give parameter details\n"+
			"\t* @return			Give Return Type details\n"+
			"\t* @exception		Give exception details\n"+
	  		"\t*/\n"+
			"\t public void "+"test"+oMethod[i].getName()+"Bad"+"()";
			//printFile("\t public void "+"test"+oMethod[i].getName()+"Good"+"()");
			if(strThrowsBad.indexOf("throws") > 0)
			{
				strMethodBad = strMethodBad + " throws Exception";
			}
			strMethodBad = strMethodBad + " {";
			printFile(strMethodBad);


			/**for checking whether any of the method parameters are of type DataHolder
			*  and if so calling the method called createDataHolder method which will create
			*  the object of DataHolder by prompting the user to enter the key value pair
			*/
			boolean blisparambad = false;
			for(int l = 0; l<oclass.length; l++ )
			{
				if( (oclass[l].getName()).equals("com.gt.smf.common.DataHolder"))
				{
					blisparambad = true;
				}
			}
			if(blisparambad)
			{
				/*
				String strcallmethod ="\t \t \tSystem.out.println(\"The method you entered is"+
				" 'test"+oMethod[i].getName()+"Bad()', try giving INVALID data\");\n"+
				"\t \t \tcreateDataHolder();";
				printFile(strcallmethod);
				*/
			}

			String oStrMethod1 = "\t \t \tactual = oTestClassInstance."+oMethod[i].getName();
			//oclass1[] = oMethod[i].getParameterTypes();

				//To write parameters into the method
				if(oclass.length > 0){
					oStrMethod1 = oStrMethod1 + "(" ;
					for(int w = 0; w<oclass.length; w++){


						String str_take_class_out1 =""+oclass[w];
						str_take_class_out1 = str_take_class_out1.trim();
						int its = str_take_class_out1.indexOf("class",0);
						//System.out.println("index of class"+its);
						if(its >= 0)
						{
							str_take_class_out1 = str_take_class_out1.substring(6,str_take_class_out1.length());
						}

						oStrMethod1 = oStrMethod1 + str_take_class_out1;

						int no_of_args_bad = oclass.length ;
							//for deciding whether to put comma after wach and every argument of the method.
							if(no_of_args_bad-(w+1) != 0)
							{
								oStrMethod1 = oStrMethod1 + ",";
							}
					}
					oStrMethod1 = oStrMethod1 + ");";
				}
				else{
					oStrMethod1 = oStrMethod1 + "();";
				}

			printFile(oStrMethod1);

			printFile("\t \t \tassertTrue(actual == expected);");
			printFile("\t }");
			printFile("");

			}

	}
	printFile("}");
	System.out.println("File generated successfully");
   }
	catch(Exception e)
	{
		System.out.println("Exception44444444444"+e);
	}

}

	public static void printFile(String message)
	{
	  try
	  {
		pw.println(message);
	  }
	  catch(Exception oE)
	  {}
	}


}//JUtil

