/*******************************************************************
 * Class Name  : JUtilForPackage
 * Description : This class generates the skeleton structure of
 * a testing class against a production class.
 * Author      : Hariprakash K S
 * Date        : 10/10/01
 * Modified    :
 ********************************************************************/

/*
* How to Use: java JUtilForPackage arg1 arg2
*
*		arg1 = f:\\hari\\help\\Work_on_JUnit\\com
*
*		This is the path till first folder name from where the
*		package structure starts and from where you want generate the
*		test classes for all the class files in the folders and subfolders.
*
*       arg2 = com
*
*		This should be name of the folder from where the package
*		declaration begins.
*/


import junit.framework.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

public  class JUtilForPackage
{
	public static PrintWriter pw;
	static String str_classname;
	static String str_directory;
	static String str_filename;
	static String filepath;
	static String dir;



public static void main(String args[])
{
	dir = args[0];
	String strRemoveRoot =  args[0].substring(4,args[0].length());
	str_directory = dir;
	String strPackageStmt = args[1];
	generateTestClass(dir,strPackageStmt);
}// end of main method

public static void printFile(String message){
		try {
			pw.println(message);
		}
		catch(Exception oE){
		}
}

public static void directory(String dir,String strPackageStmt){
		try
		{
			File objFile = new File (dir);
			String strAllFiles[] = objFile.list();
			for(int k=0;k<strAllFiles.length;k++)
			{
				File objIsDir = new File(dir +"\\"+ strAllFiles[k]);
				if (objIsDir.isDirectory())
				{
					directory(dir+"\\"+strAllFiles[k],strPackageStmt+"."+strAllFiles[k]);
				}
				else
				{
					generateTestClass(dir,strPackageStmt);
				}
			}

		}
		catch(Exception oE){
		}
}


public static void generateTestClass(String dir,String strPackageStmt){
		try
		{


			File objFile = new File (dir);
			String strAllFiles[] = objFile.list();
			for(int k=0;k<strAllFiles.length;k++)
			{

				File objIsDir = new File(dir +"\\"+ strAllFiles[k]);

					if (objIsDir.isDirectory())
					{
						directory(dir+"\\"+strAllFiles[k],strPackageStmt+"."+strAllFiles[k]);
					}
					//if its not a directory then it will generate the Test classes if it is a .class extension file otherwise will not.
					else{



				if((strAllFiles[k].substring(strAllFiles[k].lastIndexOf('.')+1,strAllFiles[k].length()).equals("class")))
				{
					String strClassname = strAllFiles[k].substring(0,strAllFiles[k].lastIndexOf('.'));
					filepath = dir + "\\Test" + strClassname  + ".java";
					str_classname = strClassname;
				try{

					Class oTest= null;
					try{
					oTest = Class.forName(strPackageStmt + "." + str_classname);
					}catch(Exception ed){System.out.println("instance error" + ed);}

				Method oMethod[] =  oTest.getDeclaredMethods();
				try {
					pw=new PrintWriter((new FileOutputStream(filepath,false)),true);
				} catch(Exception oE) {
					oE.printStackTrace();
				}
				printFile("");printFile("");printFile("");
				printFile("package " + strPackageStmt + ";");
				printFile("import junit.framework.*;\nimport java.io.*;\nimport java.util.*;");
				printFile("");printFile("");printFile("");
				printFile("public class Test"+ str_classname +" extends TestCase{");
				printFile("");printFile("");
				printFile("\t" + str_classname + "  obj"+ str_classname + ";");
				printFile("\tboolean actual;");
				printFile("\n");


				String oAllString = "\t public Test" + str_classname  + "(String name){\n"
						+ "\t \t \t  super(name);\n\t}\n";

				printFile(oAllString);
				printFile("\t protected void setUp(){");
				printFile("");
				Constructor oConstructor[] =  oTest.getDeclaredConstructors();//+oConstructor[0].getName()
				printFile("\t \t \t obj"+ str_classname  + " = new  " + str_classname + "();");
				printFile("\t}");
				printFile("\n");


				String strcreateDataHolder = "\tpublic void createDataHolder()\n" +
						"\t{ \n \t \t Vector vtrAll = new Vector();\n" +
						"\t \t try{\n"+
								 "\t \t \t BufferedReader data = new BufferedReader(new InputStreamReader(System.in));\n"+
								 "\t \t \t System.out.println(\"Enter 'stop' to start Testing\");\n"+
								 "\t \t \t int check = 0;\n"+
								 "\t \t \t for(int i = 0; i<100; i++)\n"+
								 "\t \t \t {\n"+
									"\t \t \t \t if(i % 2 == 0){\n"+
											"\t \t \t \t  System.out.println(\"Enter the Key\");\n"+
									"\t \t \t \t }\n"+
									"\t \t\t \t  else{\n"+
											"\t \t \t \t  System.out.println(\"Enter the Value\");\n"+
									"\t \t \t \t }\n"+
									"\t \t \t \t  vtrAll.add(i,data.readLine());\n"+
									"\t \t \t \t  if( ((String)vtrAll.get(i)).equals(\"stop\")) break;\n"+
									"\t \t \t }\n"+
								"\t \t }//end of try\n"+
								"\t \t catch(Exception ex){System.out.println(\"Error at 111111111\"+ex);\n"+
								"\t \t }\n"+
							 "\t \t \t \t int increment = 0;\n"+
							 "\t \t \t \t  for(int p = 0; p<((vtrAll.size()-1)/2);p++)\n"+
							 "\t \t \t \t {\n"+
								 "\t \t \t \t try{\n"+
										"\t \t \t \t objDataHolder.setColumnValue((String)vtrAll.get(increment),vtrAll.get(increment+1));\n"+
										"\t \t \t \t  increment = increment + 2;\n"+
									 "\t \t \t \t }\n"+
									 "\t \t \t \t catch(Exception rf){System.out.println(\"Error at 22222222\"+rf);\n"+
									 "\t \t \t \t  }\n"+
							 "\t \t }\n"+
				"\t }\n";
				//printFile(strcreateDataHolder);
				printFile("\n");
			for(int i = 0; i<oMethod.length; i++){
				int modifiers = oMethod[i].getModifiers();
					if(Modifier.isPublic(modifiers) || Modifier.isProtected(modifiers)){

						String strThrows = oMethod[i].toString();
						String strMethod = "\t public void "+"test"+oMethod[i].getName()+"Good"+"()";
						//printFile("\t public void "+"test"+oMethod[i].getName()+"Good"+"()");
						if(strThrows.indexOf("throws") > 0)
						{
							strMethod = strMethod + " throws Exception";
						}
						strMethod = strMethod + " {";
						printFile(strMethod);

						//printFile("\t public void "+"test"+oMethod[i].getName()+"Good"+"(){");
						Class oclass[] = oMethod[i].getParameterTypes();
							/**for checking whether any of the method parameters are of type DataHolder
							*  and if so calling the method called createDataHolder method which will create
							*  the object of DataHolder by prompting the user to enter the key value pair
							*/

							boolean blisparam = false;
							for(int l = 0; l<oclass.length; l++ )
							{
								if( (oclass[l].getName()).equals("com.gt.smf.common.DataHolder"))
								{
									//System.out.println("entered (Object)oclass[l] instanceof HashMap = "); //+ (Object)oclass[l] instanceof HashMap);
									blisparam = true;
								}
							}
							if(blisparam)
							{
								String strcallmethod ="\t \t \tSystem.out.println(\"The method you entered is"+
								" 'test"+oMethod[i].getName()+"Good()', try giving VALID data\");\n"+
								"\t \t \tcreateDataHolder();";
								printFile(strcallmethod);

							}


						String oStrMethod = "\t \t \tactual =  obj" + str_classname +"."+oMethod[i].getName();


							//To write parameters into the method
							if(oclass.length > 0){
								oStrMethod = oStrMethod + "(" ;
								for(int m = 0; m<oclass.length; m++){

									//* on 11-10-2001
									//To take out the "class" from the parameter
									String str_take_class_out =""+oclass[m];
									str_take_class_out = str_take_class_out.trim();
									int its = str_take_class_out.indexOf("class",0);
									//System.out.println("index of class"+its);
										if(its >= 0)
										{
											str_take_class_out = str_take_class_out.substring(6,str_take_class_out.length());
										}
									//on 11-10-2001*/


									oStrMethod = oStrMethod + str_take_class_out;
									int no_of_args = oclass.length ;
										//for deciding whether to put comma after each and every argument of the method.
										if(no_of_args-(m+1) != 0)
										{
											oStrMethod = oStrMethod + ",";
										}

										//else{oStrMethod = oStrMethod + ");";}
								}
								oStrMethod = oStrMethod + ");";
							}
							else{
								oStrMethod = oStrMethod + "();";
							}
						printFile(oStrMethod);

						printFile("\t \t \tassertTrue(actual == expected);");
						printFile("\t }");
						printFile("");

						//printFile("\t public void "+"test"+oMethod[i].getName()+"Bad"+"(){");
						String strThrowsBad = oMethod[i].toString();
						String strMethodBad = "\t public void "+"test"+oMethod[i].getName()+"Bad"+"()";
						//printFile("\t public void "+"test"+oMethod[i].getName()+"Good"+"()");
						if(strThrowsBad.indexOf("throws") > 0)
						{
							strMethodBad = strMethodBad + " throws Exception";

						}
						strMethodBad = strMethodBad + " {";
						printFile(strMethodBad);




						/**for checking whether any of the method parameters are of type DataHolder
						*  and if so calling the method called createDataHolder method which will create
						*  the object of DataHolder by prompting the user to enter the key value pair
						*/

						boolean blisparambad = false;
						for(int l = 0; l<oclass.length; l++ )
						{

							if( (oclass[l].getName()).equals("com.gt.smf.common.DataHolder"))
							{
								//System.out.println("entered (Object)oclass[l] instanceof HashMap = "); //+ (Object)oclass[l] instanceof HashMap);
								blisparambad = true;
							}
						}
						if(blisparambad)
						{
							String strcallmethod ="\t \t \tSystem.out.println(\"The method you entered is"+
							" 'test"+oMethod[i].getName()+"Bad()', try giving INVALID data\");\n"+
							"\t \t \tcreateDataHolder();";
							printFile(strcallmethod);

						}
						String oStrMethod1 = "\t \t \tactual = obj" + str_classname + "."+oMethod[i].getName();
						//To write parameters into the method
						if(oclass.length > 0){
							oStrMethod1 = oStrMethod1 + "(" ;
							for(int w = 0; w<oclass.length; w++){


								String str_take_class_out1 =""+oclass[w];
								str_take_class_out1 = str_take_class_out1.trim();
								int its = str_take_class_out1.indexOf("class",0);
								//System.out.println("index of class"+its);
								if(its >= 0)
								{
									str_take_class_out1 = str_take_class_out1.substring(6,str_take_class_out1.length());
								}

								oStrMethod1 = oStrMethod1 + str_take_class_out1;

								int no_of_args_bad = oclass.length ;
									//for deciding whether to put comma after wach and every argument of the method.
									if(no_of_args_bad-(w+1) != 0)
									{
										oStrMethod1 = oStrMethod1 + ",";
									}
							}
							oStrMethod1 = oStrMethod1 + ");";
						}
						else{
							oStrMethod1 = oStrMethod1 + "();";
						}
						printFile(oStrMethod1);
						printFile("\t \t \tassertTrue(actual == expected);");
						printFile("\t }");
						printFile("");
						}
					}
					printFile("}");
					System.out.println("File generated successfully");
				}
					catch(Exception e){
					System.out.println("Exception44444444444"+e);
				}
				}//end if checking the .class extension
			}//end of else(that is if this item is not a directory then it will come to this loop)
  }// end of for loop (doing for each item in the folder)
		}
		catch(Exception oE)
		{

		}
	}//end of the method generateTestClass

}//end of the class
