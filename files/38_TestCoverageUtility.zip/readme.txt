This archive contains the freely distributed JFreeChart available from http://www.jrefinery.com and its license and documentation.  It also includes an incomplete documentation for the JUnit test coverage reporting tool ("the Tool").

The classes for the Tool were authored by me, Jason Rogers, for a proof of concept.  I am currently working up beefing up the Tool to make it easier to extend, modify, debug, etc.  THIS RELEASE IS A SPIKE!!!  I hope to make future releases, but who knows.  The Tool was written to work within the Visual Age for Java environment ("VAJ).  It is not intended for any other purpose.  Future releases may be written in such a way to allow this tool to also work with a file system based environment.

To use this with the VAJ tools environment, you will need to do the following after extracting the zip file (where this readme is located):

1. create a project to contain the package "com.t4v.tools" and import the classes from this package
2. include this project in your workspace classpath
    - click Window -> Options -> Resources -> Edit
    - add the project under <VAJ_INSTALL_DIR>/ide/project_resources/<YOUR_PROJECT_NAME>
3. make sure that the following are in the workspace classpath
    - <VAJ_INSTALL_DIR>/ide/project_resources/IBM IDE Utility class libraries
    - <VAJ_INSTALL_DIR>/ide/project_resources/IBM IDE Utility local implementation
4. add a folder to your <VAJ_INSTALL_DIR>/ide/tools directory that corresponds to the project you created in step 1
5. in the folder you created in step 4, add a file called "default.ini" that contains the following text:
    Name=JUnitTestCoverageReport
    Version=0.1.0
    Menu-Items=\
		Test Coverage Report, com.t4v.tools.JUnitTestCoverageReporterLauncher, ;\
		Test Coverage Report, com.t4v.tools.JUnitTestCoverageReporterLauncher, -p;\
		Test Coverage Report, com.t4v.tools.JUnitTestCoverageReporterLauncher, -P;\
6. follow steps 1 and 2 for the JFreeChart classes (in packages com.jrefinery.*)
6. restart VAJ

When you right click on a package or project the context menu under Tools-> should contain a line "Test Coverage Report" that will run the Tool.

If you have any problems, suggestions, or would like to work with me to update the Tool you can contact me at:
chezjesus@hotmail.com (personal email) or jason.rogers@tumbleweed.com (work email, who knows how long it will remain the same, knowing our industry)