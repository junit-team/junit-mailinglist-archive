package com.t4v.tools;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

public class TestCoverageReportUtilityClass {
public TestCoverageReportUtilityClass() {
	
}

/**
 * For a given class (orginalClass) and its associated test class (testClass), 
 * determine which methods belonging to the orginalClass's public interface
 * (those methods with the <code>public</code> modifier) are tested in the testClass.
 *
 * @param originalClass the class that is tested
 * @param testClass the <code>TestCase</code> for originalClass.
 *
 * @return a complex <code>List</code> that contains:
 * <blockquote><pre>
 * a <code>List</code> of methods that are tested
 * a <code>List</code> of methods that are not tested.
 * </pre></blockquote>
 *
 * @see java.util.List
 *
 * @version 0.1.0
 */
public static List findMethodsThatAreAndAreNotTested(Class originalClass, Class testClass) {
	boolean found = false;
	List methodNames = new ArrayList();
	methodNames.add(new ArrayList());
	methodNames.add(new ArrayList());
	
	Method[] testClassMethods = null;
	Method[] originalClassMethods = null;
	List publicInterfaceOfOriginal = new ArrayList();
	
	originalClassMethods = originalClass.getDeclaredMethods();
	testClassMethods = testClass.getDeclaredMethods();
	
	for (int i = originalClassMethods.length-1; i >= 0 ; i--){
		if(Modifier.isPublic(originalClassMethods[i].getModifiers())){
			publicInterfaceOfOriginal.add(0, originalClassMethods[i]);
		}
	}

	int length = testClassMethods.length;
	int size = publicInterfaceOfOriginal.size();

	for (int i = 0; i < size; i++){
		String methodName = ((Method)publicInterfaceOfOriginal.get(i)).getName();
		
		for (int j = 0; j < length; j++){
			
			if (testClassMethods[j].getName().indexOf(methodName) > -1) {
				found = true;
				break;
			}
		}
		if(found){
			((List)methodNames.get(0)).add(methodName);
			found = false;
		}else{
			((List)methodNames.get(1)).add(methodName);
		}
	}
	
	return methodNames;
}
}