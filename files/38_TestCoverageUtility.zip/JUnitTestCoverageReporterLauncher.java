package com.t4v.tools;

/**
 * This is instantiated by the VAJ tools class loader (?) to launch
 * the JUnitTestCoverageReporter.  Command line arguments either
 * begin with "-P" for projects or "-p" for packages.
 *
 * @version 0.1.0
 */
public class JUnitTestCoverageReporterLauncher {
public JUnitTestCoverageReporterLauncher() {
	super();
}
public static void main(String[] args) {
	VAJToolLauncher.fixClasspath();
	JUnitTestCoverageReporter.main(args);
}
}
