package com.t4v.tools;

import com.ibm.ivj.util.base.*;

public abstract class VAJToolLauncher {
public VAJToolLauncher() {
	super();
}
/**
 * In VAJ 3.0, the default classpath for tools does NOT include the workspace,
 * so this approach fixes up the classpath to include the entire workspace.
 * This is <i><b>believed</b></i> to be fixed in VAJ 3.5.
 *
 * @version 0.1.0
 */
public static void fixClasspath() {
	Workspace workspace = ToolEnv.connectToWorkspace();
	Object[] classpath = workspace.getClassPathEntries();
	Object[] projects = workspace.getProjects();
	Object[] newClasspath = new Object[classpath.length + projects.length];
	for (int i = 0; i < projects.length; i++) {
		newClasspath[i] = projects[i];
	}
	System.arraycopy(classpath, 0, newClasspath, projects.length, classpath.length);
	try {
		workspace.setClassPath(newClasspath);
	} catch(IvjException e) {}
}
}
