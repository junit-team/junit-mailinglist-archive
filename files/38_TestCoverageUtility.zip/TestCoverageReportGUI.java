package com.t4v.tools;

import com.jrefinery.chart.ui.*;
import java.awt.print.*;
import com.jrefinery.chart.*;
import com.ibm.ivj.util.builders.*;
import java.lang.reflect.*;
import com.ibm.ivj.util.base.*;
import java.text.*;
import java.io.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;

/**
 * A GUI to support the reporting of classes selected that do or do not have associated tests.
 * <b>DISCLAIMER: This is a spiked (proof of concept) version of this class.  It offers no
 * separation of model, view, and controller.  Version 0.1.1 will be built on the MVC
 * framework (release date unknown).</b>
 *
 * @version 0.1.0
 */
public class TestCoverageReportGUI extends Frame implements Printable {
	IvjEventHandler ivjEventHandler = new IvjEventHandler();
	private Button ivjGenerateChartButton = null;
	private Button ivjGenerateMethodsButton = null;
	private Button ivjRunTestButton = null;
	private Button ivjSaveButton = null;
	private final static String CLASSES_WITH_TESTS = "Classes with tests:  ";
	private final static String CLASSES_WITHOUT_TESTS = "Classes without tests:  ";
	private final static String METHODS_WITH_TESTS = "Public Methods Tested: ";
	private final static String METHODS_WITHOUT_TESTS = "Public Methods Not Tested: ";
	private FlowLayout ivjToolBarPaneFlowLayout = null;
	private java.awt.List ivjClassesWithoutTestsList = null;
	private java.awt.List ivjClassesWithTestsList = null;
	private java.awt.List ivjMethodsNotTestedList = null;
	private java.awt.List ivjMethodsTestedList = null;
	private java.awt.List ivjPackagesList = null;
	private Label ivjClassesWithoutTestsLabel = null;
	private Label ivjClassesWithTestsLabel = null;
	private Label ivjMethodsNotTestedLabel = null;
	private Label ivjMethodsTestedLabel = null;
	private Label ivjPackageLabel = null;
	private Panel ivjAWTApplicationPane = null;
	private Panel ivjContentsPane = null;
	private Panel ivjToolBarPane = null;
	private static Hashtable tableOfPackages;
	private JFreeChart printingChart;
	private Workspace workspace;

	/**
	 * An event handler for window events
	 */
	class IvjEventHandler implements java.awt.event.WindowListener {
		public void windowActivated(java.awt.event.WindowEvent e) {
		};
		public void windowClosed(java.awt.event.WindowEvent e) {
		};
		public void windowClosing(java.awt.event.WindowEvent e) {
			if (e.getSource() == TestCoverageReportGUI.this)
				connEtoC1(e);
		};
		public void windowDeactivated(java.awt.event.WindowEvent e) {
		};
		public void windowDeiconified(java.awt.event.WindowEvent e) {
		};
		public void windowIconified(java.awt.event.WindowEvent e) {
		};
		public void windowOpened(java.awt.event.WindowEvent e) {
		};
	};

	/**
	 * An extension of <code>FileFilter</code>
	 */
	class FileExtensionFilter extends javax.swing.filechooser.FileFilter implements FilenameFilter {
		String ending = null;
		String description = null;

    /**
	   * @param ending the extension to filter on
	   * @param desription the description of the type of files to be accepted
	   */
		public FileExtensionFilter(String ending, String description) {
			this.ending = ending.toUpperCase();
			this.description = description;
		}
		
    /**
	   * @param f a type of file to be accepted
	   * @return true if operation succeeded, false otherwise
	   * @see javax.swing.filechooser.FileFilter.accept#
	   */
		public boolean accept(File f) {
			return f.isDirectory() || f.toString().toUpperCase().endsWith(ending);
		}
		
		/**
	   * Must be implemented because of inheritance (<code>FileNameFilter</code>)
	   * @return true if operation succeeded, false otherwise
	   * @see java.io.FilenameFilter
	   */
		public boolean accept(File dir, String name) {
			return accept(new File(dir, name));
		}
		
    /**
	   * @return <code>description</code>
	   * @see javax.swing.filechooser.FileFilter.getDescription#
	   */
		public String getDescription() {
			return description;
		}
	}

/**
 * @param title the title of the GUI
 */
public TestCoverageReportGUI(String title) {
	super(title);
	initialize(title);
	workspace = ToolEnv.connectToWorkspace();
}

private void attemptEditChartProperties(JFreeChart chart) {
	ChartPropertyEditPanel panel = new ChartPropertyEditPanel(chart);
	int result = JOptionPane.showConfirmDialog(this, panel, "Chart Properties",
				   JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
	if (result==JOptionPane.OK_OPTION) {
	  panel.setChartProperties(chart);
	}
} 

private java.awt.Panel awtApplicationPane() {
	if (ivjAWTApplicationPane == null) {
		try {
			ivjAWTApplicationPane = new java.awt.Panel();
			ivjAWTApplicationPane.setName("AWTApplicationPane");
			ivjAWTApplicationPane.setLayout(null);
			ivjAWTApplicationPane.setBackground(Color.lightGray);
			awtApplicationPane().add(classesWithoutTestsList(), classesWithoutTestsList().getName());
			awtApplicationPane().add(classesWithTestsList(), classesWithTestsList().getName());
			awtApplicationPane().add(classesWithoutTestsLabel(), classesWithoutTestsLabel().getName());
			awtApplicationPane().add(classesWithTestsLabel(), classesWithTestsLabel().getName());
			awtApplicationPane().add(packageLabel(), packageLabel().getName());
			awtApplicationPane().add(packagesList(), packagesList().getName());
			awtApplicationPane().add(methodsTestedList(), methodsTestedList().getName());
			awtApplicationPane().add(methodsNotTestedList(), methodsNotTestedList().getName());
			awtApplicationPane().add(methodsNotTestedLabel(), methodsNotTestedLabel().getName());
			awtApplicationPane().add(methodsTestedLabel(), methodsTestedLabel().getName());
			awtApplicationPane().add(runTestButton(), runTestButton().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjAWTApplicationPane;
}

private void centerOnScreen(Component component) {
	Rectangle childRectangle = component.getBounds();
	Rectangle parentRectangle = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());

	class CenteredLocation extends Point {
		public CenteredLocation() {
		}
		public Point translate(Rectangle childRectangle, Rectangle parentRectangle) {
			int xOffset = (parentRectangle.width - childRectangle.width) / 2;
			int yOffset = (parentRectangle.height - childRectangle.height) / 2;

			Point centeredLocation = parentRectangle.getLocation();
			centeredLocation.translate(xOffset, yOffset);
			return centeredLocation;
		}
	}

	component.setLocation(new CenteredLocation().translate(childRectangle, parentRectangle));

}

private java.awt.Label classesWithoutTestsLabel() {
	if (ivjClassesWithoutTestsLabel == null) {
		try {
			ivjClassesWithoutTestsLabel = new java.awt.Label();
			ivjClassesWithoutTestsLabel.setName("ClassesWithoutTestsLabel");
			ivjClassesWithoutTestsLabel.setText(CLASSES_WITHOUT_TESTS);
			ivjClassesWithoutTestsLabel.setBounds(271, 10, 220, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjClassesWithoutTestsLabel;
}

private java.awt.List classesWithoutTestsList() {
	if (ivjClassesWithoutTestsList == null) {
		try {
			ivjClassesWithoutTestsList = new java.awt.List(10);
			ivjClassesWithoutTestsList.setName("ClassesWithoutTestsList");
			ivjClassesWithoutTestsList.setBounds(271, 35, 242, 380);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjClassesWithoutTestsList;
}

private java.awt.Label classesWithTestsLabel() {
	if (ivjClassesWithTestsLabel == null) {
		try {
			ivjClassesWithTestsLabel = new java.awt.Label();
			ivjClassesWithTestsLabel.setName("ClassesWithTestsLabel");
			ivjClassesWithTestsLabel.setText(CLASSES_WITH_TESTS);
			ivjClassesWithTestsLabel.setBounds(523, 10, 220, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjClassesWithTestsLabel;
}

private java.awt.List classesWithTestsList() {
	if (ivjClassesWithTestsList == null) {
		try {
			ivjClassesWithTestsList = new java.awt.List(10);
			ivjClassesWithTestsList.setName("ClassesWithTestsList");
			ivjClassesWithTestsList.setBounds(523, 35, 242, 380);
			
			class MyEventListener extends MouseAdapter {
				public MyEventListener(){
					super();
				}
				public void mouseClicked(MouseEvent e) {
					String className = ivjClassesWithTestsList.getSelectedItem();
					ivjRunTestButton.setLabel("Run " + className + "Test");
					propogateMethodsLists(packagesList().getSelectedItem(), className);
				}
			}
			
			ivjClassesWithTestsList.addMouseListener(new MyEventListener());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjClassesWithTestsList;
}

private void compareMethods(Class originalClass, Class testClass){
	int found = 0;
	int notFound = 0;
	methodsNotTestedList().removeAll();
	methodsTestedList().removeAll();
	
	java.util.List tempList = TestCoverageReportUtilityClass.findMethodsThatAreAndAreNotTested(originalClass, testClass);
	java.util.List testMethodsFound = (java.util.List)tempList.get(0);
	java.util.List testMethodsNotFound = (java.util.List)tempList.get(1);

	found = testMethodsFound.size();
	notFound = testMethodsNotFound.size();
	String temp = null;
	
	for (int i = 0; i < found; i++){
		temp = (String)testMethodsFound.get(i);
		ivjMethodsTestedList.add(temp);
	}

	for (int i = 0; i < notFound; i++){
		temp = (String)testMethodsNotFound.get(i);
		ivjMethodsNotTestedList.add(temp);
	}
	
	setMethodsLabels(found, notFound);
	ivjMethodsNotTestedList.repaint();
	ivjMethodsTestedList.repaint();
	this.repaint();
}

private void connEtoC1(WindowEvent arg1) {
	try {
		this.dispose();
		System.exit(0);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}

private java.awt.Panel contentsPane() {
	if (ivjContentsPane == null) {
		try {
			ivjContentsPane = new java.awt.Panel();
			ivjContentsPane.setName("ContentsPane");
			ivjContentsPane.setLayout(new java.awt.BorderLayout());
			ivjContentsPane.setBackground(Color.lightGray);
			contentsPane().add(toolBarPane(), "North");
			contentsPane().add(awtApplicationPane(), "Center");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjContentsPane;
}

private JMenuBar createMenuBar(JFreeChart chart, JFrame frameForChart) {

	final JFreeChart aChart = chart;
	final JFrame aFrame = frameForChart;
	// create the menus
	JMenuBar menuBar = new JMenuBar();
	ActionListener act = new ActionListener() {
		public void actionPerformed(ActionEvent event) {
			String command = event.getActionCommand();
			if (command.equals("Print")) {
				printChart(aChart);
			} else if (command.equals("Exit")) {
				aFrame.dispose();
			} else if (command.equals("ChartProperties")) {
				attemptEditChartProperties(aChart);
			} 
		}
	};

	// first the file menu
	JMenu fileMenu = new JMenu("File", true);
	fileMenu.setMnemonic('F');
	JMenuItem printItem = new JMenuItem("Print...", 'O');
	printItem.setActionCommand("Print");
	printItem.addActionListener(act);
	fileMenu.add(printItem);

	fileMenu.add(new JSeparator());

	JMenuItem exitItem = new JMenuItem("Exit", 'x');
	exitItem.setActionCommand("Exit");
	exitItem.addActionListener(act);
	fileMenu.add(exitItem);

	// then the edit menu
	JMenu editMenu = new JMenu("Edit");
	editMenu.setMnemonic('E');
	JMenuItem chartPropertiesItem = new JMenuItem("Chart Properties...", 'P');
	chartPropertiesItem.setActionCommand("ChartProperties");
	chartPropertiesItem.addActionListener(act);
	editMenu.add(chartPropertiesItem);

	// finally, glue together the menu and return it
	menuBar.add(fileMenu);
	menuBar.add(editMenu);
	return menuBar;

}

private void generateChart(){
	String[] packages = ivjPackagesList.getItems();
	int length = ivjPackagesList.getItemCount();
	int notTested = 0;
	int tested = 0;

	for (int i = 0; i < length; i++) {
		repropogateClassLists(packages[i]);
		notTested += ivjClassesWithoutTestsList.getItemCount();
		tested += ivjClassesWithTestsList.getItemCount();
	}
	float percentageTested = ((float)(tested) / (float)(notTested+tested));
	NumberFormat format = NumberFormat.getPercentInstance();
	
	String formattedPercentageTested = format.format((double)percentageTested);
	String formattedPercentageNotTested = format.format((1 - (double)percentageTested));
	JFrame frame = new JFrame();
	JPanel content = new JPanel(new BorderLayout());
	
	Number[][] data = new Integer[][]
	  { { new Integer(0), new Integer(notTested)},
	    { new Integer(0), new Integer(tested)}};

	java.util.List seriesNames = new ArrayList();
	seriesNames.add("Not Tested" + formattedPercentageNotTested);
	seriesNames.add("Tested" + formattedPercentageTested);
	
	java.util.List categoryNames = new ArrayList();
	categoryNames.add("Not Tested");
	categoryNames.add("Tested");
	
	CategoryDataSource categoryData = new DefaultCategoryDataSource(seriesNames, categoryNames, data);
	JFreeChart chart = JFreeChart.createLineChart(categoryData);
	chart.setChartBackgroundPaint(new GradientPaint(0, 0, Color.white,0, 1000, Color.orange));
	JFreeChartPanel chartPanel = new JFreeChartPanel(chart);
	chartPanel.setBorder(BorderFactory.createCompoundBorder(
							BorderFactory.createEmptyBorder(4, 4, 4, 4),
							BorderFactory.createLineBorder(Color.darkGray, 1)));
	chart.setTitle("Test Coverage Chart");
	
	chartPanel.setVisible(true);
	JMenuBar menuBar = createMenuBar(chart, frame);
	content.add(menuBar, BorderLayout.NORTH);
	content.add(chartPanel, BorderLayout.SOUTH);

	frame.setContentPane(content);
	frame.pack();
	centerOnScreen(frame);
	frame.setVisible(true);
}

private Button generateChartButton() {
	if (ivjGenerateChartButton == null) {
		try {
			ivjGenerateChartButton = new Button();
			ivjGenerateChartButton.setName("ChartButton");
			ivjGenerateChartButton.setLabel("Generate Chart");
			ActionListener act = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					generateChart();
				}
			};
			ivjGenerateChartButton.addActionListener(act);
		} catch (Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjGenerateChartButton;
}

private void handleException(java.lang.Throwable exception) {

	System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	exception.printStackTrace(System.out);
}

private void initialize(String title) {
	try {
		UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); 
	} catch (Exception e) {
	}
	
	if(tableOfPackages == null){
		tableOfPackages = new Hashtable();
	}
	try {
		setName(title);
		setLayout(new java.awt.BorderLayout());
		setSize(780, 660);
		setTitle(title);
		add(contentsPane(), "Center");
		initializeConnections();
		centerOnScreen(this);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}

private void initializeConnections() throws Exception {
	this.addWindowListener(ivjEventHandler);
}

/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		TestCoverageReportGUI aTestCoverageReportGUI;
		aTestCoverageReportGUI = new TestCoverageReportGUI(new java.lang.String());
		aTestCoverageReportGUI.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		aTestCoverageReportGUI.show();
		java.awt.Insets insets = aTestCoverageReportGUI.getInsets();
		aTestCoverageReportGUI.setSize(aTestCoverageReportGUI.getWidth() + insets.left + insets.right, aTestCoverageReportGUI.getHeight() + insets.top + insets.bottom);
		aTestCoverageReportGUI.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Frame");
		exception.printStackTrace(System.out);
	}
}

private java.awt.Label methodsNotTestedLabel() {
	if (ivjMethodsNotTestedLabel == null) {
		try {
			ivjMethodsNotTestedLabel = new java.awt.Label();
			ivjMethodsNotTestedLabel.setName("MethodsNotTestedLabel");
			ivjMethodsNotTestedLabel.setText(METHODS_WITHOUT_TESTS);
			ivjMethodsNotTestedLabel.setBounds(271, 430, 239, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMethodsNotTestedLabel;
}

private java.awt.List methodsNotTestedList() {
	if (ivjMethodsNotTestedList == null) {
		try {
			ivjMethodsNotTestedList = new java.awt.List();
			ivjMethodsNotTestedList.setName("MethodsNotTestedList");
			ivjMethodsNotTestedList.setBounds(271, 455, 242, 115);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMethodsNotTestedList;
}

private java.awt.Label methodsTestedLabel() {
	if (ivjMethodsTestedLabel == null) {
		try {
			ivjMethodsTestedLabel = new java.awt.Label();
			ivjMethodsTestedLabel.setName("MethodsTestedLabel");
			ivjMethodsTestedLabel.setText(METHODS_WITH_TESTS);
			ivjMethodsTestedLabel.setBounds(521, 430, 239, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMethodsTestedLabel;
}

private java.awt.List methodsTestedList() {
	if (ivjMethodsTestedList == null) {
		try {
			ivjMethodsTestedList = new java.awt.List();
			ivjMethodsTestedList.setName("MethodsTestedList");
			ivjMethodsTestedList.setBounds(523, 455, 242, 115);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMethodsTestedList;
}

private java.awt.Label packageLabel() {
	if (ivjPackageLabel == null) {
		try {
			ivjPackageLabel = new java.awt.Label();
			ivjPackageLabel.setName("PackageLabel");
			ivjPackageLabel.setText("Packages");
			ivjPackageLabel.setBounds(13, 10, 84, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPackageLabel;
}

private java.awt.List packagesList() {
	if (ivjPackagesList == null) {
		try {
			ivjPackagesList = new java.awt.List(10);
			ivjPackagesList.setName("PackagesList");
			ivjPackagesList.setBounds(13, 35, 242, 380);
			
			class MyEventListener extends MouseAdapter {
				public MyEventListener(){
					super();
				}
				public void mouseClicked(MouseEvent e) {
					repropogateClassLists(ivjPackagesList.getSelectedItem());
				}
			}
			
			ivjPackagesList.addMouseListener(new MyEventListener());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPackagesList;
}

/**
 * This method is declared <code>public</code> because it is inherited from 
 * <code>Printable</code>, therefore the visibility cannot be reduced.
 */
public int print(Graphics g, PageFormat pf, int pageIndex) {
	if (pageIndex!=0) return NO_SUCH_PAGE;
	Graphics2D g2 = (Graphics2D)g;
	double x = pf.getImageableX();
	double y = pf.getImageableY();
	double w = pf.getImageableWidth();
	double h = pf.getImageableHeight();
	printingChart.draw(g2, new java.awt.geom.Rectangle2D.Double(x, y, w, h));
	return PAGE_EXISTS;
}  

private void printChart(JFreeChart chart) {

	PrinterJob pj = PrinterJob.getPrinterJob();
	pj.setPrintable(this);
	printingChart = chart;
	if (pj.printDialog()) {
		try {
			pj.print();
		} catch (PrinterException e) {
			JOptionPane.showMessageDialog(this, e);
		}
	}

}

private void propogateMethodsLists(String selectedPackage, String selectedClass) {
	Class originalClass = null;
	Class testClass = null;
	
	try {
		originalClass = Class.forName(selectedPackage + "." + selectedClass);
		testClass = Class.forName(selectedPackage + ".tests." + selectedClass + "Test");
		
		compareMethods(originalClass, testClass);
	} catch (ClassNotFoundException ex) {
		JDialog parent = new JDialog(this, true);
		parent.setSize(500, 100);
		
		String message = "Encountered Class Not Found Exception";

		JPanel panel = new JPanel();
		panel.add(new JLabel(message));
		panel.add(new JLabel(ex.getMessage()));

		parent.getContentPane().add(panel);
		parent.setVisible(true);
	}

}

private void repropogateClassLists(String packageName) {
	Vector temp = (Vector)tableOfPackages.get(packageName);
	
	resetClassesWithoutTestsList((Vector)temp.elementAt(0));
	resetClassesWithTestsList((Vector)temp.elementAt(1));

	setPercentage();
	
	ivjClassesWithoutTestsList.repaint();
	ivjClassesWithTestsList.repaint();
	this.repaint();
}

private void resetClassesWithoutTestsList(Vector classes) {
	classesWithoutTestsList();
	ivjClassesWithoutTestsList.removeAll();
	for (int i = 0; i < classes.size(); i++){
		ivjClassesWithoutTestsList.add((String)classes.elementAt(i));
	}
}

private void resetClassesWithTestsList(Vector classes) {
	classesWithTestsList();
	ivjClassesWithTestsList.removeAll();
	for (int i = 0; i < classes.size(); i++){
		ivjClassesWithTestsList.add((String)classes.elementAt(i));
	}
}

private java.awt.Button runTestButton() {
	if (ivjRunTestButton == null) {
		try {
			ivjRunTestButton = new java.awt.Button();
			ivjRunTestButton.setName("RunTestButton");
			ivjRunTestButton.setBounds(56, 490, 184, 28);
			ivjRunTestButton.setLabel("Run Test");
			ActionListener act = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					final StringBuffer name = new StringBuffer(ivjPackagesList.getSelectedItem());
					name.append(".tests.");
					name.append(ivjClassesWithTestsList.getSelectedItem());
					name.append("Test");
					try {
						workspace.runMain(junit.awtui.TestRunner.class, new String[] { name.toString()});
					} catch (Exception ex) {
						/* Exceptions that can occur are:
						
							 IvjException, 
						   ClassNotFoundException, 
						   NoSuchMethodException,
						   IllegalAccessException,
						   IllegalArgumentException,
						   InvocationTargetException
						*/
						workspace.logMessage(ex.getMessage(), true);
					}
				}
			};
			ivjRunTestButton.addActionListener(act);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjRunTestButton;
}

private Button saveButton() {
	if (ivjSaveButton == null) {
		try {
			ivjSaveButton = new java.awt.Button();
			ivjSaveButton.setName("SaveButton");
			ivjSaveButton.setLabel("Save");
			ActionListener act = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					saveReport();
				}
			};
			ivjSaveButton.addActionListener(act);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjSaveButton;
}

private String saveDialog(
	String rootDirectory,
	String msg,
	Vector fileExtensions,
	Vector fileDescriptions) {
	
	File selectedFile;
	JFrame applicationFrame = new JFrame("Save");
	JFileChooser fileChooser = new JFileChooser();
	fileChooser.setCurrentDirectory(new File(rootDirectory));
	for (int i = 0; i < fileDescriptions.size(); i++) {
		FileExtensionFilter fe =
			new FileExtensionFilter((String) fileExtensions.elementAt(i), (String) fileDescriptions.elementAt(i));
		fileChooser.addChoosableFileFilter(fe);
		if (i == 0)
			fileChooser.setFileFilter(fe);
	}
	fileChooser.setDialogTitle(msg);
	if (fileChooser.showSaveDialog(applicationFrame) == JFileChooser.APPROVE_OPTION) {
		selectedFile = fileChooser.getSelectedFile();
		return selectedFile.toString();
	} else
		return null;
}

private void saveReport() {
	final String message = "Save A Report For All Packages";
	String path = "\\\\isi5\\JavaFactory\\Docs\\Internal\\Iteration_Reports_And_Charts";
	Vector fileExtensions = new Vector();
	Vector fileDescriptions = new Vector();
	
	fileExtensions.add(".xml");
	fileDescriptions.add("Extensible Markup Language (*.xml)");
	
	File file =
		new File(saveDialog(path, message, fileExtensions, fileDescriptions));
	FileWriter writer = null;

	try {
		writer = new FileWriter(file);
		writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<REPORT>\n");
		String[] packages = ivjPackagesList.getItems();
		int length = ivjPackagesList.getItemCount();
		int totalClassesWithTests = 0;
		int totalClassesWithoutTests = 0;
		String packageStart = "\t<PACKAGE>\n";
		String packageEnd = "\t</PACKAGE>\n";
		String classTestedStart = "\t\t<CLASSES_TESTED>\n";
		String classTestedEnd = "\t\t</CLASSES_TESTED>\n";
		String classNotTestedStart = "\t\t<CLASSES_NOT_TESTED>\n";
		String classNotTestedEnd = "\t\t</CLASSES_NOT_TESTED>\n";
		String methodTestedStart = "\t\t\t<METHODS_TESTED>\n";
		String methodTestedEnd = "\t\t\t</METHODS_TESTED>\n";
		String methodNotTestedStart = "\t\t\t<METHODS_NOT_TESTED>\n";
		String methodNotTestedEnd = "\t\t\t</METHODS_NOT_TESTED>\n";
		
		for (int i = 0; i < length; i++) {
			writer.write(packageStart + packages[i] );
			repropogateClassLists(packages[i]);
			
			writer.write(classNotTestedStart);
			for (int j = 0; j < ivjClassesWithoutTestsList.getItemCount(); j++) {
				writer.write("\t\t\t<CLASS>" + ivjClassesWithoutTestsList.getItem(j) + "\n</CLASS>\n");
				totalClassesWithoutTests++;
			}
			writer.write(classNotTestedEnd);
			
			writer.write(classTestedStart);
			for (int k = 0; k < ivjClassesWithTestsList.getItemCount(); k++) {
				writer.write("\t\t\t<CLASS>" + ivjClassesWithTestsList.getItem(k) + "\n</CLASS>\n");
				propogateMethodsLists(packages[i], ivjClassesWithTestsList.getItem(k));
				
				writer.write(methodNotTestedStart);
				for (int l = 0; l < ivjMethodsNotTestedList.getItemCount(); l++){
					writer.write("\t\t\t\t<METHOD>" + ivjMethodsNotTestedList.getItem(l) + "\n</METHOD>\n");
				}
				writer.write(methodNotTestedEnd);
				
				writer.write(methodTestedStart);
				for (int l = 0; l < ivjMethodsTestedList.getItemCount(); l++){
					writer.write("\t\t\t\t<METHOD>" + ivjMethodsTestedList.getItem(l) + "\n</METHOD>\n");
				}
				writer.write(methodTestedEnd);
				totalClassesWithTests++;
			}
			writer.write(classTestedEnd);
			writer.write(packageEnd);
		}
		writer.write("\t<NUMBERS>\n\t\t<TESTED>\n");
		writer.write("\t\t\t" + totalClassesWithTests);
		writer.write("\n\t\t</TESTED>\n\t\t<NOT_TESTED>\n");
		writer.write("\t\t\t" + totalClassesWithoutTests);
		writer.write("\n\t\t</NOT_TESTED>\n");
		writer.write("\t</NUMBERS>\n");
		writer.write("</REPORT>");
		writer.flush();
		writer.close();
	} catch (IOException ex) {
		ex.printStackTrace();
	}
}

/**
 * This is called by {@link JUnitTestCoverageReporter#publishReportToGui} to begin the process
 * of "filling up" the GUI.
 * @see JUnitTestCoverageReporter#publishReportToGui
 */
public void setLists(String packageName, Vector classesWithoutTests, 
					 Vector classesWithTests) {

	Vector temp = new Vector();
	
	if(packageName == null){
		packageName = "No corresponding test package";
	}else{		
		temp.add(classesWithoutTests);
		temp.add(classesWithTests);
	}

	ivjPackagesList.add(packageName);	
	tableOfPackages.put(packageName, temp);
}

private void setMethodsLabels(int tested, int notTested){
	int size = tested + notTested;
	StringBuffer endString = new StringBuffer(" of ");
	endString.append(size);
	endString.append(")");
	
	StringBuffer buffer = new StringBuffer(METHODS_WITHOUT_TESTS);
	buffer.append("(");
	buffer.append(notTested);
	buffer.append(endString.toString());
	
	ivjMethodsNotTestedLabel.setText(buffer.toString());
	buffer = null;

	buffer = new StringBuffer(METHODS_WITH_TESTS);
	buffer.append("(");
	buffer.append(tested);
	buffer.append(endString.toString());
	
	ivjMethodsTestedLabel.setText(buffer.toString());
}

private void setPercentage() {
	
	int classesWithoutTests = ivjClassesWithoutTestsList.getItemCount();
	int classesWithTests = ivjClassesWithTestsList.getItemCount();
	int numberOfTotalClasses = classesWithoutTests +classesWithTests;

	if(classesWithoutTests == 0 && classesWithTests == 0){
		String temp = "No associated test Package";
		ivjClassesWithoutTestsLabel.setText(temp);
		ivjClassesWithTestsLabel.setText(temp);
		return;
	}
							   
	float percentageTested = ((float)(classesWithTests) / (float)(numberOfTotalClasses));
	NumberFormat format = NumberFormat.getPercentInstance();
	
	String formattedPercentageTested = format.format((double)percentageTested);
	String formattedPercentageNotTested = format.format((1 - (double)percentageTested));

	ivjClassesWithoutTestsLabel.setText(
			CLASSES_WITHOUT_TESTS + 
			formattedPercentageNotTested +
		 	" (" + classesWithoutTests +
		 	" of " + numberOfTotalClasses + ")");
	ivjClassesWithTestsLabel.setText(
			CLASSES_WITH_TESTS + 
			formattedPercentageTested +
		 	" (" + classesWithTests +
		 	" of " + numberOfTotalClasses + ")");
}

private Panel toolBarPane() {
	if (ivjToolBarPane == null) {
		try {
			ivjToolBarPane = new java.awt.Panel();
			ivjToolBarPane.setName("ToolBarPane");
			ivjToolBarPane.setLayout(toolBarPaneFlowLayout());
			ivjToolBarPane.add(saveButton());
			ivjToolBarPane.add(generateChartButton());
		} catch (Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjToolBarPane;
}

private java.awt.FlowLayout toolBarPaneFlowLayout() {
	java.awt.FlowLayout ivjToolBarPaneFlowLayout = null;
	try {
		ivjToolBarPaneFlowLayout = new java.awt.FlowLayout();
		ivjToolBarPaneFlowLayout.setAlignment(java.awt.FlowLayout.LEFT);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjToolBarPaneFlowLayout;
}
}