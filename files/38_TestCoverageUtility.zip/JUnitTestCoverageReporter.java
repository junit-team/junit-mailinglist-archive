package com.t4v.tools;

import java.util.*;
import java.lang.reflect.*;
import com.ibm.ivj.util.base.*;
import com.ibm.ivj.util.builders.*;

/**
 * A class to report on which classes in the specified package(s) or project(s)
 * have tests.  If a package does not have an associated test package in the following
 * manner the TestCoverageReportGui show a header in the classes tested and not tested
 * lists which explains that there is no associated test package.
 * <blockquote><pre>
 * For a package named [original_package_name] the associated test package must be in the 
 * form of [original_package_name].tests (i.e. com.foobar.classes will have a test package
 * com.foobar.classes.tests).
 * </pre></blockquote>
 *
 * Likewise test classes are defined as follows:
 * <blockquote><pre>
 * For a class named [original_class_name] the associated test class must be in the 
 * form of [original_class_name]Test located in the proper test package
 * (i.e. com.foobar.classes.ClassOne will have a test class com.foobar.classes.tests.ClassOneTest).
 * </pre></blockquote>
 *
 * These limitations will either be removed with future releases or will be configurable.
 *
 * @version 0.1.0
 */
public class JUnitTestCoverageReporter {
	private Workspace workspace;
	private Repository repository;
	private Type[] typesForPackage;
	private Type[] typesForCorrespondingTestPackage;
	private com.ibm.ivj.util.base.Package thePackage;
	private com.ibm.ivj.util.base.Package theCorrespondingTestPackage;
	private boolean correspondingTestPackageExists;
	private Vector testsThatExist = null;
	private Vector testsThatDoNotExist = null;
	private float percentageCovered;
	private static TestCoverageReportGUI gui;
	
/**
 * @param aPackageName the name of the package for which a report should be generated
 */
public JUnitTestCoverageReporter(String aPackageName) {
	initialize(aPackageName);
}

/**
 * generate the report for <code>thePackage</code>.  This excludes interfaces and
 * exceptions.
 */
public void generateReport() {
	int size = typesForPackage.length;
	
	percentageCovered = 0.0F;
	testsThatExist = new Vector();
	testsThatDoNotExist = new Vector();

	if (correspondingTestPackageExists) {
		for (int i = 0; i < size; i++) {
			String typeName = typesForPackage[i].getName();
			String typeTest = typeName + "Test";
			if (testExists(typeTest)) {
				testsThatExist.add(typeName);
			} else {
				try{
					//don't include interfaces
					if(!typesForPackage[i].isInterface()){
						//don't include exceptions
						if (typesForPackage[i].getName().indexOf("Exception") == -1) {
							testsThatDoNotExist.add(typeName);
						}
					}
				} catch (IvjException e){
					e.printStackTrace();
					workspace.logMessage("\nError determining if type is an interface\n", true);
				}
			}
		}

		percentageCovered = (((float) (testsThatExist.size()) / size) * 100);
	}
}
private void initialize(String aPackageName){
	workspace = ToolEnv.connectToWorkspace();
	repository = workspace.getRepository();
	thePackage = workspace.loadedPackageNamed(aPackageName);
	theCorrespondingTestPackage = workspace.loadedPackageNamed(aPackageName+".tests");
	
	try {
		typesForPackage = thePackage.getTypes();
		if(theCorrespondingTestPackage != null){
			correspondingTestPackageExists = true;
			typesForCorrespondingTestPackage = theCorrespondingTestPackage.getTypes();
		}
	} catch (IvjException e) {
		workspace.logMessage("Error getting types for package in the Test Coverage Reporter", true);
		workspace.logMessage("\nSee console for stack trace", true);
		e.printStackTrace();
	}

	if(gui == null){
		gui = new TestCoverageReportGUI ("Test Coverage Reporter");
	}
	gui.show();
}

/**
 * @param identifier the first argument from the command line.  This is based on the class being
 * invoked through VAJ's tools API.  Valid arguments for this tool are "-P" for projects
 * and "-p" for packages.
 */
public static boolean isArgumentAPackage(String identifier){
	return ( identifier.equals("-p") );
}

public static void main(String[] args) {
	JUnitTestCoverageReporter reporter = null;
	
	for (int i = 1; i < args.length; i++){
		Workspace workspace = ToolEnv.connectToWorkspace();
		if( JUnitTestCoverageReporter.isArgumentAPackage(args[0]) ){
			reporter = new JUnitTestCoverageReporter(args[i]);
			reporter.generateReport();
			reporter.publishReportToGui();
		}else{
			try{
				com.ibm.ivj.util.base.Package[] packages = workspace.loadedProjectNamed(args[i]).getPackages();
				for (int j = 0; j < packages.length; j++){
					reporter  = new JUnitTestCoverageReporter(packages[j].getName());
					reporter.generateReport();
					reporter.publishReportToGui();
				}
			} catch(IvjException e){
				workspace.logMessage("\nError getting packages from " + args[i], true);
			}
		}
	}
}

/**
 * send this report to the <code>TestCoverageReportGUI</code>
 * @see TestCoverageReportGUI#setLists
 */
public void publishReportToGui() {
	gui.setLists(thePackage.getName(), 
				 testsThatDoNotExist,
				 testsThatExist);
}
private boolean testExists(String testName) {
	boolean exists = false;
	if (typesForCorrespondingTestPackage != null) {
		int size = typesForCorrespondingTestPackage.length;

		for (int i = 0; i < size; i++) {
			if (typesForCorrespondingTestPackage[i].getName().equals(testName)) {
				exists = true;
			}
		}
	}
	return exists;
}
}
