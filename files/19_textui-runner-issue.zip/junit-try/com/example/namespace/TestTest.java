package com.example.namespace;
import junit.framework.*;

public class TestTest extends junit.framework.TestCase {
	public void testRunnin() {
		assertFalse("failure works!", true);
	}
	public static Test suite() {
		return new TestSuite(TestTest.class);
	}
	public static void main(String[] args) {
		junit.textui.TestRunner.run(TestTest.class);
	}
}
