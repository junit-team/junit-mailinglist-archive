public class TestLoginAction extends MockStrutsTestCase {

    public TestLoginAction(String testName) { super(testName); }

    public void testSuccessfulLogin() {
       setRequestPathInfo("/login");
       addRequestParameter("username","sysveda");
       addRequestParameter("password","sysveda");
       actionPerform();
       verifyForward("success");
       assertEquals("sysveda",(String) getSession().getAttribute("authentication"));
       verifyNoActionErrors();
    }
}

