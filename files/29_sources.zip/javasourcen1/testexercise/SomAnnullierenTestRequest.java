package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (20.02.2003 11:31:29)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.nom.som.net.AnnuEinzelServerRequest;

public class SomAnnullierenTestRequest extends NomTestRequest {

/**
 * SomAnnullierenTestRequest - Konstruktorkommentar.
 */
public SomAnnullierenTestRequest() {
	super();
}
/**
 * SomAnnullierenTestRequest - Konstruktorkommentar.
 * @param testObject testexercise.TestObject
 */
public SomAnnullierenTestRequest(TestObject testObject, java.io.FileWriter fw) {
	super(testObject, fw);
}
public void ausf�hren() {
		
	request = new AnnuEinzelServerRequest();
    ((AnnuEinzelServerRequest) request).createAuftDaten().set(techNomAuftragCdsIn);
    ((AnnuEinzelServerRequest) request).createAuftCodes().set(techAregPkeyFeldIn);
    ((AnnuEinzelServerRequest) request).createAnzAuftCodes().set(techAnzahlAregPkeyFeldDsIn);
    ((AnnuEinzelServerRequest) request).createAnzKunden().set(techAnzahlNomKundeCdsFeldDsIn);
    ((AnnuEinzelServerRequest) request).createKunden().set(techNomKundeCdsFeldIn);
    super.ausf�hren();
    this.techNomAuftragCdsIst = ((AnnuEinzelServerRequest) request).getAuftDaten();
    this.techAnzahlAregPkeyFeldDsIst = ((AnnuEinzelServerRequest) request).getAnzAuftCodes();
    this.techAregPkeyFeldIst = ((AnnuEinzelServerRequest) request).getAuftCodes();
    this.techAnzahlNomKundeCdsFeldDsIst = ((AnnuEinzelServerRequest) request).getAnzKunden();
    this.techNomKundeCdsFeldIst = ((AnnuEinzelServerRequest) request).getKunden();
	
}
}
