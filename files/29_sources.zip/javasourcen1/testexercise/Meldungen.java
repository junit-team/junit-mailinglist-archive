package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (25.02.2003 11:23:28)
 * @author: Wolfgang Weber
 */

import java.util.Vector;
import com.dcag.s55.gool.go.net.MessageList;

public class Meldungen {

private Vector vec;

public class Meldung {

String nr;
String text;



public Meldung(String nr, String text) {

	this.nr = nr;
	this.text = text;
}

public String getNr() {
	return nr;
}

public String getText() {
	return text;
}

}
	





	
public Meldungen() {
	vec = new Vector();
}
public Meldungen(MessageList meldungen) {

	vec = new Vector();

	for (int i = 0; i < meldungen.size(); i++) {
		this.addMeldung(meldungen.getMessage(i).getID(), (String) meldungen.getMessage(i).getText());
	}
		
}
private void addMeldung(String nr, String text) {
	Meldung meldung = new Meldung(nr, text);
	vec.add(meldung);
}

public java.util.Vector equals(Meldungen meldungen) {

	Vector vec = new Vector();

	sortiere();
	meldungen.sortiere();

    for (int i = 0; i < this.size(); i++) {

	    if  (!this.getMeldung(i).getNr().equals(meldungen.getMeldung(i).getNr())) {
		    TestResult res = new TestResult(this.getMeldung(i).getNr(), meldungen.getMeldung(i).getNr(), "Meldung (" + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getMeldung(i).getText().equals(meldungen.getMeldung(i).getText())) {
		    TestResult res = new TestResult(this.getMeldung(i).getText(), meldungen.getMeldung(i).getText(), "Meldung (" + i + ")");
		    vec.add(res);
	    }
	    
	}



    return vec;


	
	
}
public void fuelle(java.util.Vector vec, int pos) {

	int anz = new Integer((String) vec.get(pos + 0)).intValue();

	for (int i = pos; i < pos + 2 * anz; i = i+ 2) {
		addMeldung((String) vec.get(i + 1), (String) vec.get(i + 2));
	} 
}

private Meldung getMeldung(int i) {
	return (Meldung) vec.get(i);
}
private void setMeldung(Meldung meldung, int i) {
	vec.setElementAt(meldung, i);
}
public int size() {
	return vec.size();
}
public void sortiere() {

	int anz = vec.size();

	for (int i = 0; i < anz - 1; i++) {
		for (int j = i + 1; j < anz; j++) {
			if  (getMeldung(i).getNr().compareTo(getMeldung(j).getNr()) > 0) {
				Meldung meldung = getMeldung(i);
				setMeldung(getMeldung(j), i);
				setMeldung(meldung, j);
			}
		}
	}

}
}
