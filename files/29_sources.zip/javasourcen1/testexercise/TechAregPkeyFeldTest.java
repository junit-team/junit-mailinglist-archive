package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (18.02.2003 11:03:53)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.gool.go.types.fzg.codes.TechAregPkeyFeld;
import com.dcag.s55.gool.go.types.fzg.codes.ArgcAregCode;

public class TechAregPkeyFeldTest extends com.dcag.s55.gool.go.types.fzg.codes.TechAregPkeyFeld {

/**
 * TechAregPkeyFeldTest - Konstruktorkommentar.
 */
public TechAregPkeyFeldTest() {
	super();
	
}
/**
 * TechAregPkeyFeldTest - Konstruktorkommentar.
 */
public TechAregPkeyFeldTest(TechAregPkeyFeld t) {
	super();
	set(t);
	
}
public java.util.Vector equals(TechAregPkeyFeld cds) {

    java.util.Vector vec = new java.util.Vector();
	
	sortiere();
	TechAregPkeyFeldTest t = new TechAregPkeyFeldTest(cds);
	t.sortiere();

	for (int i = 0;i < this.getSize();i++) {
		if  (!this.getAregPkey(i).getAregCode().toString().equals(t.getAregPkey(i).getAregCode().toString())) {
			TestResult res = new TestResult(getAregPkey(i).getAregCode(), t.getAregPkey(i).getAregCode(), "AregCode");
			vec.add(res);
		}
	}
	
	return vec;	
}

public void fuelle(java.util.Vector vec, int pos) {

	int anz = new Integer((String) vec.get(pos)).intValue();

	for (int i = 0; i < anz; i++) {
		this.getAregPkey(i).getAregCode().set((String) vec.get(i+1));
	}


}
public void fuelle(java.util.Vector vec, int pos, int anz) {


	for (int i = 0; i < anz; i++) {
		this.getAregPkey(i).getAregCode().set((String) vec.get(pos+i+1));
	}


}
private int getLength() {

	int i = 0;
	while (i < this.getSize() && this.getAregPkey(i) != null && !this.getAregPkey(i).getAregCode().toString().equals(new String("     ")) ) {
		i++;
	}
	return i;

}
public void sortiere() {

	int anz = this.getLength();
	for (int i = 0; i < anz - 1; i++) {
		for (int j = i + 1; j < anz; j++) {
			if  (getAregPkey(i).getAregCode().toString().compareTo(getAregPkey(j).getAregCode().toString()) > 0) {
				String temp = getAregPkey(i).getAregCode().toString();
				getAregPkey(i).getAregCode().set(getAregPkey(j).getAregCode().toString());
				getAregPkey(j).getAregCode().set(temp);
			}
		}
	}		
		
}
}
