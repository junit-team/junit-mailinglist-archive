package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (20.02.2003 13:05:41)
 * @author: Wolfgang Weber
 */
public class TechAdsAuftnrTest extends com.dcag.s55.gool.go.types.auft.TechAdsAuftnr {

public static int ANZ_STRUKTUR_ELEM = 4;

/**
 * TechAdsAuftnrTest - Konstruktorkommentar.
 */
public TechAdsAuftnrTest() {
	super();
	initialisiere();
}
public void fuelle(java.util.Vector vec, int pos) {
	
	if  ( ((String) vec.get(pos+0)).length() > 0)
        getJahr1().set(vec.get(pos+0));
	if  ( ((String) vec.get(pos+1)).length() > 0)        
        getLfdnr().set(vec.get(pos+1));
	if  ( ((String) vec.get(pos+2)).length() > 0)        
        getNdl().set(vec.get(pos+2));
	if  ( ((String) vec.get(pos+3)).length() > 0)        
        getSparte().set(vec.get(pos+3));
		
}
private void initialisiere() {

   getJahr1().set(new String(" "));
   getLfdnr().set(new String(" "));
   getNdl().set(new String(" "));
   getSparte().set(new String(" "));

}
}
