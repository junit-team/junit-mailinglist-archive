package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (20.02.2003 11:52:48)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.go.auftrag.net.AendEinzelServerRequest;
 
public class AuftragAendernTestRequest extends NomTestRequest {

/**
 * ReusableAendernEinzelServerRequest - Konstruktorkommentar.
 */
public AuftragAendernTestRequest() {
	super();
}
/**
 * ReusableAendernEinzelServerRequest - Konstruktorkommentar.
 * @param testObject testexercise.TestObject
 */
public AuftragAendernTestRequest(TestObject testObject, java.io.FileWriter fw) {
	super(testObject, fw);
}
public void ausf�hren() {
		
	request = new AendEinzelServerRequest();
    ((AendEinzelServerRequest) request).createAuftDaten().set(techNomAuftragCdsIn);
    ((AendEinzelServerRequest) request).createAuftCodes().set(techAregPkeyFeldIn);
    ((AendEinzelServerRequest) request).createAnzAuftCodes().set(techAnzahlAregPkeyFeldDsIn);
    ((AendEinzelServerRequest) request).createAnzKunden().set(techAnzahlNomKundeCdsFeldDsIn);
    ((AendEinzelServerRequest) request).createKunden().set(techNomKundeCdsFeldIn);
    super.ausf�hren();
    this.techNomAuftragCdsIst = ((AendEinzelServerRequest) request).getAuftDaten();
    this.techAnzahlAregPkeyFeldDsIst = ((AendEinzelServerRequest) request).getAnzAuftCodes();
    this.techAregPkeyFeldIst = ((AendEinzelServerRequest) request).getAuftCodes();
    this.techAnzahlNomKundeCdsFeldDsIst = ((AendEinzelServerRequest) request).getAnzKunden();
    this.techNomKundeCdsFeldIst = ((AendEinzelServerRequest) request).getKunden();
	
}
}
