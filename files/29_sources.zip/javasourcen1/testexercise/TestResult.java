package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (19.02.2003 09:38:02)
 * @author: Wolfgang Weber
 */
public class TestResult {

private String ist;
private String soll;
private String parameter;

/**
 * TestResult - Konstruktorkommentar.
 */
public TestResult(Object ist, Object soll, String parameter) {
	this.ist = ist.toString();
	this.soll = soll.toString();
	this.parameter = parameter;
}
/**
 * TestResult - Konstruktorkommentar.
 */
public TestResult(String ist, String soll, String parameter) {
	this.ist = ist;
	this.soll = soll;
	this.parameter = parameter;
}
public String getIst() {
	return ist;
}
public String getParameter() {
	return parameter;
}
public String getSoll() {
	return soll;
}
}
