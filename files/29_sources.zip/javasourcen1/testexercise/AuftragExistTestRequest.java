package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (20.02.2003 13:53:59)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.go.auftrag.net.AuftExistServerRequest;
 
public class AuftragExistTestRequest extends NomTestRequest {

TechAdsAuftnrTest techAdsAuftnr;

/**
 * AuftragExistTestRequest - Konstruktorkommentar.
 */
public AuftragExistTestRequest() {
	super();
}
/**
 * AuftragExistTestRequest - Konstruktorkommentar.
 * @param testObject testexercise.TestObject
 */
public AuftragExistTestRequest(TestObject testObject, java.io.FileWriter fw) {
	super(testObject, fw);
}
public void ausf�hren() {
		
	request = new AuftExistServerRequest();
	
    ((AuftExistServerRequest) request).createAuftNummer().set(techAdsAuftnr);
    super.ausf�hren();
	
}
public void lesenAusgabeSoll() {

    meldungenSoll = new Meldungen();
                    	
    meldungenSoll.fuelle(testObject.getOutPara(), 0);

    rcSoll = new Integer((String) testObject.getOutPara((meldungenSoll.size() * 2) + 1)).intValue();
	
}
public void lesenEingabe() {


    techAdsAuftnr = new TechAdsAuftnrTest();
    techAdsAuftnr.fuelle(testObject.getInPara(), 0);
	
}
public boolean vergleicheSollIstParameter() {

	return true;


}
}
