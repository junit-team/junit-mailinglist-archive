package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (10.02.2003 11:30:29)
 * @author: Wolfgang Weber
 */

import java.util.Vector;
import java.lang.reflect.Method;

 
public class InputHandler implements org.xml.sax.ContentHandler {

private TestObject testObject;
private Vector inOut;
private String aktMethode;
private String aktObjekt;
private String aktParameter;
private boolean zuLesenderWert;
private String buffer;

/**
 * InputHandler - Konstruktorkommentar.
 */
public InputHandler() {
	super();
}
/**
 * characters - Methodenkommentar.
 */
public void characters(char[] arg1, int arg2, int arg3) throws org.xml.sax.SAXException {
	
	String s = new String(arg1, arg2, arg3);

	if  (zuLesenderWert) {
		buffer = buffer.concat(s);
	}

	

	
}


	
/**
 * endDocument - Methodenkommentar.
 */
public void endDocument() throws org.xml.sax.SAXException {}
/**
 * endElement - Methodenkommentar.
 */
public void endElement(String arg1, String arg2, String arg3) throws org.xml.sax.SAXException {
	
	if  (arg2.equals(aktMethode)) {
		// neues testObject eintragen
		inOut.add(testObject);
		testObject = null;
		aktMethode = new String("");
		aktParameter = new String("");
	}
	else if (arg2.equals(aktObjekt)) {
		aktObjekt = new String("");
	}

	if (aktParameter.equals("in") && zuLesenderWert) {
		testObject.getInPara().removeElementAt(testObject.getInPara().size() - 1);
		testObject.addInPara(buffer);
	}
	else if (aktParameter.equals("out") && zuLesenderWert) {
		testObject.getOutPara().removeElementAt(testObject.getOutPara().size() - 1);
		testObject.addOutPara(buffer);
	}
	zuLesenderWert = false;

}
/**
 * endPrefixMapping - Methodenkommentar.
 */
public void endPrefixMapping(String arg1) throws org.xml.sax.SAXException {}
public Vector getInOut() {
	return inOut;
}
/**
 * ignorableWhitespace - Methodenkommentar.
 */
public void ignorableWhitespace(char[] arg1, int arg2, int arg3) throws org.xml.sax.SAXException {}
/**
 * processingInstruction - Methodenkommentar.
 */
public void processingInstruction(String arg1, String arg2) throws org.xml.sax.SAXException {}
/**
 * setDocumentLocator - Methodenkommentar.
 */
public void setDocumentLocator(org.xml.sax.Locator arg1) {}
/**
 * skippedEntity - Methodenkommentar.
 */
public void skippedEntity(String arg1) throws org.xml.sax.SAXException {} 
/**
 * startDocument - Methodenkommentar.
 */
public void startDocument() throws org.xml.sax.SAXException {
	
	inOut = new Vector();
	this.aktMethode = new String("");
	this.aktObjekt = new String("");
	this.aktParameter = new String("");
	this.zuLesenderWert = false;

	
}
/**
 * startElement - Methodenkommentar.
 */
public void startElement(String arg1, String arg2, String arg3, org.xml.sax.Attributes arg4) throws org.xml.sax.SAXException {

String attr;

 

    zuLesenderWert = false;
    if  (arg4.getLength() > 0) {
	    attr = arg4.getValue("typ");
		if  (attr.equals("object")) {
			// ist das Startelement von einem Testobjekt
			aktObjekt = arg2;
			testObject = new TestObject(arg2);
		}
		else {
			if  (attr.equals("methode")) {
				// ist das Startelement von einer Methode
				if  (testObject == null) {
					testObject = new TestObject(aktObjekt);
				}
				aktMethode = arg2;
				testObject.setNummer(arg4.getValue("nummer"));
				testObject.setMethode(arg2);
			}
			else {
			    // es werden In- oder OutputElemente kommen
				if (attr.equals("in") || attr.equals("out")) {
					aktParameter = attr;
				}	
			}
		}
    }
    else {
    // kein Typ weist darauf hin, da� der naechste Parseschritt
    // In- oder Outputwert lesen muss
		if  (aktParameter.equals("in")) {
	        testObject.addInPara(new String());
		}
        else {
	        if  (aktParameter.equals("out")) { 
	            testObject.addOutPara(new String());
	        }
        }
        zuLesenderWert = true;
        buffer = new String();
    }
}
/**
 * startPrefixMapping - Methodenkommentar.
 */
public void startPrefixMapping(String arg1, String arg2) throws org.xml.sax.SAXException {}
}
