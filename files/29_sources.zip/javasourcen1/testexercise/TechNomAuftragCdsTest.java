package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (17.02.2003 18:15:12)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.go.auftrag.types.TechNomAuftragCds;

public class TechNomAuftragCdsTest extends com.dcag.s55.go.auftrag.types.TechNomAuftragCds {

public static int ANZ_STRUKTUR_ELEM = 129;


public TechNomAuftragCdsTest() {
	
	super();
	initialisiere();	

}
public java.util.Vector equals(TechNomAuftragCds t) {

   java.util.Vector vec = new java.util.Vector();
   

   if  (!this.getAbladeKey().getGebtDbagNr().equals(t.getAbladeKey().getGebtDbagNr())) {
	   TestResult res = new TestResult(this.getAbladeKey().getGebtDbagNr()  ,t.getAbladeKey().getGebtDbagNr()  ,"DbagNr");
       vec.add(res);      	   
   }

   if  (!this.getAbladeKey().getKnotAbladeschl().equals(t.getAbladeKey().getKnotAbladeschl())) {
	   TestResult res = new TestResult(this.getAbladeKey().getKnotAbladeschl()  ,t.getAbladeKey().getKnotAbladeschl()  ,"Abladeschl");
       vec.add(res);      	   
   }

   if  (!this.getAbladeLangtext().equals(t.getAbladeLangtext())) {
	   TestResult res = new TestResult(this.getAbladeLangtext()  ,t.getAbladeLangtext()  ,"AbladeLangtext");
       vec.add(res);      	   
   }

   if  (!this.getAddFees().equals(t.getAddFees())) {
	   TestResult res = new TestResult(this.getAddFees()  ,t.getAddFees()  ,"AddFees");
       vec.add(res);      	   
   }
   
   if  (!this.getAgreedConfDateFrom().getEinheit().equals(t.getAgreedConfDateFrom().getEinheit())) {
	   TestResult res = new TestResult(this.getAgreedConfDateFrom().getEinheit()  ,t.getAgreedConfDateFrom().getEinheit()  ,"AgreedConfDateFrom_Einheit");
       vec.add(res);      	   
   }

   if  (!this.getAgreedConfDateFrom().getZeitangabe().equals(t.getAgreedConfDateFrom().getZeitangabe())) {
	   TestResult res = new TestResult(this.getAgreedConfDateFrom().getZeitangabe()  ,t.getAgreedConfDateFrom().getZeitangabe()  ,"AgreedConfDateFrom_Zeitangabe");
       vec.add(res);      	   
   }

   if  (!this.getAgreedConfDateTo().getEinheit().equals(t.getAgreedConfDateTo().getEinheit())) {
	   TestResult res = new TestResult(this.getAgreedConfDateTo().getEinheit()  , t.getAgreedConfDateTo().getEinheit()  ,"AgreedConfDateTo_Einheit");
       vec.add(res);      	   
   }

   if  (!this.getAgreedConfDateTo().getZeitangabe().equals(t.getAgreedConfDateTo().getZeitangabe())) {
	   TestResult res = new TestResult(this.getAgreedConfDateTo().getZeitangabe()  ,t.getAgreedConfDateTo().getZeitangabe()  ,"AgreedConfDateTo_Zeitangabe");
       vec.add(res);      	   
   }

   if  (!this.getAllocSearchFlag().equals(t.getAllocSearchFlag())) {
	   TestResult res = new TestResult(this.getAllocSearchFlag()  ,t.getAllocSearchFlag()  ,"AllocSearchFlag");
       vec.add(res);      	   
   }

   if  (!this.getAnnuGrund().equals(t.getAnnuGrund())) {
	   TestResult res = new TestResult(this.getAnnuGrund()  ,t.getAnnuGrund()  ,"AnnuGrund");
       vec.add(res);      	   
   }

   if  (!this.getAuftEindat().getJahr().equals(t.getAuftEindat().getJahr())) {
	   TestResult res = new TestResult(this.getAuftEindat().getJahr() ,t.getAuftEindat().getJahr() ,"AuftEindat_Jahr");
       vec.add(res);      	   
   }

   if  (!this.getAuftEindat().getMonat().equals(t.getAuftEindat().getMonat())) {
	   TestResult res = new TestResult(this.getAuftEindat().getMonat() ,t.getAuftEindat().getMonat() ,"AuftEindat_Monat");
       vec.add(res);      	   
   }
   
   if  (!this.getAuftEindat().getTag().equals(t.getAuftEindat().getTag())) {
	   TestResult res = new TestResult(this.getAuftEindat().getTag() ,t.getAuftEindat().getTag() ,"AuftEindat_Tag");
       vec.add(res);      	   
   }
   
   if  (!this.getBasicModelDisc().equals(t.getBasicModelDisc())) {
	   TestResult res = new TestResult(this.getBasicModelDisc() ,t.getBasicModelDisc(),"BasicModelDisc");
       vec.add(res);      	   
   }

   if  (!this.getBaumuster().getAufbauart().equals(t.getBaumuster().getAufbauart())) {
       TestResult res = new TestResult(this.getBaumuster().getAufbauart(), t.getBaumuster().getAufbauart(), "Baumuster_Aufbauart");
       vec.add(res);
   }
   
   if  (!this.getBaumuster().getBaureihe().equals(t.getBaumuster().getBaureihe())) {
       TestResult res = new TestResult(this.getBaumuster().getBaureihe(), t.getBaumuster().getBaureihe(), "Baumuster_Baureihe");
       vec.add(res);
   }
   
   if  (!this.getBaumuster().getGetriebe().equals(t.getBaumuster().getGetriebe())) {
       TestResult res = new TestResult(this.getBaumuster().getGetriebe(), t.getBaumuster().getGetriebe(), "Baumuster_Getriebe");
       vec.add(res);
   }
   
   if  (!this.getBaumuster().getLenkung().equals(t.getBaumuster().getLenkung())) {
       TestResult res = new TestResult(this.getBaumuster().getLenkung(), t.getBaumuster().getLenkung(), "Baumuster_Lenkung");
       vec.add(res);
   }
   
   if  (!this.getBestaetDat().getJahr().equals(t.getBestaetDat().getJahr())) {
       TestResult res = new TestResult(this.getBestaetDat().getJahr(), t.getBestaetDat().getJahr(), "BestaetDat_Jahr");
       vec.add(res);
   }
   
   if  (!this.getBestaetDat().getMonat().equals(t.getBestaetDat().getMonat())) {
       TestResult res = new TestResult(this.getBestaetDat().getMonat(), t.getBestaetDat().getMonat(), "BestaetDat_Monat");
       vec.add(res);
   }    
   
   if  (!this.getBestaetDat().getTag().equals(t.getBestaetDat().getTag())) {
       TestResult res = new TestResult(this.getBestaetDat().getTag(), t.getBestaetDat().getTag(), "BestaetDat_Tag");
       vec.add(res);
   }
   
   if  (!this.getCommRecDealer().equals(t.getCommRecDealer())) {
       TestResult res = new TestResult(this.getCommRecDealer(), t.getCommRecDealer(), "CommRecDealer");
       vec.add(res);
   }
   
   if  (!this.getConfDateFrom().getEinheit().equals(t.getConfDateFrom().getEinheit())) {
       TestResult res = new TestResult(this.getConfDateFrom().getEinheit(), t.getConfDateFrom().getEinheit(), "ConfDateFrom_Einheit");
       vec.add(res);
   }
   
   if  (!this.getConfDateFrom().getZeitangabe().equals(t.getConfDateFrom().getZeitangabe())) {
       TestResult res = new TestResult(this.getConfDateFrom().getZeitangabe(), t.getConfDateFrom().getZeitangabe(), "ConfDateFrom_Zeitangabe");
       vec.add(res);
   }
       
   if  (!this.getConfDateTo().getEinheit().equals(t.getConfDateTo().getEinheit())) {
       TestResult res = new TestResult(this.getConfDateTo().getEinheit(), t.getConfDateTo().getEinheit(), "ConfDateTo_Einheit");
       vec.add(res);
   }
   
   if  (!this.getConfDateTo().getZeitangabe().equals(t.getConfDateTo().getZeitangabe())) {
       TestResult res = new TestResult(this.getConfDateTo().getZeitangabe(), t.getConfDateTo().getZeitangabe(), "ConfDateTo_Zeitangabe");
       vec.add(res);
   }
      
   if  (!this.getConfirmationMode().equals(t.getConfirmationMode())) {
       TestResult res = new TestResult(this.getConfirmationMode(), t.getConfirmationMode(), "ConfirmationMode");
       vec.add(res);
   }
   
   if  (!this.getConsulatFee().equals(t.getConsulatFee())) {
       TestResult res = new TestResult(this.getConsulatFee(), t.getConsulatFee(), "ConsulatFee");
       vec.add(res);
   }
   
   if  (!this.getCustOrigWishFrom().getJahr().equals(t.getCustOrigWishFrom().getJahr())) {
       TestResult res = new TestResult(this.getCustOrigWishFrom().getJahr(), t.getCustOrigWishFrom().getJahr(), "CustOrigWishFrom_Jahr");
       vec.add(res);
   }
      
   if  (!this.getCustOrigWishFrom().getMonat().equals(t.getCustOrigWishFrom().getMonat())) {
       TestResult res = new TestResult(this.getCustOrigWishFrom().getMonat(), t.getCustOrigWishFrom().getMonat(), "CustOrigWishFrom_Monat");
       vec.add(res);
   }
   
   if  (!this.getCustOrigWishFrom().getTag().equals(t.getCustOrigWishFrom().getTag())) {
       TestResult res = new TestResult(this.getCustOrigWishFrom().getTag(), t.getCustOrigWishFrom().getTag(), "CustOrigWishFrom_Tag");
       vec.add(res);
   }
       
   if  (!this.getCustOrigWishTo().getJahr().equals(t.getCustOrigWishTo().getJahr())) {
       TestResult res = new TestResult(this.getCustOrigWishTo().getJahr(), t.getCustOrigWishTo().getJahr(), "CustOrigWishTo_Jahr");
       vec.add(res);
   }
   
   if  (!this.getCustOrigWishTo().getMonat().equals(t.getCustOrigWishTo().getMonat())) {
       TestResult res = new TestResult(this.getCustOrigWishTo().getMonat(), t.getCustOrigWishTo().getMonat(), "CustOrigWishTo_Monat");
       vec.add(res);
   }
   
   if  (!this.getCustOrigWishTo().getTag().equals(t.getCustOrigWishTo().getTag())) {
       TestResult res = new TestResult(this.getCustOrigWishTo().getTag(), t.getCustOrigWishTo().getTag(), "CustOrigWishTo_Tag");
       vec.add(res);
   }
   
   if  (!this.getCustWishDateFrom().getEinheit().equals(t.getCustWishDateFrom().getEinheit())) {
       TestResult res = new TestResult(this.getCustWishDateFrom().getEinheit(), t.getCustWishDateFrom().getEinheit(), "CustWishDateFrom_Einheit");
       vec.add(res);
   }
       
   if  (!this.getCustWishDateFrom().getZeitangabe().equals(t.getCustWishDateFrom().getZeitangabe())) {
       TestResult res = new TestResult(this.getCustWishDateFrom().getZeitangabe(), t.getCustWishDateFrom().getZeitangabe(), "CustWishDateFrom_Zeitangabe");
       vec.add(res);
   }
   
   if  (!this.getCustWishDateTo().getEinheit().equals(t.getCustWishDateTo().getEinheit())) {
       TestResult res = new TestResult(this.getCustWishDateTo().getEinheit(), t.getCustWishDateTo().getEinheit(), "CustWishDateTo_Einheit");
       vec.add(res);
   }
   
   if  (!this.getCustWishDateTo().getZeitangabe().equals(t.getCustWishDateTo().getZeitangabe())) {
       TestResult res = new TestResult(this.getCustWishDateTo().getZeitangabe(), t.getCustWishDateTo().getZeitangabe(), "CustWishDateTo_Zeitangabe");
       vec.add(res);
   }
   
   if  (!this.getDateOrdPlace().getJahr().equals(t.getDateOrdPlace().getJahr())) {
       TestResult res = new TestResult(this.getDateOrdPlace().getJahr(), t.getDateOrdPlace().getJahr(), "DateOrdPlace_Jahr");
       vec.add(res);
   }   
   
   if  (!this.getDateOrdPlace().getMonat().equals(t.getDateOrdPlace().getMonat())) {
       TestResult res = new TestResult(this.getDateOrdPlace().getMonat(), t.getDateOrdPlace().getMonat(), "DateOrdPlace_Monat");
       vec.add(res);
   }

   if  (!this.getDateOrdPlace().getTag().equals(t.getDateOrdPlace().getTag())) {
       TestResult res = new TestResult(this.getDateOrdPlace().getTag(), t.getDateOrdPlace().getTag(), "DateOrdPlace_Tag");
       vec.add(res);
   }   
   
   if  (!this.getDebKtonr().equals(t.getDebKtonr())) {
       TestResult res = new TestResult(this.getDebKtonr(), t.getDebKtonr(), "DebKtonr");
       vec.add(res);
   }

   if  (!this.getDelivMode().equals(t.getDelivMode())) {
       TestResult res = new TestResult(this.getDelivMode(), t.getDelivMode(), "DelivMode");
       vec.add(res);
   }   
   
   if  (!this.getDepPort().equals(t.getDepPort())) {
       TestResult res = new TestResult(this.getDepPort(), t.getDepPort(), "DepPort");
       vec.add(res);
   }

   if  (!this.getDiscount().equals(t.getDiscount())) {
       TestResult res = new TestResult(this.getDiscount(), t.getDiscount(), "Discount");
       vec.add(res);
   }   
   
   if  (!this.getDiscountMode().equals(t.getDiscountMode())) {
       TestResult res = new TestResult(this.getDiscountMode(), t.getDiscountMode(), "DiscountMode");
       vec.add(res);
   }

   if  (!this.getDistDocu().equals(t.getDistDocu())) {
       TestResult res = new TestResult(this.getDistDocu(), t.getDistDocu(), "DistDocu");
       vec.add(res);
   }   
   
   if  (!this.getDistNr().equals(t.getDistNr())) {
       TestResult res = new TestResult(this.getDistNr(), t.getDistNr(), "DistNr");
       vec.add(res);
   }

   if  (!this.getDownPayment().equals(t.getDownPayment())) {
       TestResult res = new TestResult(this.getDownPayment(), t.getDownPayment(), "DownPayment");
       vec.add(res);
   }

   if  (!this.getFaktOnlKc().equals(t.getFaktOnlKc())) {
       TestResult res = new TestResult(this.getFaktOnlKc(), t.getFaktOnlKc(), "FaktOnlKc");
       vec.add(res);
   }   
   
   if  (!this.getFeasibility().getFkbkAnlauf().equals(t.getFeasibility().getFkbkAnlauf())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkAnlauf(), t.getFeasibility().getFkbkAnlauf(), "Feasibility_FkbkAnlauf");
       vec.add(res);
   }

   if  (!this.getFeasibility().getFkbkBaubarKnz().equals(t.getFeasibility().getFkbkBaubarKnz())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkBaubarKnz(), t.getFeasibility().getFkbkBaubarKnz(), "Feasibility_FkbkBaubarKnz");
       vec.add(res);
   }

   if  (!this.getFeasibility().getFkbkObkFehlt().equals(t.getFeasibility().getFkbkObkFehlt())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkObkFehlt(), t.getFeasibility().getFkbkObkFehlt(), "Feasibility_FkbkObkFehlt");
       vec.add(res);
   }

   if  (!this.getFeasibility().getFkbkPruefdatum().getJahr().equals(t.getFeasibility().getFkbkPruefdatum().getJahr())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkPruefdatum().getJahr(), t.getFeasibility().getFkbkPruefdatum().getJahr(), "Feasibility_FkbkPruefdatum_Jahr");
       vec.add(res);
   }   
   
   if  (!this.getFeasibility().getFkbkPruefdatum().getMonat().equals(t.getFeasibility().getFkbkPruefdatum().getMonat())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkPruefdatum().getMonat(), t.getFeasibility().getFkbkPruefdatum().getMonat(), "Feasibility_FkbkPruefdatum_Monat");
       vec.add(res);
   }   
   
   if  (!this.getFeasibility().getFkbkPruefdatum().getTag().equals(t.getFeasibility().getFkbkPruefdatum().getTag())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkPruefdatum().getTag(), t.getFeasibility().getFkbkPruefdatum().getTag(), "Feasibility_FkbkPruefdatum_Tag");
       vec.add(res);
   }

   if  (!this.getFeasibility().getFkbkSperrsv().equals(t.getFeasibility().getFkbkSperrsv())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkSperrsv(), t.getFeasibility().getFkbkSperrsv(), "Feasibility_FkbkSperrsv");
       vec.add(res);
   }

   if  (!this.getFeasibility().getFkbkTeilspez().equals(t.getFeasibility().getFkbkTeilspez())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkTeilspez(), t.getFeasibility().getFkbkTeilspez(), "Feasibility_FkbkTeilspez");
       vec.add(res);
   }   
   
   if  (!this.getFeasibility().getFkbkWerkszuord().equals(t.getFeasibility().getFkbkWerkszuord())) {
       TestResult res = new TestResult(this.getFeasibility().getFkbkWerkszuord(), t.getFeasibility().getFkbkWerkszuord(), "Feasibility_FkbkWerkszuord");
       vec.add(res);
   }   
   
   if  (!this.getFeasibility().getFzkfVersionsnr().equals(t.getFeasibility().getFzkfVersionsnr())) {
       TestResult res = new TestResult(this.getFeasibility().getFzkfVersionsnr(), t.getFeasibility().getFzkfVersionsnr(), "Feasibility_FzkfVersionsnr");
       vec.add(res);
   }


   if  (!this.getFeasibility().getTechAenVersion().equals(t.getFeasibility().getTechAenVersion())) {
       TestResult res = new TestResult(this.getFeasibility().getTechAenVersion(), t.getFeasibility().getTechAenVersion(), "Feasibility_TechAenVersion");
       vec.add(res);
   }   
   
   if  (!this.getFreight().equals(t.getFreight())) {
       TestResult res = new TestResult(this.getFreight(), t.getFreight(), "Freight");
       vec.add(res);
   }   
   
   if  (!this.getInlandFlag().equals(t.getInlandFlag())) {
       TestResult res = new TestResult(this.getInlandFlag(), t.getInlandFlag(), "InlandFlag");
       vec.add(res);
   }

   if  (!this.getIntLicense().equals(t.getIntLicense())) {
       TestResult res = new TestResult(this.getIntLicense(), t.getIntLicense(), "IntLicense");
       vec.add(res);
   }

   if  (!this.getLanguage().equals(t.getLanguage())) {
       TestResult res = new TestResult(this.getLanguage(), t.getLanguage(), "Language");
       vec.add(res);
   }   
   
   if  (!this.getLetterOfCredit().equals(t.getLetterOfCredit())) {
       TestResult res = new TestResult(this.getLetterOfCredit(), t.getLetterOfCredit(), "LetterOfCredit");
       vec.add(res);
   }   
   
   if  (!this.getLowerPaint().equals(t.getLowerPaint())) {
       TestResult res = new TestResult(this.getLowerPaint(), t.getLowerPaint(), "LowerPaint");
       vec.add(res);
   }

   if  (!this.getLtAng().equals(t.getLtAng())) {
       TestResult res = new TestResult(this.getLtAng(), t.getLtAng(), "LtAng");
       vec.add(res);
   }   
   
   if  (!this.getMassDiscNr().equals(t.getMassDiscNr())) {
       TestResult res = new TestResult(this.getMassDiscNr(), t.getMassDiscNr(), "MassDiscNr");
       vec.add(res);
   }

   if  (!this.getMbvsNr().equals(t.getMbvsNr())) {
       TestResult res = new TestResult(this.getMbvsNr(), t.getMbvsNr(), "MbvsNr");
       vec.add(res);
   }

   if  (!this.getOldCommNr().getJahr1().equals(t.getOldCommNr().getJahr1())) {
       TestResult res = new TestResult(this.getOldCommNr().getJahr1(), t.getOldCommNr().getJahr1(), "OldCommNr_Jahr1");
       vec.add(res);
   }   
   
   if  (!this.getOldCommNr().getLfdnr().equals(t.getOldCommNr().getLfdnr())) {
       TestResult res = new TestResult(this.getOldCommNr().getLfdnr(), t.getOldCommNr().getLfdnr(), "OldCommNr_Lfdnr");
       vec.add(res);
   }   
   
   if  (!this.getOldCommNr().getNdl().equals(t.getOldCommNr().getNdl())) {
       TestResult res = new TestResult(this.getOldCommNr().getNdl(), t.getOldCommNr().getNdl(), "OldCommNr_Ndl");
       vec.add(res);
   }

   if  (!this.getOldCommNr().getSparte().equals(t.getOldCommNr().getSparte())) {
       TestResult res = new TestResult(this.getOldCommNr().getSparte(), t.getOldCommNr().getSparte(), "OldCommNr_Sparte");
       vec.add(res);
   }

   if  (!this.getOrderClass().getFrueher().equals(t.getOrderClass().getFrueher())) {
       TestResult res = new TestResult(this.getOrderClass().getFrueher(), t.getOrderClass().getFrueher(), "OrderClass_Frueher");
       vec.add(res);
   }   
   
   if  (!this.getOrderClass().getKlasse10().equals(t.getOrderClass().getKlasse10())) {
       TestResult res = new TestResult(this.getOrderClass().getKlasse10(), t.getOrderClass().getKlasse10(), "OrderClass_Klasse10");
       vec.add(res);
   }

   if  (!this.getOrderClass().getKlasse4().equals(t.getOrderClass().getKlasse4())) {
       TestResult res = new TestResult(this.getOrderClass().getKlasse4(), t.getOrderClass().getKlasse4(), "OrderClass_Klasse4");
       vec.add(res);
   }   
   
   if  (!this.getOrderClass().getKlasse5().equals(t.getOrderClass().getKlasse5())) {
       TestResult res = new TestResult(this.getOrderClass().getKlasse5(), t.getOrderClass().getKlasse5(), "OrderClass_Klasse5");
       vec.add(res);
   }   
   
   if  (!this.getOrderClass().getKlasse6().equals(t.getOrderClass().getKlasse6())) {
       TestResult res = new TestResult(this.getOrderClass().getKlasse6(), t.getOrderClass().getKlasse6(), "OrderClass_Klasse6");
       vec.add(res);
   }

   if  (!this.getOrderClass().getKlasse7().equals(t.getOrderClass().getKlasse7())) {
       TestResult res = new TestResult(this.getOrderClass().getKlasse7(), t.getOrderClass().getKlasse7(), "OrderClass_Klasse7");
       vec.add(res);
   }   
   
   if  (!this.getOrderClass().getKlasse8().equals(t.getOrderClass().getKlasse8())) {
       TestResult res = new TestResult(this.getOrderClass().getKlasse8(), t.getOrderClass().getKlasse8(), "OrderClass_Klasse8");
       vec.add(res);
   }

   if  (!this.getOrderClass().getKlasse9().equals(t.getOrderClass().getKlasse9())) {
       TestResult res = new TestResult(this.getOrderClass().getKlasse9(), t.getOrderClass().getKlasse9(), "OrderClass_Klasse9");
       vec.add(res);
   }

   if  (!this.getOrderClass().getKundeBestand().equals(t.getOrderClass().getKundeBestand())) {
       TestResult res = new TestResult(this.getOrderClass().getKundeBestand(), t.getOrderClass().getKundeBestand(), "OrderClass_KundeBestand");
       vec.add(res);
   }   
   
   if  (!this.getOrderClass().getSpaeter().equals(t.getOrderClass().getSpaeter())) {
       TestResult res = new TestResult(this.getOrderClass().getSpaeter(), t.getOrderClass().getSpaeter(), "OrderClass_Spaeter");
       vec.add(res);
   }   
   
   if  (!this.getOrderConf().equals(t.getOrderConf())) {
       TestResult res = new TestResult(this.getOrderConf(), t.getOrderConf(), "OrderConf");
       vec.add(res);
   }

   if  (!this.getOrderMode().equals(t.getOrderMode())) {
       TestResult res = new TestResult(this.getOrderMode(), t.getOrderMode(), "OrderMode");
       vec.add(res);
   }   
   
   if  (!this.getOrderState().equals(t.getOrderState())) {
       TestResult res = new TestResult(this.getOrderState(), t.getOrderState(), "OrderState");
       vec.add(res);
   }

   if  (!this.getOrdTypeExp().equals(t.getOrdTypeExp())) {
       TestResult res = new TestResult(this.getOrdTypeExp(), t.getOrdTypeExp(), "OrdTypeExp");
       vec.add(res);
   }

   if  (!this.getPlatzWunsch().getJahr().equals(t.getPlatzWunsch().getJahr())) {
       TestResult res = new TestResult(this.getPlatzWunsch().getJahr(), t.getPlatzWunsch().getJahr(), "PlatzWunsch_Jahr");
       vec.add(res);
   }   
   
   if  (!this.getPlatzWunsch().getMonat().equals(t.getPlatzWunsch().getMonat())) {
       TestResult res = new TestResult(this.getPlatzWunsch().getMonat(), t.getPlatzWunsch().getMonat(), "PlatzWunsch_Monat");
       vec.add(res);
   }   
   
   if  (!this.getPlatzWunsch().getTag().equals(t.getPlatzWunsch().getTag())) {
       TestResult res = new TestResult(this.getPlatzWunsch().getTag(), t.getPlatzWunsch().getTag(), "PlatzWunsch_Tag");
       vec.add(res);
   }

   if  (!this.getPlausibility().equals(t.getPlausibility())) {
       TestResult res = new TestResult(this.getPlausibility(), t.getPlausibility(), "Plausibility");
       vec.add(res);
   }

   if  (!this.getProdGruppe().equals(t.getProdGruppe())) {
       TestResult res = new TestResult(this.getProdGruppe(), t.getProdGruppe(), "ProdGruppe");
       vec.add(res);
   }   
   
   if  (!this.getProdInfoRef().equals(t.getProdInfoRef())) {
       TestResult res = new TestResult(this.getProdInfoRef(), t.getProdInfoRef(), "ProdInfoRef");
       vec.add(res);
   }

   if  (!this.getProduktionNr().equals(t.getProduktionNr())) {
       TestResult res = new TestResult(this.getProduktionNr(), t.getProduktionNr(), "ProduktionNr");
       vec.add(res);
   }   
   
   if  (!this.getProdWishDateFrom().getEinheit().equals(t.getProdWishDateFrom().getEinheit())) {
       TestResult res = new TestResult(this.getProdWishDateFrom().getEinheit(), t.getProdWishDateFrom().getEinheit(), "ProdWishDateFrom_Einheit");
       vec.add(res);
   }   
   
   if  (!this.getProdWishDateFrom().getZeitangabe().equals(t.getProdWishDateFrom().getZeitangabe())) {
       TestResult res = new TestResult(this.getProdWishDateFrom().getZeitangabe(), t.getProdWishDateFrom().getZeitangabe(), "ProdWishDateFrom_Zeitangabe");
       vec.add(res);
   }

   if  (!this.getProdWishDateTo().getEinheit().equals(t.getProdWishDateTo().getEinheit())) {
       TestResult res = new TestResult(this.getProdWishDateTo().getEinheit(), t.getProdWishDateTo().getEinheit(), "ProdWishDateTo_Einheit");
       vec.add(res);
   }   
   
   if  (!this.getProdWishDateTo().getZeitangabe().equals(t.getProdWishDateTo().getZeitangabe())) {
       TestResult res = new TestResult(this.getProdWishDateTo().getZeitangabe(), t.getProdWishDateTo().getZeitangabe(), "ProdWishDateTo_Zeitangabe");
       vec.add(res);
   }

   if  (!this.getPropConfDateFrom().getEinheit().equals(t.getPropConfDateFrom().getEinheit())) {
       TestResult res = new TestResult(this.getPropConfDateFrom().getEinheit(), t.getPropConfDateFrom().getEinheit(), "PropConfDateFrom_Einheit");
       vec.add(res);
   }   
   
   if  (!this.getPropConfDateFrom().getZeitangabe().equals(t.getPropConfDateFrom().getZeitangabe())) {
       TestResult res = new TestResult(this.getPropConfDateFrom().getZeitangabe(), t.getPropConfDateFrom().getZeitangabe(), "PropConfDateFrom_Zeitangabe");
       vec.add(res);
   }

   if  (!this.getPropConfDateTo().getEinheit().equals(t.getPropConfDateTo().getEinheit())) {
       TestResult res = new TestResult(this.getPropConfDateTo().getEinheit(), t.getPropConfDateTo().getEinheit(), "PropConfDateTo_Einheit");
       vec.add(res);
   }   
   
   if  (!this.getPropConfDateTo().getZeitangabe().equals(t.getPropConfDateTo().getZeitangabe())) {
       TestResult res = new TestResult(this.getPropConfDateTo().getZeitangabe(), t.getPropConfDateTo().getZeitangabe(), "PropConfDateTo_Zeitangabe");
       vec.add(res);
   }   
   
   if  (!this.getRoadInsurance().equals(t.getRoadInsurance())) {
       TestResult res = new TestResult(this.getRoadInsurance(), t.getRoadInsurance(), "RoadInsurance");
       vec.add(res);
   }   
   
   if  (!this.getSaleOrgId().equals(t.getSaleOrgId())) {
       TestResult res = new TestResult(this.getSaleOrgId(), t.getSaleOrgId(), "SaleOrgId");
       vec.add(res);
   }

   if  (!this.getTermBes().equals(t.getTermBes())) {
       TestResult res = new TestResult(this.getTermBes(), t.getTermBes(), "TermBes");
       vec.add(res);
   }   
   
   if  (!this.getTerminverzug().equals(t.getTerminverzug())) {
       TestResult res = new TestResult(this.getTerminverzug(), t.getTerminverzug(), "Terminverzug");
       vec.add(res);
   }   
   
   if  (!this.getTimePeriodKeyWish().getZtraEinheit().equals(t.getTimePeriodKeyWish().getZtraEinheit())) {
       TestResult res = new TestResult(this.getTimePeriodKeyWish().getZtraEinheit(), t.getTimePeriodKeyWish().getZtraEinheit(), "TimePeriodeKeyWish_ZtraEinheit");
       vec.add(res);
   }

   if  (!this.getTimePeriodKeyWish().getZtraKuerzel().equals(t.getTimePeriodKeyWish().getZtraKuerzel())) {
       TestResult res = new TestResult(this.getTimePeriodKeyWish().getZtraKuerzel(), t.getTimePeriodKeyWish().getZtraKuerzel(), "TimePeriodeKeyWish_ZtraKuerzel");
       vec.add(res);
   }

   if  (!this.getTorpass().equals(t.getTorpass())) {
       TestResult res = new TestResult(this.getTorpass(), t.getTorpass(), "Torpass");
       vec.add(res);
   }   
   
   if  (!this.getTransInsurance().equals(t.getTransInsurance())) {
       TestResult res = new TestResult(this.getTransInsurance(), t.getTransInsurance(), "TransInsurance");
       vec.add(res);
   }

   if  (!this.getUebernahmeDat().getJahr().equals(t.getUebernahmeDat().getJahr())) {
       TestResult res = new TestResult(this.getUebernahmeDat().getJahr(), t.getUebernahmeDat().getJahr(), "UebernahmeDat_Jahr");
       vec.add(res);
   }   
   
   if  (!this.getUebernahmeDat().getMonat().equals(t.getUebernahmeDat().getMonat())) {
       TestResult res = new TestResult(this.getUebernahmeDat().getMonat(), t.getUebernahmeDat().getMonat(), "UebernahmeDat_Monat");
       vec.add(res);
   }

   if  (!this.getUebernahmeDat().getTag().equals(t.getUebernahmeDat().getTag())) {
       TestResult res = new TestResult(this.getUebernahmeDat().getTag(), t.getUebernahmeDat().getTag(), "UebernahmeDat_Tag");
       vec.add(res);
   }   
   
   if  (!this.getUebernahmeDat().getTag().equals(t.getUebernahmeDat().getTag())) {
       TestResult res = new TestResult(this.getUebernahmeDat().getTag(), t.getUebernahmeDat().getTag(), "UebernahmeDat_Tag");
       vec.add(res);
   }

   if  (!this.getUndecVehicle().equals(t.getUndecVehicle())) {
       TestResult res = new TestResult(this.getUndecVehicle(), t.getUndecVehicle(), "UndecVehicle");
       vec.add(res);
   }   
   
   if  (!this.getUpholst().equals(t.getUpholst())) {
       TestResult res = new TestResult(this.getUpholst(), t.getUpholst(), "Upholst");
       vec.add(res);
   }   
   
   if  (!this.getUpperPaint().equals(t.getUpperPaint())) {
       TestResult res = new TestResult(this.getUpperPaint(), t.getUpperPaint(), "UpperPaint");
       vec.add(res);
   }

   if  (!this.getValueAddedTax().equals(t.getValueAddedTax())) {
       TestResult res = new TestResult(this.getValueAddedTax(), t.getValueAddedTax(), "ValueAddedTax");
       vec.add(res);
   }   
   
   if  (!this.getVersFreigKz().equals(t.getVersFreigKz())) {
       TestResult res = new TestResult(this.getVersFreigKz(), t.getVersFreigKz(), "VersFreigKz");
       vec.add(res);
   }

   if  (!this.getVersion().equals(t.getVersion())) {
       TestResult res = new TestResult(this.getVersion(), t.getVersion(), "Version");
       vec.add(res);
   }   

   if  (!this.getVvs().equals(t.getVvs())) {
       TestResult res = new TestResult(this.getVvs(), t.getVvs(), "Vvs");
       vec.add(res);
   }
   


   if  (!this.getWerkMan().equals(t.getWerkMan())) {
       TestResult res = new TestResult(this.getWerkMan(), t.getWerkMan(), "WerkMan");
       vec.add(res);
   }
   

   if  (!this.getWerkMasch().equals(t.getWerkMasch())) {
       TestResult res = new TestResult(this.getWerkMasch(), t.getWerkMasch(), "WerkMasch");
       vec.add(res);
   }
   
   if  (!this.getZahlBed().equals(t.getZahlBed())) {
       TestResult res = new TestResult(this.getZahlBed(), t.getZahlBed(), "ZahlBed");
       vec.add(res);
   }
   
   if  (!this.getZielKfzbr().equals(t.getZielKfzbr())) {
       TestResult res = new TestResult(this.getZielKfzbr(), t.getZielKfzbr(), "ZielKfzbr");
       vec.add(res);
   }

   if  (this.getVtpoPkey().getVtpoPosNr().get() != t.getVtpoPkey().getVtpoPosNr().get()) {
       TestResult res = new TestResult(this.getVtpoPkey().getVtpoPosNr(), t.getVtpoPkey().getVtpoPosNr(), "VtpoPkey_VtpoPosNr");
       vec.add(res);
   }
   
   if  (this.getVtpoPkey().getVtrgPkey().getVtrgNr().getLfdNr().get() != t.getVtpoPkey().getVtrgPkey().getVtrgNr().getLfdNr().get()) {
       TestResult res = new TestResult(this.getVtpoPkey().getVtrgPkey().getVtrgNr().getLfdNr(), t.getVtpoPkey().getVtrgPkey().getVtrgNr().getLfdNr(), "VtpoPkey_LfdNr");
       vec.add(res);
   }
       
   if  (this.getVtpoPkey().getVtrgPkey().getVtrgNr().getPz().get() != t.getVtpoPkey().getVtrgPkey().getVtrgNr().getPz().get()) {
       TestResult res = new TestResult(this.getVtpoPkey().getVtrgPkey().getVtrgNr().getPz(), t.getVtpoPkey().getVtrgPkey().getVtrgNr().getPz(), "VtpoPkey_Pz");
       vec.add(res);
   }

   if  (this.getFeasibility().getPkey().getEzkfKey().get() != t.getFeasibility().getPkey().getEzkfKey().get()) {
       TestResult res = new TestResult(this.getFeasibility().getPkey().getEzkfKey(), t.getFeasibility().getPkey().getEzkfKey(), "Feasibility_Pkey_EzkfKey");
       vec.add(res);
   }

   return vec;


}
public void fuelle(java.util.Vector vec, int pos) {

	if  ( ((String) vec.get(pos+0)).length() > 0)
		getAbladeKey().getGebtDbagNr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+0)));
	if  ( ((String) vec.get(pos+1)).length() > 0)		
		getAbladeKey().getKnotAbladeschl().set(vec.get(pos+1));
	if  ( ((String) vec.get(pos+2)).length() > 0)		
		getAbladeLangtext().set(vec.get(pos+2)); 
	if  ( ((String) vec.get(pos+3)).length() > 0)		
		getAddFees().set(vec.get(pos+3));
	if  ( ((String) vec.get(pos+4)).length() > 0)		
		getAgreedConfDateFrom().getEinheit().set(vec.get(pos+4));
	if  ( ((String) vec.get(pos+5)).length() > 0)		
		getAgreedConfDateFrom().getZeitangabe().set(vec.get(pos+5));
	if  ( ((String) vec.get(pos+6)).length() > 0)		
		getAgreedConfDateTo().getEinheit().set(vec.get(pos+6));
	if  ( ((String) vec.get(pos+7)).length() > 0)		
		getAgreedConfDateTo().getZeitangabe().set(vec.get(pos+7));
	if  ( ((String) vec.get(pos+8)).length() > 0)		
		getAllocSearchFlag().set(vec.get(pos+8));			
	if  ( ((String) vec.get(pos+9)).length() > 0)		 
		getAnnuGrund().set(vec.get(pos+9));
	if  ( ((String) vec.get(pos+10)).length() > 0)		
		getAuftEindat().getJahr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+10)));
	if  ( ((String) vec.get(pos+11)).length() > 0)		
		getAuftEindat().getMonat().set(TechNomAuftragCdsTest.string2int(vec.get(pos+11)));
	if  ( ((String) vec.get(pos+12)).length() > 0)		
		getAuftEindat().getTag().set(TechNomAuftragCdsTest.string2int(vec.get(pos+12)));
	if  ( ((String) vec.get(pos+13)).length() > 0)		
		getBasicModelDisc().set(vec.get(pos+13));			
	if  ( ((String) vec.get(pos+14)).length() > 0)		 
		getBaumuster().getAufbauart().set(vec.get(pos+14));
	if  ( ((String) vec.get(pos+15)).length() > 0)		
		getBaumuster().getBaureihe().set(vec.get(pos+15));
	if  ( ((String) vec.get(pos+16)).length() > 0)		
		getBaumuster().getGetriebe().set(vec.get(pos+16));
	if  ( ((String) vec.get(pos+17)).length() > 0)		
		getBaumuster().getLenkung().set(vec.get(pos+17));
	if  ( ((String) vec.get(pos+18)).length() > 0)		
		getBestaetDat().getJahr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+18)));
	if  ( ((String) vec.get(pos+19)).length() > 0)		
		getBestaetDat().getMonat().set(TechNomAuftragCdsTest.string2int(vec.get(pos+19)));
	if  ( ((String) vec.get(pos+20)).length() > 0)		
		getBestaetDat().getTag().set(TechNomAuftragCdsTest.string2int(vec.get(pos+20)));
	if  ( ((String) vec.get(pos+21)).length() > 0)		
		getCommRecDealer().set(vec.get(pos+21));
	if  ( ((String) vec.get(pos+22)).length() > 0)		
		getConfDateFrom().getEinheit().set(vec.get(pos+22));
	if  ( ((String) vec.get(pos+23)).length() > 0)		
		getConfDateFrom().getZeitangabe().set(vec.get(pos+23));
	if  ( ((String) vec.get(pos+24)).length() > 0)		
		getConfDateTo().getEinheit().set(vec.get(pos+24));
	if  ( ((String) vec.get(pos+25)).length() > 0)		
		getConfDateTo().getZeitangabe().set(vec.get(pos+25));
	if  ( ((String) vec.get(pos+26)).length() > 0)		
		getConfirmationMode().set(vec.get(pos+26));
	if  ( ((String) vec.get(pos+27)).length() > 0)		
		getConsulatFee().set(vec.get(pos+27));
	if  ( ((String) vec.get(pos+28)).length() > 0)		
		getCustOrigWishFrom().getJahr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+28)));
	if  ( ((String) vec.get(pos+29)).length() > 0)		
		getCustOrigWishFrom().getMonat().set(TechNomAuftragCdsTest.string2int(vec.get(pos+29)));
	if  ( ((String) vec.get(pos+30)).length() > 0)		
		getCustOrigWishFrom().getTag().set(TechNomAuftragCdsTest.string2int(vec.get(pos+30)));
	if  ( ((String) vec.get(pos+31)).length() > 0)		
		getCustOrigWishTo().getJahr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+31)));
	if  ( ((String) vec.get(pos+32)).length() > 0)		
		getCustOrigWishTo().getMonat().set(TechNomAuftragCdsTest.string2int(vec.get(pos+32)));
	if  ( ((String) vec.get(pos+33)).length() > 0)		
		getCustOrigWishTo().getTag().set(TechNomAuftragCdsTest.string2int(vec.get(pos+33)));
	if  ( ((String) vec.get(pos+34)).length() > 0)
		getCustWishDateFrom().getEinheit().set(vec.get(pos+34));
	if  ( ((String) vec.get(pos+35)).length() > 0)		
		getCustWishDateFrom().getZeitangabe().set(vec.get(pos+35));
	if  ( ((String) vec.get(pos+36)).length() > 0)		
		getCustWishDateTo().getEinheit().set(vec.get(pos+36));
	if  ( ((String) vec.get(pos+37)).length() > 0)		
	    getCustWishDateTo().getZeitangabe().set(vec.get(pos+37));
	if  ( ((String) vec.get(pos+38)).length() > 0)	    
	    getDateOrdPlace().getJahr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+38)));
	if  ( ((String) vec.get(pos+39)).length() > 0)	    
	    getDateOrdPlace().getMonat().set(TechNomAuftragCdsTest.string2int(vec.get(pos+39)));
	if  ( ((String) vec.get(pos+40)).length() > 0)	    
	    getDateOrdPlace().getTag().set(TechNomAuftragCdsTest.string2int(vec.get(pos+40)));
	if  ( ((String) vec.get(pos+41)).length() > 0)	    
	    getDebKtonr().set(vec.get(pos+41));
	if  ( ((String) vec.get(pos+42)).length() > 0)	    
	    getDelivMode().set(vec.get(pos+42));
	if  ( ((String) vec.get(pos+43)).length() > 0)	    
	    getDepPort().set(vec.get(pos+43));
	if  ( ((String) vec.get(pos+44)).length() > 0)	    
	    getDiscount().set(vec.get(pos+44));
	if  ( ((String) vec.get(pos+45)).length() > 0)	    
	    getDiscountMode().set(vec.get(pos+45));
	if  ( ((String) vec.get(pos+46)).length() > 0)	    
	    getDistDocu().set(vec.get(pos+46));
	if  ( ((String) vec.get(pos+47)).length() > 0)	    
	    getDistNr().set(vec.get(pos+47));
	if  ( ((String) vec.get(pos+48)).length() > 0)	    
	    getDownPayment().set(vec.get(pos+48));
	if  ( ((String) vec.get(pos+49)).length() > 0)	    
	    getFaktOnlKc().set(vec.get(pos+49));
	if  ( ((String) vec.get(pos+50)).length() > 0)	    
	    getFeasibility().getFkbkAnlauf().set(vec.get(pos+50));
	if  ( ((String) vec.get(pos+51)).length() > 0)	    
	    getFeasibility().getFkbkBaubarKnz().set(vec.get(pos+51));
	if  ( ((String) vec.get(pos+52)).length() > 0)	    
	    getFeasibility().getFkbkObkFehlt().set(vec.get(pos+52));
	if  ( ((String) vec.get(pos+53)).length() > 0)	    
	    getFeasibility().getFkbkPruefdatum().getJahr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+53)));
	if  ( ((String) vec.get(pos+54)).length() > 0)	    
	    getFeasibility().getFkbkPruefdatum().getMonat().set(TechNomAuftragCdsTest.string2int(vec.get(pos+54)));
	if  ( ((String) vec.get(pos+55)).length() > 0)	    
	    getFeasibility().getFkbkPruefdatum().getTag().set(TechNomAuftragCdsTest.string2int(vec.get(pos+55)));
	if  ( ((String) vec.get(pos+56)).length() > 0)	    
	    getFeasibility().getFkbkSperrsv().set(vec.get(pos+56));
	if  ( ((String) vec.get(pos+57)).length() > 0)	    
	    getFeasibility().getFkbkTeilspez().set(vec.get(pos+57));
	if  ( ((String) vec.get(pos+58)).length() > 0)	    
	    getFeasibility().getFkbkWerkszuord().set(vec.get(pos+58));
	if  ( ((String) vec.get(pos+59)).length() > 0)	    
	    getFeasibility().getFzkfVersionsnr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+59)));
	if  ( ((String) vec.get(pos+60)).length() > 0)	    
	    getFeasibility().getPkey().getEzkfKey().set(TechNomAuftragCdsTest.string2int(vec.get(pos+60)));
	if  ( ((String) vec.get(pos+61)).length() > 0)	    
	    getFeasibility().getTechAenVersion().set(TechNomAuftragCdsTest.string2int(vec.get(pos+61)));
	if  ( ((String) vec.get(pos+62)).length() > 0)	    
        getFreight().set(vec.get(pos+62));
	if  ( ((String) vec.get(pos+63)).length() > 0)        
        getInlandFlag().set(vec.get(pos+63));
	if  ( ((String) vec.get(pos+64)).length() > 0)        
        getIntLicense().set(vec.get(pos+64));
	if  ( ((String) vec.get(pos+65)).length() > 0)        
        getLanguage().set(vec.get(pos+65));
	if  ( ((String) vec.get(pos+66)).length() > 0)        
        getLetterOfCredit().set(vec.get(pos+66));
	if  ( ((String) vec.get(pos+67)).length() > 0)        
        getLowerPaint().set(vec.get(pos+67));
	if  ( ((String) vec.get(pos+68)).length() > 0)        
        getLtAng().set(vec.get(pos+68));
	if  ( ((String) vec.get(pos+69)).length() > 0)        
        getMassDiscNr().set(vec.get(pos+69));
	if  ( ((String) vec.get(pos+70)).length() > 0)        
        getMbvsNr().set(vec.get(pos+70));
    TechAdsAuftnrTest nr = new TechAdsAuftnrTest();
    nr.fuelle(vec, 71);
    getOldCommNr().set(nr);
	if  ( ((String) vec.get(pos+75)).length() > 0)        
        getOrderClass().getFrueher().set(vec.get(pos+75));
	if  ( ((String) vec.get(pos+76)).length() > 0)        
        getOrderClass().getKlasse10().set(vec.get(pos+76));
	if  ( ((String) vec.get(pos+77)).length() > 0)        
        getOrderClass().getKlasse4().set(vec.get(pos+77));
	if  ( ((String) vec.get(pos+78)).length() > 0)        
        getOrderClass().getKlasse5().set(vec.get(pos+78));
	if  ( ((String) vec.get(pos+79)).length() > 0)        
        getOrderClass().getKlasse6().set(vec.get(pos+79));
	if  ( ((String) vec.get(pos+80)).length() > 0)        
        getOrderClass().getKlasse7().set(vec.get(pos+80));
	if  ( ((String) vec.get(pos+81)).length() > 0)        
        getOrderClass().getKlasse8().set(vec.get(pos+81));
	if  ( ((String) vec.get(pos+82)).length() > 0)        
        getOrderClass().getKlasse9().set(vec.get(pos+82));
	if  ( ((String) vec.get(pos+83)).length() > 0)        
        getOrderClass().getKundeBestand().set(vec.get(pos+83));
	if  ( ((String) vec.get(pos+84)).length() > 0)        
        getOrderClass().getSpaeter().set(vec.get(pos+84));
	if  ( ((String) vec.get(pos+85)).length() > 0)        
        getOrderConf().set(vec.get(pos+85));
	if  ( ((String) vec.get(pos+86)).length() > 0)        
        getOrderMode().set(vec.get(pos+86));
	if  ( ((String) vec.get(pos+87)).length() > 0)        
        getOrderState().set(vec.get(pos+87));
	if  ( ((String) vec.get(pos+88)).length() > 0)        
        getOrdTypeExp().set(vec.get(pos+88));
	if  ( ((String) vec.get(pos+89)).length() > 0)        
        getPlatzWunsch().getJahr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+89)));
	if  ( ((String) vec.get(pos+90)).length() > 0)        
        getPlatzWunsch().getMonat().set(TechNomAuftragCdsTest.string2int(vec.get(pos+90)));
	if  ( ((String) vec.get(pos+91)).length() > 0)        
        getPlatzWunsch().getTag().set(TechNomAuftragCdsTest.string2int(vec.get(pos+91)));
	if  ( ((String) vec.get(pos+92)).length() > 0)        
        getPlausibility().set(vec.get(pos+92));
	if  ( ((String) vec.get(pos+93)).length() > 0)        
        getProdGruppe().set(vec.get(pos+93));
	if  ( ((String) vec.get(pos+94)).length() > 0)        
        getProdInfoRef().set(vec.get(pos+94));
	if  ( ((String) vec.get(pos+95)).length() > 0)        
        getProduktionNr().set(vec.get(pos+95));
	if  ( ((String) vec.get(pos+96)).length() > 0)        
        getProdWishDateFrom().getEinheit().set(vec.get(pos+96));
	if  ( ((String) vec.get(pos+97)).length() > 0)        
        getProdWishDateFrom().getZeitangabe().set(vec.get(pos+97));
	if  ( ((String) vec.get(pos+98)).length() > 0)        
        getProdWishDateTo().getEinheit().set(vec.get(pos+98));
	if  ( ((String) vec.get(pos+99)).length() > 0)        
        getProdWishDateTo().getZeitangabe().set(vec.get(pos+99));
	if  ( ((String) vec.get(pos+100)).length() > 0)        
        getPropConfDateFrom().getEinheit().set(vec.get(pos+100));
	if  ( ((String) vec.get(pos+101)).length() > 0)        
        getPropConfDateFrom().getZeitangabe().set(vec.get(pos+101));
	if  ( ((String) vec.get(pos+102)).length() > 0)        
        getPropConfDateTo().getEinheit().set(vec.get(pos+102));
	if  ( ((String) vec.get(pos+103)).length() > 0)        
        getPropConfDateTo().getZeitangabe().set(vec.get(pos+103));
	if  ( ((String) vec.get(pos+104)).length() > 0)        
        getRoadInsurance().set(vec.get(pos+104));
	if  ( ((String) vec.get(pos+105)).length() > 0)        
        getSaleOrgId().set(vec.get(pos+105));
	if  ( ((String) vec.get(pos+106)).length() > 0)        
        getTermBes().set(vec.get(pos+106));
	if  ( ((String) vec.get(pos+107)).length() > 0)        
        getTerminverzug().set(vec.get(pos+107));
	if  ( ((String) vec.get(pos+108)).length() > 0)        
        getTimePeriodKeyWish().getZtraEinheit().set(vec.get(pos+108));
	if  ( ((String) vec.get(pos+109)).length() > 0)        
        getTimePeriodKeyWish().getZtraKuerzel().set(vec.get(pos+109));
	if  ( ((String) vec.get(pos+110)).length() > 0)        
        getTorpass().set(vec.get(pos+110));
	if  ( ((String) vec.get(pos+111)).length() > 0)        
        getTransInsurance().set(vec.get(pos+111));
	if  ( ((String) vec.get(pos+112)).length() > 0)        
        getUebernahmeDat().getJahr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+112)));
	if  ( ((String) vec.get(pos+113)).length() > 0)        
        getUebernahmeDat().getMonat().set(TechNomAuftragCdsTest.string2int(vec.get(pos+113)));
	if  ( ((String) vec.get(pos+114)).length() > 0)        
        getUebernahmeDat().getTag().set(TechNomAuftragCdsTest.string2int(vec.get(pos+114)));
	if  ( ((String) vec.get(pos+115)).length() > 0)        
        getUndecVehicle().set(vec.get(pos+115));
	if  ( ((String) vec.get(pos+116)).length() > 0)        
        getUpholst().set(vec.get(pos+116));
	if  ( ((String) vec.get(pos+117)).length() > 0)        
        getUpperPaint().set(vec.get(pos+117));
	if  ( ((String) vec.get(pos+118)).length() > 0)        
        getValueAddedTax().set(vec.get(pos+118));
	if  ( ((String) vec.get(pos+119)).length() > 0)        
        getVersFreigKz().set(vec.get(pos+119));
	if  ( ((String) vec.get(pos+120)).length() > 0)        
        getVersion().set(TechNomAuftragCdsTest.string2int(vec.get(pos+120)));
	if  ( ((String) vec.get(pos+121)).length() > 0)        
        getVtpoPkey().getVtpoPosNr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+121)));
	if  ( ((String) vec.get(pos+122)).length() > 0)        
        getVtpoPkey().getVtrgPkey().getVtrgNr().getLfdNr().set(TechNomAuftragCdsTest.string2int(vec.get(pos+122)));
	if  ( ((String) vec.get(pos+123)).length() > 0)        
        getVtpoPkey().getVtrgPkey().getVtrgNr().getPz().set(TechNomAuftragCdsTest.string2int(vec.get(pos+123)));
	if  ( ((String) vec.get(pos+124)).length() > 0)        
        getVvs().set(vec.get(pos+124));
	if  ( ((String) vec.get(pos+125)).length() > 0)        
        getWerkMan().set(vec.get(pos+125));
	if  ( ((String) vec.get(pos+126)).length() > 0)        
        getWerkMasch().set(vec.get(pos+126));
	if  ( ((String) vec.get(pos+127)).length() > 0)        
        getZahlBed().set(vec.get(pos+127));
	if  ( ((String) vec.get(pos+128)).length() > 0)        
        getZielKfzbr().set(vec.get(pos+128));
	
	
}
private void initialisiere() {

   this.getAbladeKey().getGebtDbagNr().set(0);
   this.getAbladeKey().getKnotAbladeschl().set(new String(" "));
   this.getAbladeLangtext().set(new String(" "));
   this.getAddFees().set(new String(" "));
   this.getAgreedConfDateFrom().getEinheit().set(new String(" "));				    				    
   this.getAgreedConfDateFrom().getZeitangabe().set(new String("00000000"));
   this.getAgreedConfDateTo().getEinheit().set(new String(" "));				    				    
   this.getAgreedConfDateTo().getZeitangabe().set(new String("00000000"));
   this.getAllocSearchFlag().set(new String("N"));				    
   this.getAnnuGrund().set(new String(" "));				    
   this.getAuftEindat().getJahr().set(1111);
   this.getAuftEindat().getMonat().set(11);
   this.getAuftEindat().getTag().set(11);
   this.getBasicModelDisc().set(new String(" "));				    
   this.getBaumuster().getAufbauart().set(new String(" "));
   this.getBaumuster().getBaureihe().set(new String(" "));
   this.getBaumuster().getGetriebe().set(new String(" "));
   this.getBaumuster().getLenkung().set(new String(" "));
   this.getBestaetDat().getJahr().set(1111);
   this.getBestaetDat().getMonat().set(11);
   this.getBestaetDat().getTag().set(11);
   this.getCommRecDealer().set(new String(" "));
   this.getConfDateFrom().getEinheit().set(new String(" "));				     
   this.getConfDateFrom().getZeitangabe().set(new String("00000000"));
   this.getConfDateTo().getEinheit().set(new String(" "));				     				    
   this.getConfDateTo().getZeitangabe().set(new String("00000000"));
   this.getConfirmationMode().set(new String(" "));				    
   this.getConsulatFee().set(0);
   this.getCustOrigWishFrom().getJahr().set(1111);
   this.getCustOrigWishFrom().getMonat().set(11);
   this.getCustOrigWishFrom().getTag().set(11);
   this.getCustOrigWishTo().getJahr().set(1111);
   this.getCustOrigWishTo().getMonat().set(11);
   this.getCustOrigWishTo().getTag().set(11);
   this.getCustWishDateFrom().getEinheit().set(new String(" "));
   this.getCustWishDateFrom().getZeitangabe().set(new String("00000000"));
   this.getCustWishDateTo().getEinheit().set(new String(" "));
   this.getCustWishDateTo().getZeitangabe().set(new String("00000000"));
   this.getDateOrdPlace().getJahr().set(1111);
   this.getDateOrdPlace().getMonat().set(11);
   this.getDateOrdPlace().getTag().set(11);
   this.getDebKtonr().set(new String(" "));
   this.getDelivMode().set(new String(" "));
   this.getDepPort().set(new String(" "));
   this.getDiscount().set(new String(" "));
   this.getDiscountMode().set(new String(" "));
   this.getDistDocu().set(new String(" "));
   this.getDistNr().set(new String(" "));
   this.getDownPayment().set(0);
   this.getFaktOnlKc().set(new String(" "));
   this.getFeasibility().getFkbkAnlauf().set(new String(" "));
   this.getFeasibility().getFkbkBaubarKnz().set(new String(" "));
   this.getFeasibility().getFkbkObkFehlt().set(new String(" "));
   this.getFeasibility().getFkbkPruefdatum().getJahr().set(1111);
   this.getFeasibility().getFkbkPruefdatum().getMonat().set(11);
   this.getFeasibility().getFkbkPruefdatum().getTag().set(11);
   this.getFeasibility().getFkbkSperrsv().set(new String(" "));
   this.getFeasibility().getFkbkTeilspez().set(new String(" "));
   this.getFeasibility().getFkbkWerkszuord().set(new String(" "));
   this.getFeasibility().getFzkfVersionsnr().set(0);
   this.getFeasibility().getPkey().getEzkfKey().set(0);
   this.getFeasibility().getTechAenVersion().set(0);
   this.getFreight().set(0);
   this.getInlandFlag().set(new String(" "));
   this.getIntLicense().set(new String(" "));
   this.getLanguage().set(new String(" "));
   this.getLetterOfCredit().set(new String(" "));
   this.getLowerPaint().set(new String(" "));
   this.getLtAng().set(new String(" "));
   this.getMassDiscNr().set(new String(" "));
   this.getMbvsNr().set(new String(" "));
   this.getOldCommNr().set(new TechAdsAuftnrTest());
   this.getOrderClass().getFrueher().set(new String(" "));
   this.getOrderClass().getKlasse10().set(new String(" "));
   this.getOrderClass().getKlasse4().set(new String(" "));
   this.getOrderClass().getKlasse5().set(new String(" "));
   this.getOrderClass().getKlasse6().set(new String(" "));
   this.getOrderClass().getKlasse7().set(new String(" "));
   this.getOrderClass().getKlasse8().set(new String(" "));
   this.getOrderClass().getKlasse9().set(new String(" "));
   this.getOrderClass().getKundeBestand().set(new String(" "));
   this.getOrderClass().getSpaeter().set(new String(" "));
   this.getOrderConf().set(new String(" "));
   this.getOrderMode().set(new String(" "));
   this.getOrderState().set(new String(" "));
   this.getOrdTypeExp().set(new String("    "));
   this.getPlatzWunsch().getJahr().set(1111);
   this.getPlatzWunsch().getMonat().set(11);
   this.getPlatzWunsch().getTag().set(11);
   this.getPlausibility().set(new String(" "));
   this.getProdGruppe().set(new String(" "));
   this.getProdInfoRef().set(new String(" "));
   this.getProduktionNr().set(0);
   this.getProdWishDateFrom().getEinheit().set(new String(" "));
   this.getProdWishDateFrom().getZeitangabe().set(new String("00000000"));
   this.getProdWishDateTo().getEinheit().set(new String(" "));
   this.getProdWishDateTo().getZeitangabe().set(new String("00000000"));
   this.getPropConfDateFrom().getEinheit().set(new String(" "));
   this.getPropConfDateFrom().getZeitangabe().set(new String("00000000"));
   this.getPropConfDateTo().getEinheit().set(new String(" "));
   this.getPropConfDateTo().getZeitangabe().set(new String("00000000"));
   this.getRoadInsurance().set(new String(" "));
   this.getSaleOrgId().set(new String(" "));
   this.getTermBes().set(new String(" "));
   this.getTerminverzug().set(new String(" "));
   this.getTimePeriodKeyWish().getZtraEinheit().set(new String(" "));
   this.getTimePeriodKeyWish().getZtraKuerzel().set(new String(" "));
   this.getTorpass().set(new String(" "));
   this.getTransInsurance().set(new String(" "));
   this.getUebernahmeDat().getJahr().set(1111);
   this.getUebernahmeDat().getMonat().set(11);
   this.getUebernahmeDat().getTag().set(11);
   this.getUndecVehicle().set(new String(" "));
   this.getUpholst().set(new String(" "));
   this.getUpperPaint().set(new String(" "));
   this.getValueAddedTax().set(new String(" "));
   this.getVersFreigKz().set(new String(" "));
   this.getVersion().set(0);
   this.getVtpoPkey().getVtpoPosNr().set(0);
   this.getVtpoPkey().getVtrgPkey().getVtrgNr().getLfdNr().set(0);
   this.getVtpoPkey().getVtrgPkey().getVtrgNr().getPz().set(0);
   this.getVvs().set(new String(" "));
   this.getWerkMan().set(new String(" "));
   this.getWerkMasch().set(new String(" "));
   this.getZahlBed().set(new String(" "));
   this.getZielKfzbr().set(new String(" "));
	


}
public static int string2int(Object o) {

	return new Integer((String) o).intValue();

}
}
