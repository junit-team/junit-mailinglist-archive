package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (18.02.2003 16:45:59)
 * @author: Wolfgang Weber
 */
import java.util.Vector;
import com.dcag.s55.go.auftrag.types.TechNomKundeCds;
import com.dcag.s55.go.auftrag.types.TechNomKundeCdsFeld;

public class TechNomKundeCdsFeldTest extends com.dcag.s55.go.auftrag.types.TechNomKundeCdsFeld {

public static int ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS = 29;

/**
 * TechNomKundeCdsFeldTest - Konstruktorkommentar.
 */
public TechNomKundeCdsFeldTest() {
	super();
}
/**
 * TechNomKundeCdsFeldTest - Konstruktorkommentar.
 */
public TechNomKundeCdsFeldTest(TechNomKundeCdsFeld t) {
	super();
	set(t);
}
public Vector equals(TechNomKundeCdsFeld cds) {

	Vector vec = new Vector();
	
	this.sortiere();
	
	TechNomKundeCdsFeldTest t = new TechNomKundeCdsFeldTest(cds);
	t.sortiere();

    for (int i = 0; i < this.getSize(); i++) {

	    if  (!this.getKunde(i).getAddendum1().toString().equals(t.getKunde(i).getAddendum1().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getAddendum1(), t.getKunde(i).getAddendum1(), "Addendum1 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getAddendum2().toString().equals(t.getKunde(i).getAddendum2().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getAddendum2(), t.getKunde(i).getAddendum2(), "Addendum2 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getAddressRow1().toString().equals(t.getKunde(i).getAddressRow1().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getAddressRow1(), t.getKunde(i).getAddressRow1(), "AddressRow1 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getAddressRow2().toString().equals(t.getKunde(i).getAddressRow2().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getAddressRow2(), t.getKunde(i).getAddressRow2(), "AddressRow2 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getAddressRow3().toString().equals(t.getKunde(i).getAddressRow3().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getAddressRow3(), t.getKunde(i).getAddressRow3(), "AddressRow3 (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getCancellationMark().toString().equals(t.getKunde(i).getCancellationMark().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getCancellationMark(), t.getKunde(i).getCancellationMark(), "CancellationMark (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getChristianName().toString().equals(t.getKunde(i).getChristianName().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getChristianName(), t.getKunde(i).getChristianName(), "ChristianName (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getCity().toString().equals(t.getKunde(i).getCity().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getCity(), t.getKunde(i).getCity(), "City (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getCompanyName().toString().equals(t.getKunde(i).getCompanyName().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getCompanyName(), t.getKunde(i).getCompanyName(), "CompanyName (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getConsecutiveNr().toString().equals(t.getKunde(i).getConsecutiveNr().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getConsecutiveNr(), t.getKunde(i).getConsecutiveNr(), "ConsecutiveNr (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getCountry().toString().equals(t.getKunde(i).getCountry().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getCountry(), t.getKunde(i).getCountry(), "Country (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getCustTitle().toString().equals(t.getKunde(i).getCustTitle().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getCustTitle(), t.getKunde(i).getCustTitle(), "CustTitle (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getDisposition().toString().equals(t.getKunde(i).getDisposition().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getDisposition(), t.getKunde(i).getDisposition(), "Disposition (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getEmail().toString().equals(t.getKunde(i).getEmail().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getEmail(), t.getKunde(i).getEmail(), "Email (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getFamilyName().toString().equals(t.getKunde(i).getFamilyName().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getFamilyName(), t.getKunde(i).getFamilyName(), "FamilyName (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getKeyExt().toString().equals(t.getKunde(i).getKeyExt().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getKeyExt(), t.getKunde(i).getKeyExt(), "KeyExt (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getPostcode().toString().equals(t.getKunde(i).getPostcode().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getPostcode(), t.getKunde(i).getPostcode(), "Postcode (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getRole1().toString().equals(t.getKunde(i).getRole1().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole1(), t.getKunde(i).getRole1(), "Role1 (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getRole2().toString().equals(t.getKunde(i).getRole2().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole2(), t.getKunde(i).getRole2(), "Role2 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole3().toString().equals(t.getKunde(i).getRole3().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole3(), t.getKunde(i).getRole3(), "Role3 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole4().toString().equals(t.getKunde(i).getRole4().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole4(), t.getKunde(i).getRole4(), "Role4 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole5().toString().equals(t.getKunde(i).getRole5().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole5(), t.getKunde(i).getRole5(), "Role5 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole6().toString().equals(t.getKunde(i).getRole6().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole6(), t.getKunde(i).getRole6(), "Role6 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole7().toString().equals(t.getKunde(i).getRole7().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole7(), t.getKunde(i).getRole7(), "Role7 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole8().toString().equals(t.getKunde(i).getRole8().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole8(), t.getKunde(i).getRole8(), "Role8 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole9().toString().equals(t.getKunde(i).getRole9().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole9(), t.getKunde(i).getRole9(), "Role9 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole10().toString().equals(t.getKunde(i).getRole10().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole10(), t.getKunde(i).getRole10(), "Role10 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getRole10().toString().equals(t.getKunde(i).getRole10().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getRole10(), t.getKunde(i).getRole10(), "Role10 (Kunde " + i + ")");
		    vec.add(res);
	    }

	    if  (!this.getKunde(i).getSalutation().toString().equals(t.getKunde(i).getSalutation().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getSalutation(), t.getKunde(i).getSalutation(), "Salutation (Kunde " + i + ")");
		    vec.add(res);
	    }
	    
	    if  (!this.getKunde(i).getVersionNr().toString().equals(t.getKunde(i).getVersionNr().toString())) {
		    TestResult res = new TestResult(this.getKunde(i).getVersionNr(), t.getKunde(i).getVersionNr(), "VersionNr (Kunde " + i + ")");
		    vec.add(res);
	    }

    }
    
    return vec;
} 

public void fuelle(java.util.Vector vec, int pos, int anz) {

    String s;


    for (int i = 0; i < anz; i++) {

    
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 1))).length() > 0) 
			getKunde(i).getAddendum1().set(s);
		else
		    getKunde(i).getAddendum1().set(new String(" "));


		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 2))).length() > 0) 
			this.getKunde(i).getAddendum2().set(s);
		else
		    getKunde(i).getAddendum2().set(new String(" "));
			

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 3))).length() > 0) 
			this.getKunde(i).getAddressRow1().set(s);
		else
		    getKunde(i).getAddressRow1().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 4))).length() > 0) 
			this.getKunde(i).getAddressRow2().set(s);
		else
		    getKunde(i).getAddressRow2().set(new String(" "));
		    
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 5))).length() > 0) 
			this.getKunde(i).getAddressRow3().set(s);
		else
		    getKunde(i).getAddressRow3().set(new String(" "));
			
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 6))).length() > 0) 
			this.getKunde(i).getCancellationMark().set(s);
		else
		    getKunde(i).getCancellationMark().set(new String(" "));
			
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 7))).length() > 0) 
			this.getKunde(i).getChristianName().set(s);
		else
		    getKunde(i).getChristianName().set(new String(" "));
			
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 8))).length() > 0) 
			this.getKunde(i).getCity().set(s);
		else
		    getKunde(i).getCity().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 9))).length() > 0) 
			this.getKunde(i).getCompanyName().set(s);
		else
		    getKunde(i).getCompanyName().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 10))).length() > 0) 
			this.getKunde(i).getConsecutiveNr().set(new Integer(s).intValue());
		else
		    getKunde(i).getConsecutiveNr().set(0);

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 11))).length() > 0) 
			getKunde(i).getCountry().set(s);
		else
		    getKunde(i).getCountry().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 12))).length() > 0) 
			this.getKunde(i).getCustTitle().set(s);
		else
		    getKunde(i).getCustTitle().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 13))).length() > 0) 
			getKunde(i).getDisposition().set(s);
		else
		    getKunde(i).getDisposition().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 14))).length() > 0) 
			this.getKunde(i).getEmail().set(s);
		else
		    getKunde(i).getEmail().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 15))).length() > 0) 
			this.getKunde(i).getFamilyName().set(s);
		else
		    getKunde(i).getFamilyName().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 16))).length() > 0) 
			this.getKunde(i).getKeyExt().set(s);
		else
		    getKunde(i).getKeyExt().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 17))).length() > 0) 
			getKunde(i).getPostcode().set(s);
		else
		    getKunde(i).getPostcode().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 18))).length() > 0) 
			this.getKunde(i).getRole1().set(s);
		else
		    getKunde(i).getRole1().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 19))).length() > 0) 
			this.getKunde(i).getRole2().set(s);
		else
		    getKunde(i).getRole2().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 20))).length() > 0) 
			this.getKunde(i).getRole3().set(s);
		else
		    getKunde(i).getRole3().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 21))).length() > 0) 
			this.getKunde(i).getRole4().set(s);
		else
		    getKunde(i).getRole4().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 22))).length() > 0) 
			this.getKunde(i).getRole5().set(s);
		else
		    getKunde(i).getRole5().set(new String(" "));
		    
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 23))).length() > 0) 
			this.getKunde(i).getRole6().set(s);
		else
		    getKunde(i).getRole6().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 24))).length() > 0) 
			this.getKunde(i).getRole7().set(s);
		else
		    getKunde(i).getRole7().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 25))).length() > 0) 
			this.getKunde(i).getRole8().set(s);
		else
		    getKunde(i).getRole8().set(new String(" "));
		    
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 26))).length() > 0) 
			this.getKunde(i).getRole9().set(s);
		else
		    getKunde(i).getRole9().set(new String(" "));
		    
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 27))).length() > 0) 
			this.getKunde(i).getRole10().set(s);
		else
		    getKunde(i).getRole10().set(new String(" "));

		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 28))).length() > 0) 
			this.getKunde(i).getSalutation().set(s);
		else
		    getKunde(i).getSalutation().set(new String(" "));
		    
		if  ( (s = ((String) vec.get(pos + (i * ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 29))).length() > 0) 
			this.getKunde(i).getVersionNr().set(new Integer(s).intValue());
		else
		    getKunde(i).getVersionNr().set(0);

	}

}
private int getLength() {

	int i = 0;
	while (i < this.getSize() && this.getKunde(i) != null && !this.getKunde(i).getRole1().toString().equals(new String("    "))) {
		i++;
	}
	return i;
}
public void sortiere() {

	int anz = this.getLength();
	for (int i = 0; i < anz - 1; i++) {
		for (int j = i + 1; j < anz; j++) {
			if  (this.getKunde(i).getRole1().toString().compareTo(getKunde(j).getRole1().toString()) > 0) {
				TechNomKundeCds temp = getKunde(i);
				getKunde(i).set(getKunde(j));
				getKunde(j).set(temp);
			}
		}
	}		
	
}
}
