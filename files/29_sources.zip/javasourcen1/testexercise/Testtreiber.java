package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (06.02.2003 10:25:03)
 * @author: Wolfgang Weber
 */

import junit.framework.TestCase;
import junit.framework.Assert;
import junit.framework.TestSuite;
import junit.framework.Test;
import junit.textui.TestRunner;
import java.util.Vector;
import java.io.FileWriter;
import java.util.GregorianCalendar;
// import javax.swing.JFileChooser;
import java.awt.FileDialog;
// import javax.swing.filechooser.FileFilter;
import javax.swing.JFrame;


public class Testtreiber extends TestCase {

private static Vector inOut;
private static String SomObj = new String("som");
private static String SomAnlegen = new String("anlegen");
private static String SomAnnullieren = new String("annullieren");
private static String AuftragObj = new String("auftrag");
private static String AuftragAendern = new String("aendern");
private static String AuftragLesen = new String("lesen");
private static String AuftragExist = new String("exist");
private static String AuftragTappTausch = new String("tapptausch");
private static String AuftragFahrzeugTausch = new String("fahrzeugtausch");
private static String AuftragAuftraggeberAenderung = new String("auftraggeberaenderung");



private static int testZaehler = 0;
private static int anzErfolgreich = 0;
private static int anzNichtErfolgreich = 0;
private static FileWriter fw;

/**
 * CalculatorTest - Konstruktorkommentar.
 */
public Testtreiber(String name) {
	super(name);
}
private static void aktualisiereStatus(boolean res) {

	if (res)
		Testtreiber.anzErfolgreich++;
	else
		Testtreiber.anzNichtErfolgreich++;
}
	public void aufruf() {
		
        if  (Testtreiber.testZaehler < inOut.size()) {
	            
			TestObject testObject = (TestObject) Testtreiber.inOut.get(Testtreiber.testZaehler);
			Testtreiber.testZaehler++;			

			if (testObject.getObject().equals(Testtreiber.SomObj) ||
				testObject.getObject().equals(Testtreiber.AuftragObj) ) {

				
				NomTestRequest req = null;
				
			    if (testObject.getMethode().equals(Testtreiber.SomAnlegen)) {  
                    req = new SomAnlageTestRequest(testObject, fw);
                }       

				if (testObject.getMethode().equals(Testtreiber.SomAnnullieren)) { 
                    req = new SomAnnullierenTestRequest(testObject, fw);
				}

				if (testObject.getMethode().equals(Testtreiber.AuftragAendern)) { 
                    req = new AuftragAendernTestRequest(testObject, fw);
				}

				if (testObject.getMethode().equals(Testtreiber.AuftragLesen)) { 
                    req = new AuftragLesenTestRequest(testObject, fw);
				}

				if (testObject.getMethode().equals(Testtreiber.AuftragExist)) { 
                    req = new AuftragExistTestRequest(testObject, fw);
				}

				if (testObject.getMethode().equals(Testtreiber.AuftragTappTausch)) { 
                    req = new AuftragTappTauschTestRequest(testObject, fw);
				}
				

                req.lesenEingabe();
                req.lesenAusgabeSoll();

                req.ausf�hren();

                boolean res = req.vergleicheSollIst();
        			
        		Testtreiber.aktualisiereStatus(res);
					
    			Assert.assert(res);

			}
			
        }
	}
	public static void main(String[] arg) {

	InputHandler inputHandler = new InputHandler();
	org.xml.sax.XMLReader reader;
	reader = new org.apache.xerces.parsers.SAXParser();
	reader.setContentHandler(inputHandler);

    FileDialog chooser = new FileDialog(new java.awt.Frame(), "W�hlen Sie eine XML-Datei aus!");
//    chooser.setDirectory("H:/intern/NOMTeamlaufwerk/Subsystemtest/Suiten");
    chooser.setVisible(true);
    
/*    int returnVal = chooser.showOpenDialog(new JFrame());
    if (returnVal != JFileChooser.APPROVE_OPTION) {
	    System.out.println("Sie muessen eine XML-Datei auswaehlen, um den Testlauf zu starten!");
	    System.exit(0);
    }

    String path = chooser.getSelectedFile().getPath().replace('\\','/'); */
	try {
		reader.parse(new org.xml.sax.InputSource("file:///" +  chooser.getDirectory() + "/" + chooser.getFile()));
	}
	catch (org.xml.sax.SAXException e) {
		System.out.println("SAX-Exception " + e.getMessage() + " " + e.getLocalizedMessage() + e.getException() + chooser.getDirectory() + "/" + chooser.getFile());
		System.exit(0);
	}
	catch (java.io.IOException e) {
		System.out.println("IO-Exception " + e.getMessage() + " " + e.getLocalizedMessage());
		System.exit(0);
	}
	catch (Exception e) {
		System.out.println("Exception " + e.getMessage() + " " + e.getLocalizedMessage() );
		System.exit(0);
	}

	Testtreiber.inOut = inputHandler.getInOut();	

/*    chooser = new JFileChooser("H:/intern/NOMTeamlaufwerk/Subsystemtest/Protokolle");
    chooser.setDialogTitle("W�hlen Sie eine Protokoll-Datei aus!");
    returnVal = chooser.showOpenDialog(new JFrame());
    if (returnVal != JFileChooser.APPROVE_OPTION) {
	    System.out.println("Sie muessen eine Protokolldatei auswaehlen, um den Testlauf zu starten!");
	    System.exit(0);
    }

    String path1 = chooser.getSelectedFile().getPath().replace('\\','/'); */

    FileDialog chooser1 = new FileDialog(new java.awt.Frame(), "W�hlen Sie eine Protokoll-Datei aus!");
//    chooser.setDirectory("H:/intern/NOMTeamlaufwerk/Subsystemtest/Suiten");
    chooser1.setVisible(true);
    
	try {
		GregorianCalendar cal = new GregorianCalendar();
    	fw = new FileWriter(chooser1.getDirectory() + "/" + chooser1.getFile());
    	int monat = cal.get(GregorianCalendar.MONTH) + 1;
//    	fw.write("Testlauf am " + cal.get(GregorianCalendar.DAY_OF_MONTH) + "." +  monat + "." + cal.get(GregorianCalendar.YEAR) + " mit der Eingabedatei " + path + " und der Ausgabedatei " + path1 + "\n");
   	    fw.write("Es wurden " + Testtreiber.inOut.size() + " Testfaelle eingelesen!\n");
   	    fw.write("-----------------------------------------------------------------\n");
	}
	catch (Exception e) {
		System.out.println("Fehler bei Zugriff auf die Protokolldatei!" + e.getMessage());
		System.exit(0);
	}
	
	System.out.println("Es wurden " + Testtreiber.inOut.size() + " Testfaelle eingelesen!\n");

	TestRunner.run(Testtreiber.class); 

}
public static Test suite() {
	TestSuite suite = new TestSuite();
	for (int i = 0; i < Testtreiber.inOut.size();i++) {
		suite.addTest( 
			new Testtreiber("aufruf") 
			     { protected void runTest() { test(); }}
		);
	}
	return suite;

}
public void tearDown() {

	if  (Testtreiber.testZaehler == Testtreiber.inOut.size()) {
		try {
		    fw.write("Anzahl erfolgreicher Testfaelle:  " + Testtreiber.anzErfolgreich + "\n");
		    fw.write("Anzahl nicht erfolgreicher Testfaelle: " + Testtreiber.anzNichtErfolgreich + "\n");
		    int anzNichtBearbeitet = Testtreiber.testZaehler - Testtreiber.anzErfolgreich - Testtreiber.anzNichtErfolgreich;
		    fw.write("Anzahl nicht bearbeiteter Testfaelle: " + anzNichtBearbeitet + "\n");
		    fw.flush();
		    fw.close();
		}
		catch (Exception e) {
			System.out.println("Fehler beim Schreiben der Protokolldatei" + e.getMessage());
		}
		Testtreiber.testZaehler++;		
	}
}
	public void test() {
		aufruf();
	}
}
