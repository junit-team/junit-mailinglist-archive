package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (20.02.2003 08:58:35)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.gool.go.net.GoAPIServerRequest;
import com.dcag.s55.gool.go.net.MessageList;
import com.dcag.s55.gool.types.*;
import com.dcag.s55.go.auftrag.types.TechNomAuftragCds;
import com.dcag.s55.gool.go.types.fzg.codes.TechAregPkeyFeld;
import com.dcag.s55.gool.go.types.core.TechAnzahlDs;
import com.dcag.s55.go.auftrag.types.TechNomKundeCdsFeld;
import com.dcag.s55.gool.net.mcp.MCPHttpPostServer;
import com.dcag.s55.gool.go.net.GoBridgeServer;
import java.io.FileWriter;

 
public abstract class NomTestRequest extends TestRequest {

protected TechNomAuftragCdsTest techNomAuftragCdsIn;
protected TechAnzahlDs techAnzahlAregPkeyFeldDsIn;
protected TechAregPkeyFeldTest techAregPkeyFeldIn;
protected TechNomKundeCdsFeldTest techNomKundeCdsFeldIn;
protected TechAnzahlDs techAnzahlNomKundeCdsFeldDsIn;
protected TechNomAuftragCdsTest techNomAuftragCdsSoll;
protected TechAnzahlDs techAnzahlAregPkeyFeldDsSoll;
protected TechAregPkeyFeldTest techAregPkeyFeldSoll;
protected TechNomKundeCdsFeldTest techNomKundeCdsFeldSoll;
protected TechAnzahlDs techAnzahlNomKundeCdsFeldDsSoll;
protected TechNomAuftragCds techNomAuftragCdsIst;
protected TechAnzahlDs techAnzahlAregPkeyFeldDsIst;
protected TechAregPkeyFeld techAregPkeyFeldIst;
protected TechNomKundeCdsFeld techNomKundeCdsFeldIst;
protected TechAnzahlDs techAnzahlNomKundeCdsFeldDsIst;
protected int rcSoll;
protected int rcIst;
protected Meldungen meldungenIst;
protected Meldungen meldungenSoll;
protected GoAPIServerRequest request;


protected TechAdsAuftnrTest techAdsAuftnr1;
protected TechAdsAuftnrTest techAdsAuftnr2;
protected int version1;
protected int version2;
protected TechNomAuftragCds techNomAuftragCdsIst1;
protected TechAnzahlDs techAnzahlAregPkeyFeldDsIst1;
protected TechAregPkeyFeld techAregPkeyFeldIst1;
protected TechNomKundeCdsFeld techNomKundeCdsFeldIst1;
protected TechAnzahlDs techAnzahlNomKundeCdsFeldDsIst1;
protected TechNomAuftragCds techNomAuftragCdsIst2;
protected TechAnzahlDs techAnzahlAregPkeyFeldDsIst2;
protected TechAregPkeyFeld techAregPkeyFeldIst2;
protected TechNomKundeCdsFeld techNomKundeCdsFeldIst2;
protected TechAnzahlDs techAnzahlNomKundeCdsFeldDsIst2;
protected TechNomAuftragCdsTest techNomAuftragCdsSoll1;
protected TechAnzahlDs techAnzahlAregPkeyFeldDsSoll1;
protected TechAregPkeyFeldTest techAregPkeyFeldSoll1;
protected TechNomKundeCdsFeldTest techNomKundeCdsFeldSoll1;
protected TechAnzahlDs techAnzahlNomKundeCdsFeldDsSoll1;
protected TechNomAuftragCdsTest techNomAuftragCdsSoll2;
protected TechAnzahlDs techAnzahlAregPkeyFeldDsSoll2;
protected TechAregPkeyFeldTest techAregPkeyFeldSoll2;
protected TechNomKundeCdsFeldTest techNomKundeCdsFeldSoll2;
protected TechAnzahlDs techAnzahlNomKundeCdsFeldDsSoll2;

/**
 * NomRequest - Konstruktorkommentar.
 */
public NomTestRequest() {
	super();
}
/**
 * NomRequest - Konstruktorkommentar.
 */
public NomTestRequest(TestObject testObject, FileWriter fw) {
	super(testObject, fw);

}
public void ausf�hren() {

    MCPHttpPostServer http=new MCPHttpPostServer("http://53.113.100.2:9040/gtr/quer/bin/gool_bridge.dll","bsk67","bsk67002");
   	GoBridgeServer bridge=new GoBridgeServer(http,java.util.Locale.GERMAN,"bsk90");

    request = (GoAPIServerRequest) bridge.send(request);

    this.rcIst = request.getReturncode();
    meldungenIst = new Meldungen(request.getMessages());
	
}
public void lesenAusgabeSoll() {

	lesenAusgabeSollParameter();
	lesenAusgabeSollMeldungenRc();
	
}
public void lesenAusgabeSollMeldungenRc() {

	lesenAusgabeSollMeldungenRc(TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM + 1 + (int) techAnzahlAregPkeyFeldDsSoll.get() + 1 + ((int) techAnzahlNomKundeCdsFeldDsSoll.get() * TechNomKundeCdsFeldTest.ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS));

	
}
public void lesenAusgabeSollMeldungenRc(int pos) {

//    meldungenSoll.fuelle(testObject.getOutPara(), pos + POS_ANZ_AREG_CODE + (int) techAnzahlAregPkeyFeldDsSoll.get() + ((int) techAnzahlNomKundeCdsFeldDsSoll.get() * TechNomKundeCdsFeldTest.ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 2);
    meldungenSoll.fuelle(testObject.getOutPara(), pos);
//    rcSoll = new Integer((String) testObject.getOutPara(pos + POS_ANZ_AREG_CODE + (int) techAnzahlAregPkeyFeldDsSoll.get() + ((int) techAnzahlNomKundeCdsFeldDsSoll.get() * TechNomKundeCdsFeldTest.ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS) + 2 + (2 * meldungenSoll.size()) + 1)).intValue();
    rcSoll = new Integer((String) testObject.getOutPara(pos + (2 * meldungenSoll.size()) + 1)).intValue();
	
}
public void lesenAusgabeSollParameter() {

	lesenAusgabeSollParameter(0);
	
}
public void lesenAusgabeSollParameter(int pos) {
                    
    techNomAuftragCdsSoll = new TechNomAuftragCdsTest();
                    
    techAnzahlAregPkeyFeldDsSoll = new TechAnzahlDs();
    techAregPkeyFeldSoll = new TechAregPkeyFeldTest();

    techNomKundeCdsFeldSoll = new TechNomKundeCdsFeldTest();
    techAnzahlNomKundeCdsFeldDsSoll = new TechAnzahlDs();

    meldungenSoll = new Meldungen();
                    	
    techNomAuftragCdsSoll.fuelle(testObject.getOutPara(), pos);
    if  (((String) testObject.getOutPara(pos + TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM)).length() > 0) {
        techAnzahlAregPkeyFeldDsSoll.set(new Integer((String) testObject.getOutPara(pos + TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM)).intValue());					    
        techAregPkeyFeldSoll.fuelle(testObject.getOutPara(),pos + TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM, (int) techAnzahlAregPkeyFeldDsSoll.get());
    }

    if  (((String) testObject.getOutPara( pos + TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM + (int) techAnzahlAregPkeyFeldDsSoll.get() + 1)).length() > 0) {
    	techAnzahlNomKundeCdsFeldDsSoll.set(new Integer((String) testObject.getOutPara(pos + TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM + (int) techAnzahlAregPkeyFeldDsSoll.get() + 1)).intValue());
    	techNomKundeCdsFeldSoll.fuelle(testObject.getOutPara(), pos + TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM + 1 + (int) techAnzahlAregPkeyFeldDsSoll.get(), (int) techAnzahlNomKundeCdsFeldDsSoll.get());
	}
    
}
    

public void lesenAusgabeSollParameter2Auft() {

	lesenAusgabeSollParameter(0);
	lesenAusgabeSollParameter(TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM + 1 + (int) techAnzahlAregPkeyFeldDsSoll.get() + 1 + ((int) techAnzahlNomKundeCdsFeldDsSoll.get() * TechNomKundeCdsFeldTest.ANZ_STRUKTUR_ELEM_NOM_KUNDE_CDS));
	
}
public void lesenEingabe() {


    techNomAuftragCdsIn = new TechNomAuftragCdsTest();
                    
    techAnzahlAregPkeyFeldDsIn = new TechAnzahlDs();
    techAregPkeyFeldIn = new TechAregPkeyFeldTest();
                    
    techNomKundeCdsFeldIn = new TechNomKundeCdsFeldTest();
    techAnzahlNomKundeCdsFeldDsIn = new TechAnzahlDs();

	techNomAuftragCdsIn.fuelle(testObject.getInPara(),0);
	if  (((String) testObject.getInPara(TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM)).length() > 0) {
	    techAnzahlAregPkeyFeldDsIn.set(new Integer((String) testObject.getInPara(TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM)).intValue());					    
	    techAregPkeyFeldIn.fuelle(testObject.getInPara(),TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM, (int) techAnzahlAregPkeyFeldDsIn.get());
    }

    if  (((String) testObject.getInPara(TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM + (int) techAnzahlAregPkeyFeldDsIn.get() + 1)).length() > 0) {
    	techAnzahlNomKundeCdsFeldDsIn.set(new Integer((String) testObject.getInPara(TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM + (int) techAnzahlAregPkeyFeldDsIn.get() + 1)).intValue());
    	techNomKundeCdsFeldIn.fuelle(testObject.getInPara(), TechNomAuftragCdsTest.ANZ_STRUKTUR_ELEM + 1 + (int) techAnzahlAregPkeyFeldDsIn.get(), (int) techAnzahlNomKundeCdsFeldDsIn.get());
	}
	
}
public void lesenEingabe2Auft() {

    techAdsAuftnr1 = new TechAdsAuftnrTest();
    techAdsAuftnr1.fuelle(testObject.getInPara(), 0);
    version1 = new Integer(testObject.getInPara(TechAdsAuftnrTest.ANZ_STRUKTUR_ELEM)).intValue();
    techAdsAuftnr2 = new TechAdsAuftnrTest();
    techAdsAuftnr2.fuelle(testObject.getInPara(), TechAdsAuftnrTest.ANZ_STRUKTUR_ELEM + 1);
    version2 = new Integer(testObject.getInPara(2 * TechAdsAuftnrTest.ANZ_STRUKTUR_ELEM + 1)).intValue();
    

}
public boolean vergleicheSollIst() {

	boolean res1 = false;
	boolean res2 = false;
	
	if  (rcIst != rcSoll) {
		fehlerausgabe(new Long(rcSoll).toString(), new Long(rcIst).toString(), new String("Returncode"));
	}
	else {
		res1 = vergleicheSollIstParameter();
		res2 = vergleicheSollIstMessages();
	}
	
    return ( (this.rcIst == this.rcSoll) && res1 && res2 );

}
public boolean vergleicheSollIstMessages() {

	boolean meldungenEqual = true;
	
	if  (rcIst == rcSoll) {
		if  (meldungenSoll.size() == meldungenIst.size()) {
			if  (meldungenSoll.size() > 0) {
				java.util.Vector vec = meldungenSoll.equals(meldungenIst);
				fehlerausgabe(vec);
				if  (vec.size() > 0) {
					meldungenEqual = false;
				}
			}
		}
		else {
			fehlerausgabe(new Integer(meldungenSoll.size()).toString(), new Integer(meldungenIst.size()).toString(), new String("Anzahl Meldungen"));		
		}
    }

	return ( (meldungenSoll.size() == meldungenIst.size()) && meldungenEqual);

}
	
public boolean vergleicheSollIstParameter() {

	return vergleicheSollIstParameter(techNomAuftragCdsSoll,
									  techNomAuftragCdsIst,
									  techAnzahlAregPkeyFeldDsSoll,
									  techAnzahlAregPkeyFeldDsIst,
									  techAregPkeyFeldSoll,
									  techAregPkeyFeldIst,
									  techAnzahlNomKundeCdsFeldDsSoll,
									  techAnzahlNomKundeCdsFeldDsIst,
									  techNomKundeCdsFeldSoll,
									  techNomKundeCdsFeldIst);
}	
	
public boolean vergleicheSollIstParameter(TechNomAuftragCdsTest techNomAuftragCdsSoll,
										  TechNomAuftragCds techNomAuftragCdsIst,
										  TechAnzahlDs techAnzahlAregPkeyFeldDsIst, 
										  TechAnzahlDs techAnzahlAregPkeyFeldDsSoll, 
										  TechAregPkeyFeldTest techAregPkeyFeldDsSoll,
										  TechAregPkeyFeld techAregPkeyFeldDs, 
										  TechAnzahlDs techAnzahlNomKundeCdsFeldDsIst, 
										  TechAnzahlDs techAnzahlNomKundeCdsFeldDsSoll, 
										  TechNomKundeCdsFeldTest techNomKundeCdsFeldDsSoll,
										  TechNomKundeCdsFeld techNomKundeCdsFeldDsIst) {
	
    boolean techNomAuftragCdsEqual = true;
    boolean techAregPkeyFeldEqual = true;
    boolean techNomKundeCdsFeldEqual = true;
		                         
	if  (rcIst == rcSoll) {
		java.util.Vector vec = techNomAuftragCdsSoll.equals(techNomAuftragCdsIst);
		fehlerausgabe(vec);
		if  (vec.size() > 0) {
		    techNomAuftragCdsEqual = false;
		}
		if  (techAnzahlAregPkeyFeldDsIst.longValue() == techAnzahlAregPkeyFeldDsSoll.longValue()) {
			if  (techAnzahlAregPkeyFeldDsIst.longValue() > 0) {
    			vec = techAregPkeyFeldSoll.equals(techAregPkeyFeldIst);
	    		if  (vec.size() > 0) {
			        fehlerausgabe(vec);
    			    techAregPkeyFeldEqual = false;
			    }
			}
		}
		else {
			fehlerausgabe(new Long(techAnzahlAregPkeyFeldDsSoll.longValue()).toString(), new Long(techAnzahlAregPkeyFeldDsIst.longValue()).toString(), new String("Anzahl Areg"));
		}
			
		if  (techAnzahlNomKundeCdsFeldDsIst.get() == techAnzahlNomKundeCdsFeldDsSoll.get()) {
			if  (techAnzahlNomKundeCdsFeldDsSoll.longValue() > 0) {
    			vec = techNomKundeCdsFeldSoll.equals(techNomKundeCdsFeldIst);
    			if  (vec.size() > 0) {
    			    fehlerausgabe(vec);
			        techNomKundeCdsFeldEqual = false;			    
    			}
			}	
		}
		else {
			fehlerausgabe(new Long(techAnzahlNomKundeCdsFeldDsSoll.longValue()).toString(), new Long(techAnzahlNomKundeCdsFeldDsIst.longValue()).toString(), new String("Anzahl Kunde"));
		}	
			 
	}

	return ( techNomAuftragCdsEqual && techAregPkeyFeldEqual && (techAnzahlAregPkeyFeldDsIst == techAnzahlAregPkeyFeldDsSoll) &&
		     (techAnzahlNomKundeCdsFeldDsIst == techAnzahlNomKundeCdsFeldDsSoll));

}
public boolean vergleicheSollIstParameter2Auft() {

	boolean res1 = vergleicheSollIstParameter(techNomAuftragCdsSoll1,
									  techNomAuftragCdsIst1,
									  techAnzahlAregPkeyFeldDsSoll1,
									  techAnzahlAregPkeyFeldDsIst1,
									  techAregPkeyFeldSoll1,
									  techAregPkeyFeldIst1,
									  techAnzahlNomKundeCdsFeldDsSoll1,
									  techAnzahlNomKundeCdsFeldDsIst1,
									  techNomKundeCdsFeldSoll1,
									  techNomKundeCdsFeldIst1);

	boolean res2 = vergleicheSollIstParameter(techNomAuftragCdsSoll2,
									  techNomAuftragCdsIst2,
									  techAnzahlAregPkeyFeldDsSoll2,
									  techAnzahlAregPkeyFeldDsIst2,
									  techAregPkeyFeldSoll2,
									  techAregPkeyFeldIst2,
									  techAnzahlNomKundeCdsFeldDsSoll2,
									  techAnzahlNomKundeCdsFeldDsIst2,
									  techNomKundeCdsFeldSoll2,
									  techNomKundeCdsFeldIst2);

	return (res1 && res2);
	
}	
	
}
