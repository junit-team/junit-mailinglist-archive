package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (25.02.2003 17:21:52)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.nom.tapptausch.net.TappTauschServerRequest;

public class AuftragTappTauschTestRequest extends NomTestRequest {

/**
 * AuftragTappTauschTestRequest - Konstruktorkommentar.
 */
public AuftragTappTauschTestRequest() {
	super();
}
/**
 * AuftragTappTauschTestRequest - Konstruktorkommentar.
 * @param testObject testexercise.TestObject
 * @param fw java.io.FileWriter
 */
public AuftragTappTauschTestRequest(TestObject testObject, java.io.FileWriter fw) {
	super(testObject, fw);
}
public void ausf�hren() {

     request = new TappTauschServerRequest();
	
    ((TappTauschServerRequest) request).createAuftNr1().set(techAdsAuftnr1);
    ((TappTauschServerRequest) request).createAuftVersion1().set(version1);
    ((TappTauschServerRequest) request).createAuftNr2().set(techAdsAuftnr2);
    ((TappTauschServerRequest) request).createAuftVersion2().set(version2);    

    super.ausf�hren();
    
    this.techNomAuftragCdsIst1 = ((TappTauschServerRequest) request).getAuftDaten1();
    this.techAnzahlAregPkeyFeldDsIst1 = ((TappTauschServerRequest) request).getAnzAuftCodes1();
    this.techAregPkeyFeldIst1 = ((TappTauschServerRequest) request).getAuftCodes1();
    this.techAnzahlNomKundeCdsFeldDsIst1 = ((TappTauschServerRequest) request).getAnzKunden1();
    this.techNomKundeCdsFeldIst1 = ((TappTauschServerRequest) request).getKunden1();

    this.techNomAuftragCdsIst2 = ((TappTauschServerRequest) request).getAuftDaten2();
    this.techAnzahlAregPkeyFeldDsIst2 = ((TappTauschServerRequest) request).getAnzAuftCodes2();
    this.techAregPkeyFeldIst2 = ((TappTauschServerRequest) request).getAuftCodes2();
    this.techAnzahlNomKundeCdsFeldDsIst2 = ((TappTauschServerRequest) request).getAnzKunden2();
    this.techNomKundeCdsFeldIst2 = ((TappTauschServerRequest) request).getKunden2();
    
		



	
}
public void lesenAusgabeSollMeldungenRc() {

	super.lesenAusgabeSollMeldungenRc( 2 * (techNomAuftragCdsSoll1.getMetaType().getLength() + 1 + techAregPkeyFeldSoll1.getMetaType().getLength() + 1 + techNomKundeCdsFeldSoll1.getMetaType().getLength()) );
}
public void lesenAusgabeSollParameter() {

	super.lesenAusgabeSollParameter2Auft();
}
public void lesenEingabe() {

	super.lesenEingabe2Auft();

}
public boolean vergleicheSollIstParameter() {
	
	return super.vergleicheSollIstParameter2Auft();

}
}
