package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (20.02.2003 10:09:28)
 * @author: Wolfgang Weber
 */

import java.io.FileWriter;
 
public abstract class TestRequest {

protected TestObject testObject;
private FileWriter fw;

/**
 * TestRequest - Konstruktorkommentar.
 */
public TestRequest() {
	super();
}
/**
 * TestRequest - Konstruktorkommentar.
 */
public TestRequest(TestObject testObject, FileWriter fw) {
	super();
	this.testObject = testObject;
	this.fw = fw;
}
public void fehlerausgabe(String soll, String ist, String para) {

	try {   	
		fw.write("Aufruf von "  + testObject.getObject() + "." + testObject.getMethode() + "(" + testObject.getNummer() + ") ergibt Out-Parameter " + para + " : " + ist + " statt " + soll + "!\n");
	}
	catch (Exception e) {
		System.out.println("Fehler beim Schreiben der Protokolldatei " + e.getMessage());
	}

}
public void fehlerausgabe(java.util.Vector vec) {

	for (int i = 0; i < vec.size(); i++) {
	    TestResult res = (TestResult) vec.get(i);
	    fehlerausgabe(res.getIst(), res.getSoll(), res.getParameter());
	}    
	
}
}
