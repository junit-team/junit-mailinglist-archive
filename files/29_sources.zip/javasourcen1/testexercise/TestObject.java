package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (10.02.2003 12:37:22)
 * @author: Wolfgang Weber
 */

import java.util.Vector;

public class TestObject {

private String testObject;
private String methode;
private Vector inPara;
private Vector outPara;
private String nummer;

/**
 * TestObject - Konstruktorkommentar.
 */
public TestObject(String testObject) {
	this.testObject = testObject;
	inPara = new Vector();
	outPara = new Vector();
	this.methode = new String("");
}
public void addInPara(String in) {
	this.inPara.add(in);
}
public void addOutPara(String in) {
	this.outPara.add(in);
}
public Vector getInPara() {
	return inPara;
}
public String getInPara(int index) {
	return (String) inPara.get(index); 
}
public String getMethode() {
	return methode;
}
public String getNummer() {
	return nummer;
}
public String getObject() {
	return testObject;
}
public Vector getOutPara() {
	return outPara;
}
public String getOutPara(int index) {
	return (String) outPara.get(index); 
}
public void setMethode(String methode) {
	this.methode = methode;
}
public void setNummer(String nummer) {
	this.nummer = nummer;
}
}
