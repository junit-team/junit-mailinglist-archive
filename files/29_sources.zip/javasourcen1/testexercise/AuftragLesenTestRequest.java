package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (20.02.2003 12:13:26)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.go.auftrag.net.AuftLesenServerRequest;

public class AuftragLesenTestRequest extends NomTestRequest {

TechAdsAuftnrTest techAdsAuftnr;

/**
 * AuftragLesenTestRequest - Konstruktorkommentar.
 */
public AuftragLesenTestRequest() {
	super();
}
/**
 * AuftragLesenTestRequest - Konstruktorkommentar.
 * @param testObject testexercise.TestObject
 */
public AuftragLesenTestRequest(TestObject testObject, java.io.FileWriter fw) {
	super(testObject, fw);
}
public void ausf�hren() {
		
	request = new AuftLesenServerRequest();
	
    ((AuftLesenServerRequest) request).createAuftNummer().set(techAdsAuftnr);
    super.ausf�hren();
    this.techNomAuftragCdsIst = ((AuftLesenServerRequest) request).getAuftDaten();
    this.techAnzahlAregPkeyFeldDsIst = ((AuftLesenServerRequest) request).getAnzAuftCodes();
    this.techAregPkeyFeldIst = ((AuftLesenServerRequest) request).getAuftCodes();
    this.techAnzahlNomKundeCdsFeldDsIst = ((AuftLesenServerRequest) request).getAnzKunden();
    this.techNomKundeCdsFeldIst = ((AuftLesenServerRequest) request).getKunden();
	
}
public void lesenEingabe() {


    techAdsAuftnr = new TechAdsAuftnrTest();
    techAdsAuftnr.fuelle(testObject.getInPara(), 0);
	
}
}
