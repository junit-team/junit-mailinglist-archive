package testexercise;

/**
 * Die Beschreibung des Typs hier eingeben.
 * Erstellungsdatum: (20.02.2003 09:42:24)
 * @author: Wolfgang Weber
 */

import com.dcag.s55.nom.som.net.AnlEinzelServerRequest;
 
public class SomAnlageTestRequest extends NomTestRequest {

/**
 * SomAnlageTestRequest - Konstruktorkommentar.
 */
public SomAnlageTestRequest() {
	super();
}
/**
 * SomAnlageTestRequest - Konstruktorkommentar.
 * @param testObject testexercise.TestObject
 */
public SomAnlageTestRequest(TestObject testObject, java.io.FileWriter fw) {
	super(testObject, fw);
}
public void ausf�hren() {
		
	request = new AnlEinzelServerRequest();
    ((AnlEinzelServerRequest) request).createAuftDaten().set(techNomAuftragCdsIn);
    ((AnlEinzelServerRequest) request).createAuftCodes().set(techAregPkeyFeldIn);
    ((AnlEinzelServerRequest) request).createAnzAuftCodes().set(techAnzahlAregPkeyFeldDsIn);
    ((AnlEinzelServerRequest) request).createAnzKunden().set(techAnzahlNomKundeCdsFeldDsIn);
    ((AnlEinzelServerRequest) request).createKunden().set(techNomKundeCdsFeldIn);
    super.ausf�hren();
    this.techNomAuftragCdsIst = ((AnlEinzelServerRequest) request).getAuftDaten();
    this.techAnzahlAregPkeyFeldDsIst = ((AnlEinzelServerRequest) request).getAnzAuftCodes();
    this.techAregPkeyFeldIst = ((AnlEinzelServerRequest) request).getAuftCodes();
    this.techAnzahlNomKundeCdsFeldDsIst = ((AnlEinzelServerRequest) request).getAnzKunden();
    this.techNomKundeCdsFeldIst = ((AnlEinzelServerRequest) request).getKunden();
	
}
}
