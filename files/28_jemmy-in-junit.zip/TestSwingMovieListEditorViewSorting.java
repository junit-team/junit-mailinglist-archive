/**
 * Copyright (c) 2002 Saorsa Development, Inc.
 */
package com.saorsa.nowplaying.tests;

import java.util.Vector;

import javax.swing.ListModel;

import com.saorsa.nowplaying.*;
import com.saorsa.nowplaying.MovieList;
import com.saorsa.nowplaying.SwingMovieListEditorView;

import org.netbeans.jemmy.operators.*;
import org.netbeans.jemmy.operators.JFrameOperator;
import org.netbeans.jemmy.operators.JMenuBarOperator;

import junit.framework.TestCase;

public class TestSwingMovieListEditorViewSorting extends TestCase {
  private MovieList movieList;
  private Movie starWars;
  private Movie starTrek;
  private Movie stargate;
  private Movie theShining;

  /**
   * @associates Movie 
   */
  private Vector movies;

  /**
   * @associates Movie 
   */
  private Vector sortedMovies;

  /**
   * @associates Movie 
   */
  private Vector ratingSortedMovies;
  private JFrameOperator mainWindow;
  private MovieListEditor editor;
  private JMenuBarOperator menubar;
  private JMenuOperator viewMenu;

  protected void setUp() throws Exception {
    super.setUp();
    SwingMovieListEditorView.start();
    stargate = new Movie("Stargate", Category.SCIFI, -1);
    theShining = new Movie("The Shining", Category.HORROR, 2);
    starWars = new Movie("Star Wars", Category.SCIFI, 5);
    starTrek = new Movie("Star Trek", Category.SCIFI, 3);

    movies = new Vector();
    movies.add(stargate);
    movies.add(theShining);
    movies.add(starWars);
    movies.add(starTrek);
    
    sortedMovies = new Vector();
    sortedMovies.add(starTrek);
    sortedMovies.add(starWars);
    sortedMovies.add(stargate);
    sortedMovies.add(theShining);

    ratingSortedMovies = new Vector();
    ratingSortedMovies.add(starWars);
    ratingSortedMovies.add(starTrek);
    ratingSortedMovies.add(theShining);
    ratingSortedMovies.add(stargate);
    
    movieList = new MovieList();
    movieList.add(stargate);
    movieList.add(theShining);
    movieList.add(starWars);
    movieList.add(starTrek);

    mainWindow = new JFrameOperator("Movie List");
    editor = new MovieListEditor(movieList, 
                                 (SwingMovieListEditorView)mainWindow.getWindow());
                                 
    menubar = new JMenuBarOperator(mainWindow);
    viewMenu = new JMenuOperator(menubar, "View");
    viewMenu.push();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    mainWindow.dispose();
  }

  public void testSortingByName() {
    JMenuItemOperator sortByNameItem = new JMenuItemOperator(mainWindow, new NameBasedChooser("sortByName"));
    sortByNameItem.push();
 
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    ListModel listModel = movieList.getModel();
    assertEquals("Movie list is the wrong size", sortedMovies.size(), 
                 listModel.getSize());

    for (int i = 0; i < sortedMovies.size(); i++) {
      assertEquals("Movie list contains bad movie at index " + i, sortedMovies.get(i), 
                   listModel.getElementAt(i));
    }
  }
  
 
  public void testSortingByRating() {
    JMenuItemOperator sortByRatingItem = new JMenuItemOperator(mainWindow, new NameBasedChooser("sortByRating"));
    sortByRatingItem.push();
 
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    ListModel listModel = movieList.getModel();
    assertEquals("Movie list is the wrong size", ratingSortedMovies.size(), 
                 listModel.getSize());

    for (int i = 0; i < ratingSortedMovies.size(); i++) {
      assertEquals("Movie list contains bad movie at index " + i, ratingSortedMovies.get(i), 
                   listModel.getElementAt(i));
    }
  }
  
  
  public static void main(String[] args) {
    junit.textui.TestRunner.run(TestSwingMovieListEditorViewSorting.class);
  }

}
