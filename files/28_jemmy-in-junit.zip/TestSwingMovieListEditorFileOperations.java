/**
 * Copyright (c) 2002 Saorsa Development, Inc.
 */
package com.saorsa.nowplaying.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ListModel;

import org.custommonkey.xmlunit.XMLTestCase;
import org.netbeans.jemmy.operators.JButtonOperator;
import org.netbeans.jemmy.operators.JComboBoxOperator;
import org.netbeans.jemmy.operators.JFileChooserOperator;
import org.netbeans.jemmy.operators.JFrameOperator;
import org.netbeans.jemmy.operators.JListOperator;
import org.netbeans.jemmy.operators.JMenuBarOperator;
import org.netbeans.jemmy.operators.JMenuItemOperator;
import org.netbeans.jemmy.operators.JMenuOperator;
import org.netbeans.jemmy.operators.JTextFieldOperator;

import com.saorsa.nowplaying.Category;
import com.saorsa.nowplaying.Movie;
import com.saorsa.nowplaying.MovieList;
import com.saorsa.nowplaying.MovieListEditor;
import com.saorsa.nowplaying.SwingMovieListEditorView;

public class TestSwingMovieListEditorFileOperations extends XMLTestCase {
  private MovieList movieList;
  private Movie theShining;
  private String savedText;
  private String extendedSavedText;
  private JFrameOperator mainWindow;
  private MovieListEditor editor;
  private File outputFile;
  private String outputPathName;
  private File inputFile;
  private JMenuBarOperator menubar;
  private JMenuOperator fileMenu;

  public TestSwingMovieListEditorFileOperations(String arg0) {
    super(arg0);
  }

  protected void setUp() throws Exception {
    SwingMovieListEditorView.start();
    movieList = new MovieList();
    movieList.add(new Movie("Star Wars", Category.SCIFI, 5));
    movieList.add(new Movie("Star Trek", Category.SCIFI, 3));
    movieList.add(new Movie("Stargate", Category.SCIFI, -1));
    theShining = new Movie("The Shining", Category.HORROR, -1);
    
    String textPrefix = "<movielist>" +
                           "<movie name=\"Star Wars\" category=\"Science Fiction\">" +
                               "<ratings><rating value=\"5\" source=\"Anonymous\" /></ratings>" +
                           "</movie>" +
                           "<movie name=\"Star Trek\" category=\"Science Fiction\">" +
                               "<ratings><rating value=\"3\" source=\"Anonymous\" /></ratings>" +
                           "</movie>" +
                           "<movie name=\"Stargate\" category=\"Science Fiction\"><ratings></ratings></movie>";
    savedText = textPrefix + "</movielist>";
    extendedSavedText = textPrefix + "<movie name=\"The Shining\" category=\"Horror\">" +
                               "<ratings></ratings>" +
                           "</movie>" +
                           "</movielist>";

    outputFile = File.createTempFile("testSaving", ".dat"); 

    inputFile = File.createTempFile("testLoading", ".dat"); 
    FileWriter writer = new FileWriter(inputFile);
    writer.write(extendedSavedText);
    writer.flush();
    writer.close();

    mainWindow = new JFrameOperator("Movie List");
    editor = new MovieListEditor(movieList, 
                                 (SwingMovieListEditorView)mainWindow.getWindow());
                                 
    menubar = new JMenuBarOperator(mainWindow);
    fileMenu = new JMenuOperator(menubar, "File");
    fileMenu.push();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    mainWindow.dispose();
    inputFile.delete();
    outputFile.delete();
  }
  
  public void testSaving() throws Exception {
    JMenuItemOperator saveAsItem = new JMenuItemOperator(mainWindow, new NameBasedChooser("saveas"));
    saveAsItem.pushNoBlock();
    JFileChooserOperator fileChooser = new JFileChooserOperator();
    fileChooser.setSelectedFile(outputFile);
    JButtonOperator saveButton = new JButtonOperator(fileChooser, "Save");
    saveButton.push();
    assertXMLEqual("Save-Ased file has wrong contents.", savedText, contentsOf(outputFile));
    
    JTextFieldOperator newMovieField = new JTextFieldOperator(mainWindow, new NameBasedChooser("name"));
    newMovieField.enterText(theShining.getName());
    JComboBoxOperator categoryCombo = new JComboBoxOperator(mainWindow, new NameBasedChooser("category"));
    categoryCombo.setSelectedIndex(2);
    JButtonOperator addButton = new JButtonOperator(mainWindow, new NameBasedChooser("add"));
    addButton.push();
    
    fileMenu.push();
    JMenuItemOperator saveItem = new JMenuItemOperator(mainWindow, new NameBasedChooser("save"));
    saveItem.push();
    assertXMLEqual("Resaved file has wrong contents.", extendedSavedText, contentsOf(outputFile));
  }

  private String contentsOf(File aFile) throws IOException {
    FileInputStream fstream = new FileInputStream(aFile);
    int size = fstream.available();
    byte[] buffer = new byte[size];
    fstream.read(buffer);
   return new String(buffer);
  }
  
  public void testCancelledSaving() throws Exception {
    JMenuItemOperator saveAsItem = new JMenuItemOperator(mainWindow, new NameBasedChooser("saveas"));
    saveAsItem.pushNoBlock();
    JFileChooserOperator fileChooser = new JFileChooserOperator();
    fileChooser.setSelectedFile(outputFile);
    JButtonOperator cancelButton = new JButtonOperator(fileChooser, "Cancel");
    cancelButton.push();
    FileAssert.assertSize("Saved list has wrong size.", 0, outputFile);
  }
  
  public void testLoading() {
    JMenuItemOperator openItem = new JMenuItemOperator(mainWindow, new NameBasedChooser("open"));
    openItem.pushNoBlock();

    JFileChooserOperator fileChooser = new JFileChooserOperator();
    fileChooser.setSelectedFile(inputFile);
    JButtonOperator loadButton = new JButtonOperator(fileChooser, "Open");
    loadButton.push();
    
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    ListModel listModel = movieList.getModel();
    assertEquals("Movie list is the wrong size", 4,  listModel.getSize());
  }
  
  public void testCancelledLoading() {
    JMenuItemOperator openItem = new JMenuItemOperator(mainWindow, new NameBasedChooser("open"));
    openItem.pushNoBlock();

    JFileChooserOperator fileChooser = new JFileChooserOperator();
    fileChooser.setSelectedFile(inputFile);
    JButtonOperator loadButton = new JButtonOperator(fileChooser, "Cancel");
    loadButton.push();
    
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    ListModel listModel = movieList.getModel();
    assertEquals("Movie list is the wrong size", 3,  listModel.getSize());
  }
  
  
  public static void main(String[] args) {
    junit.textui.TestRunner.run(TestSwingMovieListEditorFileOperations.class);
  }
}
