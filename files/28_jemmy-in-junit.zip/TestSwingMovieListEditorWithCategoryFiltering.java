// %1031590972114:com.saorsa.nowplaying.tests%

/**
 * Copyright (c) 2002 Saorsa Development, Inc.
 */
package com.saorsa.nowplaying.tests;

import com.saorsa.nowplaying.*;

import java.util.Vector;

import javax.swing.ListModel;

import junit.framework.TestCase;

import org.netbeans.jemmy.operators.*;


/**
 * DOCUMENT ME!
 */
public class TestSwingMovieListEditorWithCategoryFiltering
  extends TestCase {
  //~ Instance variables -------------------------------------------------------

  private Movie starWars = null;
  private Movie starTrek = null;
  private Movie stargate = null;
  private Movie theShining = null;
  private Movie carrie = null;
  private Movie fotr = null;
  private Movie redOctober = null;
  private Movie congo = null;
  private Movie princessBride = null;
  private MovieList movieList = null;
  private MovieList fantasyList = null;
  private MovieList scifiList = null;
  private MovieList thrillerList = null;
  private MovieList horrorList = null;
  private Vector movies = null;
  private Vector fantasyMovies = null;
  private Vector horrorMovies = null;
  private Vector thrillerMovies = null;
  private Vector scifiMovies = null;
  private JFrameOperator mainWindow = null;
  private MovieListEditor editor = null;

  //~ Methods ------------------------------------------------------------------

  protected void setUp() throws Exception {
    super.setUp();
    SwingMovieListEditorView.start();
    
    starWars = new Movie("Star Wars", Category.SCIFI, 5);
    starTrek = new Movie("Star Trek", Category.SCIFI, 3);
    stargate = new Movie("Stargate", Category.SCIFI, -1);
    theShining = new Movie("The Shining", Category.HORROR, 2);
    carrie = new Movie("Carrie", Category.HORROR, 3);
    fotr = new Movie("The Fellowship of The Ring", Category.FANTASY, 5);
    redOctober = new Movie("The Hunt For Red October", Category.THRILLER, 3);
    congo = new Movie("Congo", Category.THRILLER, 3);
    princessBride = new Movie("The Princess Bride", Category.FANTASY, 5);

    movieList = new MovieList();
    movieList.add(starWars);
    movieList.add(starTrek);
    movieList.add(stargate);
    movieList.add(theShining);
    movieList.add(carrie);
    movieList.add(fotr);
    movieList.add(redOctober);
    movieList.add(congo);
    movieList.add(princessBride);
    movies = new Vector(movieList.getMovies());

    scifiList = new MovieList();
    scifiList.add(starWars);
    scifiList.add(starTrek);
    scifiList.add(stargate);
    scifiMovies = new Vector(scifiList.getMovies());

    thrillerList = new MovieList();
    thrillerList.add(redOctober);
    thrillerList.add(congo);
    thrillerMovies = new Vector(thrillerList.getMovies());

    horrorList = new MovieList();
    horrorList.add(theShining);
    horrorList.add(carrie);
    horrorMovies = new Vector(horrorList.getMovies());

    fantasyList = new MovieList();
    fantasyList.add(fotr);
    fantasyList.add(princessBride);
    fantasyMovies = new Vector(fantasyList.getMovies());

    mainWindow = new JFrameOperator("Movie List");
    editor = new MovieListEditor(movieList, 
                                 (SwingMovieListEditorView)mainWindow.getWindow());
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    mainWindow.dispose();
  }

  public void testCategoryFiltering() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    JComboBoxOperator categoryCombo = new JComboBoxOperator(mainWindow, new NameBasedChooser("categoryFilter"));

    categoryCombo.setSelectedItem(Category.FANTASY);

    ListModel fantasyListModel = movieList.getModel();
    assertEquals("Fantasy list is the wrong size", fantasyMovies.size(), 
                 fantasyListModel.getSize());

    for (int i = 0; i < fantasyMovies.size(); i++) {
      assertEquals("Fantasy list contains bad movie at index " + i, fantasyMovies.get(i), 
                   fantasyListModel.getElementAt(i));
    }
    
    categoryCombo.setSelectedItem(Category.THRILLER);

    ListModel thrillerListModel = movieList.getModel();
    assertEquals("Thriller list is the wrong size", thrillerMovies.size(), 
                 thrillerListModel.getSize());

    for (int i = 0; i < thrillerMovies.size(); i++) {
      assertEquals("Thriller list contains bad movie at index " + i, thrillerMovies.get(i), 
                   thrillerListModel.getElementAt(i));
    }
    
    categoryCombo.setSelectedItem(Category.ALL);

    ListModel allListModel = movieList.getModel();
    assertEquals("Movie list is the wrong size", movies.size(), 
                 allListModel.getSize());

    for (int i = 0; i <movies.size(); i++) {
      assertEquals("Movie list contains bad movie at index " + i, movies.get(i), 
                   allListModel.getElementAt(i));
    }
  }

  public static void main(String[] args) {
    junit.textui.TestRunner.run(
          TestSwingMovieListEditorWithCategoryFiltering.class);
  }
}