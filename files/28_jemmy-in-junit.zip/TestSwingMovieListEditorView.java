// %1031325596972:com.saorsa.nowplaying.tests%

/**
 * Copyright (c) 2002 Saorsa Development, Inc.
 */
package com.saorsa.nowplaying.tests;

import java.util.Iterator;
import java.util.Vector;

import javax.swing.ListModel;

import junit.framework.TestCase;

import org.netbeans.jemmy.operators.JButtonOperator;
import org.netbeans.jemmy.operators.JComboBoxOperator;
import org.netbeans.jemmy.operators.JDialogOperator;
import org.netbeans.jemmy.operators.JFrameOperator;
import org.netbeans.jemmy.operators.JLabelOperator;
import org.netbeans.jemmy.operators.JListOperator;
import org.netbeans.jemmy.operators.JTextAreaOperator;
import org.netbeans.jemmy.operators.JTextFieldOperator;

import com.saorsa.nowplaying.Category;
import com.saorsa.nowplaying.Movie;
import com.saorsa.nowplaying.MovieList;
import com.saorsa.nowplaying.MovieListEditor;
import com.saorsa.nowplaying.Rating;
import com.saorsa.nowplaying.SwingMovieListEditorView;


/**
 * DOCUMENT ME!
 */
public class TestSwingMovieListEditorView extends TestCase {
  //~ Instance variables -------------------------------------------------------

  private JFrameOperator mainWindow;

  /**
   * @associates Movie 
   */
  private Vector movies = null;
  private Movie starWars = null;
  private Movie starTrek = null;
  private Movie stargate = null;
  private Movie theShining = null;
  private MovieList movieList = null;
  private MovieListEditor editor = null;

  //~ Methods ------------------------------------------------------------------

  protected void setUp() throws Exception {
    super.setUp();
    SwingMovieListEditorView.start();
    starWars = new Movie("Star Wars", Category.SCIFI, 5);
    starTrek = new Movie("Star Trek", Category.SCIFI, 3);
    stargate = new Movie("Stargate", Category.SCIFI, -1);
    theShining = new Movie("The Shining", Category.HORROR, 2);
    theShining.addRating(new Rating(5, "Jack", "A timeless classic!"));

    movies = new Vector();
    movies.add(starWars);
    movies.add(starTrek);
    movies.add(stargate);
    movies.add(theShining);

    movieList = new MovieList();
    movieList.add(starWars);
    movieList.add(starTrek);
    movieList.add(stargate);
    movieList.add(theShining);

    mainWindow = new JFrameOperator("Movie List");
    editor = new MovieListEditor(movieList, 
                                 (SwingMovieListEditorView)mainWindow.getWindow());
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    mainWindow.dispose();
  }

  public void testListContents() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    ListModel listModel = movieList.getModel();
    assertEquals("Movie list is the wrong size", movies.size(), 
                 listModel.getSize());

    for (int i = 0; i < movies.size(); i++) {
      assertEquals("Movie list contains bad movie at index " + i, movies.get(i), 
                   listModel.getElementAt(i));
    }
  }

  public void testAdding() {
    String LOST_IN_SPACE = "Lost In Space";
    Movie lostInSpace = new Movie(LOST_IN_SPACE, Category.SCIFI, 3);
    movies.add(lostInSpace);

    JTextFieldOperator newMovieField = new JTextFieldOperator(mainWindow, new NameBasedChooser("name"));
    newMovieField.enterText(LOST_IN_SPACE);
    JComboBoxOperator categoryCombo = new JComboBoxOperator(mainWindow, new NameBasedChooser("category"));
    categoryCombo.setSelectedIndex(1);
    JButtonOperator addButton = new JButtonOperator(mainWindow, new NameBasedChooser("add"));
    addButton.doClick();

    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    ListModel listModel = movieList.getModel();
    assertEquals("Movie list is the wrong size", movies.size(), 
                 listModel.getSize());

    for (int i = 0; i < movies.size(); i++) {
      assertEquals("Movie list contains bad movie at index " + i, movies.get(i), 
                   listModel.getElementAt(i));
    }
  }

  public void testSelecting() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    movieList.clickOnItem(1, 1);

    JTextFieldOperator newMovieField = new JTextFieldOperator(mainWindow, new NameBasedChooser("name"));
    assertEquals("wrong text from selection.", "Star Trek", 
                 newMovieField.getText());
  }

  public void testUpdating() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    movieList.clickOnItem(1, 1);

    JTextFieldOperator newMovieField = new JTextFieldOperator(mainWindow, new NameBasedChooser("name"));
    newMovieField.enterText("Star Trek I");

    JButtonOperator updateButton = new JButtonOperator(mainWindow, new NameBasedChooser("update"));

    try {
      updateButton.doClick();
    } catch (Exception e) {
      e.printStackTrace();
    }

    movieList.clickOnItem(0, 1);
    movieList.clickOnItem(1, 1);
    assertEquals("Movie should have been renamed.", "Star Trek I", 
                 newMovieField.getText());
  }

  public void testDuplicateCausingAdd() {
    JTextFieldOperator newMovieField = new JTextFieldOperator(mainWindow, new NameBasedChooser("name"));
    newMovieField.enterText(starWars.getName());
    JComboBoxOperator categoryCombo = new JComboBoxOperator(mainWindow, new NameBasedChooser("category"));
    categoryCombo.setSelectedIndex(1);
    JButtonOperator addButton = new JButtonOperator(mainWindow, new NameBasedChooser("add"));
    addButton.pushNoBlock();

    checkDuplicateExceptionDialog();

    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    checkListIsUnchanged(movieList);
  }

  public void testDuplicateCausingUpdate() {
    starWars.addRating(new Rating(4, "Dave"));
    
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    movieList.clickOnItem(1, 1);

    JTextFieldOperator newMovieField = new JTextFieldOperator(mainWindow, new NameBasedChooser("name"));
    newMovieField.enterText(starWars.getName());

    JButtonOperator updateButton = new JButtonOperator(mainWindow, new NameBasedChooser("update"));
    updateButton.pushNoBlock();

    checkDuplicateExceptionDialog();
    checkListIsUnchanged(movieList);
  }

  public void testSelectUpdatesRating() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    JListOperator ratingsList = new JListOperator(mainWindow, new NameBasedChooser("ratings"));

    movieList.clickOnItem(0, 1);
    verifyRatings(ratingsList, starWars);
    movieList.clickOnItem(1, 1);
    verifyRatings(ratingsList, starTrek);
    movieList.clickOnItem(2, 1);
    verifyRatings(ratingsList, stargate);
  }

  private void verifyRatings(JListOperator ratingsList, Movie aMovie) {
    ListModel listModel = ratingsList.getModel();    
    Iterator ratingIterator = aMovie.ratings();
    int i = 0;
    while (ratingIterator.hasNext()) {
      Rating aRating = (Rating) ratingIterator.next();
      assertEquals("Expected rating not displayed", aRating, listModel.getElementAt(i));
      i++;
    }
    assertEquals("Wrong number of ratings displayed", i, listModel.getSize());
  }

  public void testSelectUpdatesCategory() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    JComboBoxOperator categoryField = new JComboBoxOperator(mainWindow, new NameBasedChooser("category"));

    movieList.clickOnItem(0, 1);
    assertEquals("wrong category from selecting starWars.", 
                 Category.SCIFI, categoryField.getSelectedItem());
    movieList.clickOnItem(3, 1);
    assertEquals("wrong category from selecting theShining.", 
                 Category.HORROR, categoryField.getSelectedItem());
    movieList.clickOnItem(1, 1);
    assertEquals("wrong category from selecting starTrek.", 
                 Category.SCIFI, categoryField.getSelectedItem());
  }

  public void testUpdateCategory() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    JComboBoxOperator categoryCombo = new JComboBoxOperator(mainWindow, new NameBasedChooser("category"));
    movieList.clickOnItem(0, 1);
    categoryCombo.setSelectedIndex(2);

    JButtonOperator updateButton = new JButtonOperator(mainWindow, new NameBasedChooser("update"));
    updateButton.pushNoBlock();
    movieList.clickOnItem(1, 1);
    movieList.clickOnItem(0, 1);
    assertEquals("updating should have changed category.", Category.HORROR, 
                 categoryCombo.getSelectedItem());
  }

  private void checkListIsUnchanged(JListOperator movieList) {
    ListModel listModel = movieList.getModel();
    assertEquals("Movie list is the wrong size", movies.size(), 
                 listModel.getSize());

    for (int i = 0; i < movies.size(); i++) {
      assertEquals("Movie list contains bad movie at index " + i, movies.get(i), 
                   listModel.getElementAt(i));
    }
  }

  private void checkDuplicateExceptionDialog() {
    JDialogOperator messageDialog = new JDialogOperator("Duplicate Movie");
    JLabelOperator message = new JLabelOperator(messageDialog);
    assertEquals("Wrong message text", 
                 "That would result in a duplicate Movie.", message.getText());

    JButtonOperator okButton = new JButtonOperator(messageDialog, "OK");
    okButton.doClick();
  }

  public void testAddingRatings() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    movieList.clickOnItem(0, 1);
    JComboBoxOperator ratingCombo = new JComboBoxOperator(mainWindow, new NameBasedChooser("ratingvalue"));
    ratingCombo.setSelectedIndex(3);
    JTextFieldOperator ratingSourceField = new JTextFieldOperator(mainWindow, new NameBasedChooser("ratingsource"));
    ratingSourceField.enterText("Dave");
    JTextAreaOperator reviewField = new JTextAreaOperator(mainWindow, new NameBasedChooser("review"));
    reviewField.setText("Not bad.");
    JButtonOperator addRatingButton = new JButtonOperator(mainWindow, new NameBasedChooser("addrating"));
    addRatingButton.doClick();
    Vector ratings = starWars.getRatings();
    assertEquals("starWars should have 2 ratings.", 2, ratings.size());
    Rating newRating = (Rating)ratings.get(1);
    assertEquals("New rating has wrong value.", 3, newRating.getValue());
    assertEquals("New rating has wrong source.", "Dave", newRating.getSource());
    assertEquals("New rating has wrong review.", "Not bad.", newRating.getReview());
    JListOperator ratingsList = new JListOperator(mainWindow, new NameBasedChooser("ratings"));
    verifyRatings(ratingsList, starWars);
  }
  
  public void testWithoutReview() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    movieList.clickOnItem(0, 1);
    JListOperator ratingsList = new JListOperator(mainWindow, new NameBasedChooser("ratings"));
    ratingsList.clickOnItem(0, 1);
    JTextAreaOperator reviewField = new JTextAreaOperator(mainWindow, new NameBasedChooser("review"));
    assertEquals("There should not be a review.", "", reviewField.getText());
  }
  
  public void testWithReview() {
    JListOperator movieList = new JListOperator(mainWindow, new NameBasedChooser("movieList"));
    movieList.clickOnItem(3, 1);
    JListOperator ratingsList = new JListOperator(mainWindow, new NameBasedChooser("ratings"));
    ratingsList.clickOnItem(1, 1);
    JComboBoxOperator ratingCombo = new JComboBoxOperator(mainWindow, new NameBasedChooser("ratingvalue"));
    assertEquals("Bad rating value.", 5, ratingCombo.getSelectedIndex());
    JTextFieldOperator ratingSourceField = new JTextFieldOperator(mainWindow, new NameBasedChooser("ratingsource"));
    assertEquals("Bad rating source.", "Jack", ratingSourceField.getText());
    JTextAreaOperator reviewField = new JTextAreaOperator(mainWindow, new NameBasedChooser("review"));
    assertEquals("There should be a review.", "A timeless classic!", reviewField.getText());
  }
  
  public static void main(String[] args) {
    junit.textui.TestRunner.run(TestSwingMovieListEditorView.class);
  }
}