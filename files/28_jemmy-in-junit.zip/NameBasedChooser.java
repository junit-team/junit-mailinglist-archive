// %1031682923671:com.saorsa.nowplaying%

/**
 * Copyright (c) 2002 Saorsa Development, Inc.
 */
package com.saorsa.nowplaying.tests;

import java.awt.Component;

import org.netbeans.jemmy.ComponentChooser;


/**
 * DOCUMENT ME!
 */
public class NameBasedChooser implements ComponentChooser {
  //~ Instance variables -------------------------------------------------------

  private String name;

  //~ Constructors -------------------------------------------------------------

  public NameBasedChooser(String componentName) {
    name = componentName;
  }

  //~ Methods ------------------------------------------------------------------

  public boolean checkComponent(Component aComponent) {
    String theName = aComponent.getName();
    return (theName != null) && theName.equals(name);
  }

  public String getDescription() {
    return "Matches Components named \"" + name + "\"";
  }
}