/*
 * Copyright (C) 2001 Clarkware Consulting, Inc.
 * All Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *
 *  3. Neither the name of Clarkware Consulting, Inc. nor the names of its 
 *     contributors may be used to endorse or promote products derived 
 *     from this software without prior written permission. For written 
 *     permission, please contact clarkware@clarkware.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * CLARKWARE CONSULTING OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE OF THIS 
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import java.io.File;
import java.net.URL;
import java.util.StringTokenizer;

/**
 * <code>WhichJUnit</code> is a utility that prints the absolute
 * location of the JUnit class files required to run and test
 * JUnit and its samples, as prescribed by the current classpath.  
 * It also prints the absolute location of the 'excluded.properties' 
 * file that will be applied when using the graphical UIs.
 * Additionally, the current classpath is printed with a report of 
 * any non-existent or invalid class path entries.
 * 
 * @author <a href="mailto:mike@clarkware.com">Mike Clark</a>
 * @author <a href="http://www.clarkware.com">Clarkware Consulting, Inc.</a>
 */

public class WhichJUnit {
	
	public WhichJUnit() {
	}
	
	public void whichJUnit() {
		whichAssertClass();
		whichExcludedProperties();
		whichJUnitAllTestsClass();
		whichSamplesAllTestsClass();
	}
	
	public void whichAssertClass() {

		String resource = "/junit/framework/Assert.class";
		
		URL classUrl = getResourceURL(resource);
		
		if (classUrl == null) {
			log("\njunit.framework.Assert class not found!");
			log("To run JUnit, add junit.jar to the classpath.");
		} else {
			log("\njunit.framework.Assert class found in \n'" + 
				classUrl.getFile() + "'");
		}
	}
	
	public void whichJUnitAllTestsClass() {
		
		String resource = "/junit/tests/AllTests.class";
		
		URL classUrl = getResourceURL(resource);
		
		if (classUrl == null) {
			log("\njunit.tests.AllTests class not found!");
			log("To test JUnit, add the JUnit installation " +
				"directory to the classpath.");
		} else {
			log("\njunit.tests.AllTests class found in \n'" + 
				classUrl.getFile() + "'");
		}
	}
	
	public void whichSamplesAllTestsClass() {
		
		String resource = "/junit/samples/AllTests.class";
		
		URL classUrl = getResourceURL(resource);
		
		if (classUrl == null) {
			log("\njunit.samples.AllTests class not found!");
			log("To run the JUnit samples, add the JUnit installation " +
				"directory to the classpath.");
		} else {
			log("\njunit.samples.AllTests class found in \n'" + 
				classUrl.getFile() + "'");
		}
	}
	
	public void whichExcludedProperties() {

		String resource = "/junit/runner/excluded.properties";
		
		URL propertiesURL = getResourceURL(resource);
		
		if (propertiesURL == null) {
			log("\n/junit/runner/excluded.properties not found!");
		} else {
			log("\n/junit/runner/excluded.properties" + 
				" found in \n'" + propertiesURL.getFile() + "'");
		}
	}
	
	public URL getResourceURL(String resource) {	
		return WhichJUnit.class.getResource(resource);
	}

	public void validate() {
		
		StringTokenizer tokenizer = 
			new StringTokenizer(getClasspath(), File.pathSeparator);
		
		while (tokenizer.hasMoreTokens()) {
			String element = tokenizer.nextToken();
			File f = new File(element);

			if (!f.exists()) {
				log("\n'" + element + "' " + "does not exist.");
			} else if ( (!f.isDirectory()) && 
					  (!element.toLowerCase().endsWith(".jar")) &&
					  (!element.toLowerCase().endsWith(".zip")) ) {

				log("\n'" + element + "' " +
					"is not a directory, .jar file, or .zip file.");

			}
		}
	}

	public void printClasspath() {

		log("\nClasspath:");
		StringTokenizer tokenizer = 
			new StringTokenizer(getClasspath(), File.pathSeparator);
		while (tokenizer.hasMoreTokens()) {
			log(tokenizer.nextToken());
		}	
	}
	
	public void log(String message) {
		System.out.println(message);
	}

	public String getClasspath() {
		return System.getProperty("java.class.path");
	}

	public static void main(String args[]) {
		WhichJUnit which = new WhichJUnit();
		which.whichJUnit();
		which.printClasspath();
		which.validate();
	}
}
