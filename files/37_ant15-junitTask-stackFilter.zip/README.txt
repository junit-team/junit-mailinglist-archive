JUnit provides a feature that filters stack frames in exception and error
messages so that junit framework method frames don't clutter your 
exception stack traces.  That is, unless you are testing JUnit itself, you
really don't need to see any of those junit.framework.* stack frames in 
an exception trace.

I modified the Ant JUnit task to support this functionality.  It works with
the PlainResultsFormatter and XMLResultsFormatter.  It works with the JUnit
task, whether you fork the JVM or not, and it also works with the batchtest
JUnit task, again, whether you fork or not.  Now we have nice, short
exception traces in our nice HTML reports produced with the Ant JUnit and 
JUnitReport tasks.

The built-in filter applies to the following call patterns:
  "junit.framework.TestCase",
  "junit.framework.TestResult",
  "junit.framework.TestSuite",
  "junit.framework.Assert.",
  "junit.swingui.TestRunner",
  "junit.awtui.TestRunner",
  "junit.textui.TestRunner",
  "java.lang.reflect.Method.invoke(",
  "org.apache.tools.ant."

Like the filter in JUnit, it is not configurable, other than to turn it off/on.  
It could be, but I think the intended purpose is pretty well achieved with that 
default set of patterns.

To use it in a build.xml, do nothing; the filtering is enabled by default.  To 
disable it, just add the attribute filtertrace="false" to your junit task 
element, e.g.:

<junit printsummary="yes" filtertrace="true" dir="${basedir}/lib" haltonerror="${qa.junit.haltonerror}" haltonfailure="${qa.junit.haltonfailure}" fork="yes">


Here is an example of the before and after versions of a filtered AssertionFailedError run in Ant:

Original, unfiltered output you get with Ant:

junit.framework.AssertionFailedError
at junit.framework.Assert.fail(Assert.java:51)
at junit.framework.Assert.assertTrue(Assert.java:38)
at junit.framework.Assert.assertNotNull(Assert.java:199)
at junit.framework.Assert.assertNotNull(Assert.java:193)
at test.jrunx.persistence.DatabaseTest.setUp(DatabaseTest.java:61)
at junit.framework.TestCase.runBare(TestCase.java:138)
at junit.framework.TestResult$1.protect(TestResult.java:106)
at junit.framework.TestResult.runProtected(TestResult.java:124)
at junit.framework.TestResult.run(TestResult.java:109)
at junit.framework.TestCase.run(TestCase.java:131)
at junit.framework.TestSuite.runTest(TestSuite.java:173)
at junit.framework.TestSuite.run(TestSuite.java:168)
at org.apache.tools.ant.taskdefs.optional.junit.JUnitTestRunner.run(JUnitTestRunner.java:252)
at org.apache.tools.ant.taskdefs.optional.junit.JUnitTestRunner.main(JUnitTestRunner.java:433)


With filtertrace enabled:

junit.framework.AssertionFailedError
at test.jrunx.persistence.DatabaseTest.setUp(DatabaseTest.java:61)


The source code is modified from Ant 1.5 source from about two weeks ago, so it
will probably only work with Ant 1.5, but I haven't even tried it with 1.4.
You can jar uvf the classes into your Ant optional.jar, or you may be able
to get it to work by mixing around with the jar file names, but this is
trickier since Ant uses the manifest file to set it's core classpath.

Scott Stirling
sstirling@macromedia.com
JRun QA
Macromedia